# NEXUS Platform — Claude Code Prompt Series

**Build the entire NEXUS post-coding distributed intelligence platform from a blank repository.**

Each prompt is self-contained. Feed them to Claude Code in order. Every prompt references the exact spec files, data structures, constants, and interfaces from the production specification so Claude Code can produce correct code without guessing.

---

## How to Use This Document

1. Create a fresh git repo: `mkdir nexus-platform && cd nexus-platform && git init`
2. Copy the spec files from `/download/nexus_specs/` into a `specs/` subdirectory
3. Open Claude Code (Anthropic's CLI agent) in the repo root
4. Paste prompts **in order**. Wait for each to complete before proceeding.
5. Run the verification command after each prompt.
6. Do NOT skip prompts. Every one depends on files created by previous prompts.

**Estimated total build time with Claude Code:** 15-20 sessions (one per prompt), each taking 5-30 minutes of Claude Code processing time. The fastest path to a demo (Prompts 1-9) should be achievable in a single day.

---

## Prompt 1: ESP-IDF Project Scaffold and Partition Table

```
Create an ESP-IDF v5.2+ C project called "nexus_limb" targeting ESP32-S3. This is the universal firmware binary for the NEXUS platform — a single binary that runs on every MCU node in the system, with role determined by JSON configuration at boot.

STRUCTURE:
```
nexus_limb/
├── CMakeLists.txt
├── main/
│   ├── CMakeLists.txt
│   ├── main.c              (boot sequence + FreeRTOS task setup)
│   └── components/
│       ├── nexus_protocol/  (Step 2 — wire protocol)
│       ├── nexus_io/        (Step 5 — I/O abstraction)
│       ├── nexus_vm/        (Step 4 — bytecode VM)
│       └── nexus_safety/    (Step 3 — safety monitor)
├── partitions.csv
└── sdkconfig.defaults
```

PARTITION TABLE (partitions.csv):
Create this CSV with these exact entries:
- nvs: data/nvs, 0x9000, 0x6000
- otadata: data/ota, 0x17000, 0x2000
- phy_init: data/phy, 0x19000, 0x1000
- factory: app/factory, 0x20000, 0x80000   (512KB — never OTA-modified)
- ota_0: app/ota_0, 0xA0000, 0x180000      (1.5MB)
- ota_1: app/ota_1, 0x220000, 0x180000     (1.5MB)
- reflexes: data/spiffs, 0x3A0000, 0x200000  (2MB — LittleFS for reflex JSON + bytecode)
- coredump: data/coredump, 0x5A0000, 0x10000 (64KB)

sdkconfig.defaults must set:
- CONFIG_ESPTOOLPY_FLASHSIZE_16MB=y
- CONFIG_PARTITION_TABLE_SINGLE_APP=n
- CONFIG_PARTITION_TABLE_CUSTOM=y
- CONFIG_PARTITION_TABLE_CUSTOM_FILENAME="partitions.csv"
- CONFIG_SPIRAM=y
- CONFIG_SPIRAM_MODE_OCT=y
- CONFIG_SPIRAM_SPEED_80M=y
- CONFIG_ESP_CONSOLE_UART_NUM=0
- CONFIG_FREERTOS_HZ=1000
- CONFIG_ESP_DEFAULT_CPU_FREQ_240=y
- CONFIG_ESP_TASK_WDT=y
- CONFIG_ESP_TASK_WDT_TIMEOUT_S=1

For main.c, implement ONLY the skeleton:
- app_main() that logs "NEXUS Limb v0.1.0 booting" and creates a single "main_task" FreeRTOS task
- main_task() that: (a) logs boot start, (b) forces all GPIO outputs LOW (iterate all possible GPIOs, gpio_set_direction with GPIO_MODE_OUTPUT then gpio_set_level(0)), (c) enters an infinite loop with vTaskDelay(1000/portTICK_PERIOD_MS)
- Include esp_log.h, esp_system.h, freertos/FreeRTOS.h, freertos/task.h, driver/gpio.h
- Tag all logs with "NEXUS"

Write the CMakeLists.txt files so the project builds with `idf.py build` targeting esp32s3.
After writing, run: idf.py set-target esp32s3 && idf.py build
Fix any build errors until it compiles cleanly.
```

---

## Prompt 2: NEXUS Serial Wire Protocol — COBS, CRC-16, Framing, Message Dispatch

```
Implement the complete NEXUS Serial Wire Protocol as an ESP-IDF component at main/components/nexus_protocol/.

Reference spec: specs/protocol/wire_protocol_spec.md (read it for the full details)

Create these files:
1. cobs.h / cobs.c — COBS (Consistent Overhead Byte Stuffing) encode and decode
2. crc16.h / crc16.c — CRC-16/CCITT-FALSE (polynomial 0x1021, init 0xFFFF)
3. framing.h / framing.c — Frame TX/RX with ring buffers
4. msg_handler.h / msg_handler.c — Message dispatch table for 28 message types
5. protocol_types.h — All type definitions, message IDs, error codes, flags

KEY CONSTANTS (define as macros or enums in protocol_types.h):
- NEXUS_MSG_IDENTITY = 0x01
- NEXUS_MSG_ROLE_ASSIGN = 0x02
- NEXUS_MSG_ROLE_ACK = 0x03
- NEXUS_MSG_SELFTEST_RESULT = 0x04
- NEXUS_MSG_HEARTBEAT = 0x05
- NEXUS_MSG_TELEMETRY = 0x06
- NEXUS_MSG_COMMAND = 0x07
- NEXUS_MSG_COMMAND_ACK = 0x08
- NEXUS_MSG_REFLEX_DEPLOY = 0x09
- NEXUS_MSG_REFLEX_STATUS = 0x0A
- NEXUS_MSG_OBS_RECORD_START = 0x0B
- NEXUS_MSG_OBS_RECORD_STOP = 0x0C
- NEXUS_MSG_OBS_DUMP_HEADER = 0x0D
- NEXUS_MSG_OBS_DUMP_CHUNK = 0x0E
- NEXUS_MSG_OBS_DUMP_END = 0x0F
- NEXUS_MSG_IO_RECONFIGURE = 0x10
- NEXUS_MSG_FIRMWARE_UPDATE_START = 0x11
- NEXUS_MSG_FIRMWARE_UPDATE_CHUNK = 0x12
- NEXUS_MSG_FIRMWARE_UPDATE_END = 0x13
- NEXUS_MSG_FIRMWARE_UPDATE_RESULT = 0x14
- NEXUS_MSG_ERROR = 0x15
- NEXUS_MSG_PING = 0x16
- NEXUS_MSG_PONG = 0x17
- NEXUS_MSG_BAUD_UPGRADE = 0x18
- NEXUS_MSG_CLOUD_CONTEXT_REQUEST = 0x19
- NEXUS_MSG_CLOUD_RESULT = 0x1A
- NEXUS_MSG_AUTO_DETECT_RESULT = 0x1B
- NEXUS_MSG_SAFETY_EVENT = 0x1C

MESSAGE HEADER (10 bytes, big-endian):
typedef struct __attribute__((packed)) {
    uint8_t msg_type;       // offset 0
    uint8_t flags;          // offset 1
    uint16_t sequence;      // offset 2-3
    uint32_t timestamp_ms;  // offset 4-7
    uint16_t payload_len;   // offset 8-9
} nexus_header_t;

Flags bits:
- bit 0: ACK_REQUIRED
- bit 1: IS_ACK
- bit 2: IS_ERROR
- bit 3: URGENT
- bit 4: COMPRESSED
- bit 5: ENCRYPTED
- bit 6: NO_TIMESTAMP
- bit 7: RESERVED

COBS ENCODING RULES:
- Input is raw bytes, output has no 0x00 except at frame boundaries
- Scan left to right, count consecutive non-zero bytes
- When 0x00 encountered or 254 non-zeros counted, emit count byte then the non-zero bytes
- Frame format: 0x00 [COBS-encoded(header+payload+crc16)] 0x00

CRC-16/CCITT-FALSE:
- Polynomial: 0x1021
- Init: 0xFFFF
- Final XOR: 0x0000
- Check value for "123456789": 0x29B1
- CRC computed over decoded header + payload (NOT including the CRC bytes themselves)

FRAME SIZE LIMITS:
- Max payload: 1024 bytes
- Max decoded frame: 1036 bytes (10 header + 1024 payload + 2 CRC)
- Max COBS-encoded: 1051 bytes
- Max wire frame: 1053 bytes (1 + 1051 + 1)

FRAMING.C:
- Ring buffer for RX (2048 bytes minimum)
- State machine: IDLE -> RECEIVING -> PROCESSING
- On receiving 0x00 byte in IDLE: enter RECEIVING, reset buffer
- On receiving 0x00 byte in RECEIVING: COBS decode, verify CRC, dispatch
- On overflow (buffer > 1053): emit FRAME_TOO_LARGE error, reset to IDLE
- TX function: build frame from header+payload, COBS encode, send with 0x00 delimiters

MSG_HANDLER.C:
- typedef void (*msg_handler_fn)(const nexus_header_t *hdr, const uint8_t *payload, uint16_t len);
- Static array of 32 handler function pointers indexed by msg_type
- nexus_protocol_register_handler(uint8_t msg_type, msg_handler_fn fn)
- nexus_protocol_dispatch(const uint8_t *decoded_frame, uint16_t len)

ERROR CODES (key subset — define all 75 in protocol_types.h):
- 0x0000 NONE, 0x0001 UNKNOWN, 0x0003 INVALID_PAYLOAD, 0x0004 TIMEOUT
- 0x1001 GPIO_INIT_FAILED, 0x1004 I2C_BUS_LOCKED, 0x1005 I2C_DEVICE_NOT_FOUND
- 0x2001 PIN_MODE_INVALID, 0x2002 PIN_ALREADY_IN_USE
- 0x3001 REFLEX_PARSE_ERROR, 0x3004 REFLEX_TABLE_FULL
- 0x4001 KILL_SWITCH_ACTIVATED, 0x4002 OVERCURRENT_DETECTED
- 0x5001 FRAME_TOO_LARGE, 0x5003 CRC_MISMATCH, 0x5004 COBS_DECODE_ERROR
- 0x5005 SEQUENCE_GAP, 0x6001 OTA_HASH_MISMATCH

After writing all files, update main.c to:
- Include nexus_protocol.h
- In main_task, initialize the protocol layer (empty init for now)
- Log "Protocol layer initialized"
Build and verify no errors.
```

---

## Prompt 3: Safety System — Kill Switch ISR, Watchdog, Heartbeat Monitor

```
Implement the safety system as an ESP-IDF component at main/components/nexus_safety/.

Reference spec: specs/safety/safety_system_spec.md

Create these files:
1. kill_switch.h / kill_switch.c — GPIO ISR for NC mushroom-head kill switch
2. watchdog.h / watchdog.c — Software watchdog feeding external MAX6818 IC
3. heartbeat.h / heartbeat.c — Jetson heartbeat monitoring with escalation
4. safety_manager.h / safety_manager.c — Overall safety state machine

KILL SWITCH (kill_switch.c):
- Configure a GPIO pin (default GPIO_NUM_22, configurable via KConfig) as INPUT with PULLUP
- Register a falling-edge interrupt (switch opens -> GPIO goes LOW because external pull-up + NC contact)
- ISR must be IRAM_ATTR, highest priority (ESP_INTR_FLAG_LEVEL1)
- ISR actions (in exact order, NO blocking ops, NO floats, NO logging):
  1. Set volatile flag estop_triggered = true
  2. Call gpio_set_level(pin, SAFE_VALUE) for ALL configured output pins
  3. Call ledc_set_duty(0) for ALL PWM channels
  4. Give semaphore from ISR (xSemaphoreGiveFromISR)
- ISR must complete in <1ms
- Deferred handler (runs in safety supervisor task): log event, suspend all tasks, notify Jetson
- Provide nexus_safety_init(gpio_num_t kill_gpio, output_pin_t *outputs, size_t num_outputs)

WATCHDOG (watchdog.c):
- Configure a GPIO pin (default GPIO_NUM_4) connected to MAX6818 WDI
- Feed pattern: alternate 0x55/0xAA (toggle LOW-HIGH then HIGH-LOW)
- Feed interval: 200ms (FreeRTOS timer callback)
- Pattern: odd feeds = LOW then HIGH, even feeds = HIGH then LOW
- If firmware hangs with GPIO stuck constant, WDT IC times out (1.0s) and asserts ESP32 EN pin
- Provide nexus_watchdog_init(gpio_num_t wdt_gpio) and nexus_watchdog_feed()

HEARTBEAT (heartbeat.c):
- Receives heartbeat messages on UART0 (115200 baud, 8N1)
- Format: "HB:<seq>:<timestamp_ms>:<checksum>\n"
- XOR checksum of all bytes before \n
- Expected interval: 100ms (10 Hz from Jetson)
- Escalation thresholds:
  - 5 missed (500ms): enter DEGRADED mode
  - 10 missed (1000ms): enter SAFE_STATE (all outputs to safe position)
- Recovery: 3 consecutive good heartbeats -> return to NORMAL
- System does NOT auto-resume — Jetson must send explicit RESUME command
- State enum: HB_NORMAL, HB_DEGRADED, HB_SAFE_STATE
- Provide nexus_heartbeat_init() and nexus_heartbeat_check() (called every 100ms)

SAFETY MANAGER (safety_manager.c):
- Overall safety state: SAFE_NORMAL, SAFE_DEGRADED, SAFE_STATE, SAFE_FAULT
- Priority enum for safety events: SAFE_INFO, SAFE_WARNING, SAFE_ERROR, SAFE_CRITICAL
- Log safety events to NVS (esp_nvs_flash)
- Boot counter: increment on every boot, if >5 in 10 minutes enter FAULT mode
- Provide nexus_safety_get_state(), nexus_safety_log_event(level, code, detail)

Update main.c:
- At T+0ms: Call nexus_safety_init() with kill switch GPIO and all output pins
- At T+5ms: Call nexus_watchdog_init() and start feed timer
- At T+10ms: Initialize UART for heartbeat
- Create safety_supervisor task at highest priority (configMAX_PRIORITIES - 1), 2048 byte stack, 10ms period
- safety_supervisor task calls nexus_heartbeat_check() and monitors heap

Build and verify.
```

---

## Prompt 4: Reflex Bytecode Virtual Machine

```
Implement the Reflex Bytecode VM as an ESP-IDF component at main/components/nexus_vm/.

Reference spec: specs/firmware/reflex_bytecode_vm_spec.md

Create these files:
1. vm.h / vm.c — VM execution engine, memory model, fetch-decode-execute loop
2. opcodes.h — All 32 opcode definitions, instruction encoding
3. safety.h / safety.c — VM safety invariants (stack bounds, cycle budget, actuator clamping)
4. reflex_loader.h / reflex_loader.c — Load reflex definitions, manage multiple reflexes

OPCODE DEFINITIONS (opcodes.h):
Each instruction is exactly 8 bytes:
  Byte 0: opcode (uint8)
  Byte 1: flags (uint8)
  Bytes 2-3: operand1 (uint16, little-endian on ESP32-S3)
  Bytes 4-7: operand2 (uint32, little-endian on ESP32-S3)

#define OP_NOP          0x00
#define OP_PUSH_I8      0x01
#define OP_PUSH_I16     0x02
#define OP_PUSH_F32     0x03
#define OP_POP          0x04
#define OP_DUP          0x05
#define OP_SWAP         0x06
#define OP_ROT          0x07
#define OP_ADD_F        0x08
#define OP_SUB_F        0x09
#define OP_MUL_F        0x0A
#define OP_DIV_F        0x0B
#define OP_NEG_F        0x0C
#define OP_ABS_F        0x0D
#define OP_MIN_F        0x0E
#define OP_MAX_F        0x0F
#define OP_CLAMP_F      0x10
#define OP_EQ_F         0x11
#define OP_LT_F         0x12
#define OP_GT_F         0x13
#define OP_LTE_F        0x14
#define OP_GTE_F        0x15
#define OP_AND_B        0x16
#define OP_OR_B         0x17
#define OP_XOR_B        0x18
#define OP_NOT_B        0x19
#define OP_READ_PIN     0x1A
#define OP_WRITE_PIN    0x1B
#define OP_READ_TIMER   0x1C
#define OP_JUMP         0x1D
#define OP_JMP_FALSE    0x1E
#define OP_JMP_TRUE     0x1F

Flags:
#define FLAG_HAS_IMMEDIATE  0x01
#define FLAG_IS_FLOAT       0x02
#define FLAG_EXTENDED_CLAMP 0x04
#define FLAG_IS_CALL        0x08
#define FLAG_SYSCALL        0x80

Syscall (NOP with FLAG_SYSCALL):
#define SYSCALL_HALT              0x01
#define SYSCALL_PID_COMPUTE       0x02
#define SYSCALL_RECORD_SNAPSHOT   0x03
#define SYSCALL_EMIT_EVENT        0x04

MEMORY MODEL (vm.h):
typedef struct {
    uint32_t stack[256];         // Data stack (1 KB)
    uint16_t sp;                 // Stack pointer (index of next free slot)
    struct { uint32_t addr; uint32_t frame; } call_stack[16]; // Call stack (256 B)
    uint16_t csp;                // Call stack pointer
    float variables[256];       // Persistent variables (1 KB)
    float sensor_regs[64];      // Sensor registers — populated by firmware before each tick (256 B)
    float actuator_regs[64];    // Actuator registers — drained by firmware after each tick (256 B)
    bool    actuator_dirty[64]; // Track which actuator regs were written
    uint32_t tick_count_ms;      // Current tick counter
    uint32_t cycle_count;        // Cycles this tick
    uint32_t max_cycles;         // Cycle budget (default 10000)
    bool    halted;              // VM halted flag
    bool    error;               // VM error flag
    char    error_msg[64];       // Error description
} nexus_vm_t;

PID CONTROLLER STATE (8 instances, 32 bytes each):
typedef struct {
    float kp, ki, kd;
    float integral, prev_error;
    float integral_limit;
    float output_min, output_max;
} nexus_pid_t;

SNAPSHOT BUFFER (16 snapshots x 128 bytes):
typedef struct {
    uint32_t tick_ms;
    uint32_t cycle_count;
    uint32_t current_state;
    float vars[15];
    float sensors[14];
} nexus_snapshot_t;

EVENT RING BUFFER (32 events x 8 bytes):
typedef struct {
    uint32_t tick_ms;
    uint16_t event_id;
    uint16_t event_data;
} nexus_vm_event_t;

VARIABLE ACCESS CONVENTION:
- READ_PIN with operand1 >= 64 reads variable at index (operand1 - 64)
- WRITE_PIN with operand1 >= 64 writes variable at index (operand1 - 64)
- Variable index range: 0-255

STATE MACHINE CONVENTION:
- Current state stored in variable 0 (VAR_0 = READ_PIN 64 / WRITE_PIN 64)

EXECUTION ENGINE (vm.c):
- nexus_vm_init(vm) — zero all memory, set max_cycles=10000
- nexus_vm_load_bytecode(vm, bytecode, size) — validate all instructions before loading
- nexus_vm_tick(vm) — execute one tick:
  1. If halted, return immediately
  2. PC = 0, cycle_count = 0
  3. Fetch 8 bytes at PC, decode opcode
  4. Execute instruction (switch on opcode)
  5. PC += 8
  6. If opcode is NOP with FLAG_SYSCALL, handle syscall
  7. If opcode is JUMP with FLAG_IS_CALL, push return address and jump
  8. If PC reaches 0xFFFFFFFF or HALT sentinel, set halted=true
  9. After execution: clamp all dirty actuator_regs to configured min/max bounds
  10. Check cycle_count < max_cycles, else halt with error

SAFETY INVARIANTS (safety.c):
- Every PUSH: if sp >= 256, HALT with ERR_STACK_OVERFLOW
- Every POP: if sp == 0, HALT with ERR_STACK_UNDERFLOW
- Every READ_PIN/WRITE_PIN: if operand1 >= 384, HALT with ERR_INVALID_OPERAND (max 64 sensors + 256 vars + 64 actuators = 384)
- Every JUMP/JMP_FALSE/JMP_TRUE: validate target < bytecode_size and target % 8 == 0
- Cycle budget: if cycle_count >= max_cycles, halt with ERR_CYCLE_BUDGET_EXCEEDED
- Division by zero (DIV_F): return 0.0f, NOT NaN/Inf
- Call depth: if csp >= 16, HALT with ERR_CALL_DEPTH_EXCEEDED

PID COMPUTE (in syscall handler):
- Stack before: [..., setpoint_f32, input_f32]
- Stack after:  [..., output_f32]
- Use anti-windup: clamp integral to ±integral_limit
- Output clamping: clamp to output_min..output_max
- Derivative: (error - prev_error) / dt, where dt is configurable tick period

Create unit tests as a separate test file that:
- Tests PUSH/POP/DUP/SWAP/ROT with boundary conditions
- Tests ADD/SUB/MUL/DIV including division by zero
- Tests NEG_F, ABS_F, MIN_F, MAX_F, CLAMP_F
- Tests all comparisons (EQ, LT, GT, LTE, GTE)
- Tests JUMP, JUMP_IF_FALSE, JUMP_IF_TRUE
- Tests variable read/write via READ_PIN/WRITE_PIN with operand >= 64
- Tests stack overflow/underflow detection
- Tests cycle budget enforcement
- Tests PID_COMPUTE syscall

Build and verify. This is the most complex component.
```

---

## Prompt 5: I/O Abstraction Layer and Drivers

```
Implement the I/O abstraction layer as an ESP-IDF component at main/components/nexus_io/.

Reference specs:
- specs/firmware/io_driver_interface.h (read this for the exact C interface contract)
- specs/firmware/io_driver_registry.json (read this for driver register sequences)

Create these files:
1. io_abstraction.h / io_abstraction.c — Pin configuration parser, validator, allocator
2. pin_config.h / pin_config.c — Pin capability database, conflict detection
3. drivers/driver_hmc5883l.h / drivers/driver_hmc5883l.c — I2C compass
4. drivers/driver_mpu6050.h / drivers/driver_mpu6050.c — I2C IMU (accel + gyro)
5. drivers/driver_bme280.h / drivers/driver_bme280.c — I2C temperature/humidity/pressure
6. drivers/driver_digital.h / drivers/driver_digital.c — GPIO digital input/output
7. drivers/driver_pwm.h / drivers/driver_pwm.c — PWM output (LEDC)
8. drivers/driver_adc.h / drivers/driver_adc.c — ADC input

DRIVER VTABLE INTERFACE (io_abstraction.h — must match spec exactly):
typedef enum {
    IO_OK = 0,
    IO_ERR_NOT_FOUND,
    IO_ERR_INIT_FAILED,
    IO_ERR_INVALID_PIN,
    IO_ERR_INVALID_PARAM,
    IO_ERR_BUSY,
    IO_ERR_TIMEOUT,
    IO_ERR_NOT_IMPLEMENTED
} io_err_t;

typedef struct {
    const char *name;
    uint8_t bus;           // I2C bus number, or 0xFF for GPIO
    uint16_t addr;         // I2C address, or GPIO number
    io_pin_mode_t mode;
    io_pin_pull_t pull;
    float safe_value;      // For actuators: value on boot/safety event
    float min_value;
    float max_value;
    uint32_t flags;
} io_pin_config_t;

// Every driver implements this vtable:
typedef struct io_driver {
    const char *name;
    io_err_t (*init)(const io_pin_config_t *config);
    io_err_t (*read)(const io_pin_config_t *config, float *value);
    io_err_t (*write)(const io_pin_config_t *config, float value);
    io_err_t (*configure)(const io_pin_config_t *config, const char *key, const char *value);
    io_err_t (*selftest)(const io_pin_config_t *config);
    io_err_t (*deinit)(const io_pin_config_t *config);
    const char *(*get_info)(void);
} io_driver_t;

PIN CONFIG (pin_config.c):
- io_pin_mode_t: IO_PIN_INPUT, IO_PIN_OUTPUT, IO_PIN_PWM, IO_PIN_ADC, IO_PIN_I2C, IO_PIN_UART, IO_PIN_INTERRUPT
- io_pin_pull_t: IO_PULL_NONE, IO_PULL_UP, IO_PULL_DOWN
- Database of ESP32-S3 GPIO capabilities: which pins support which modes
- Conflict detection: two pins cannot use the same ADC channel, same I2C bus address, same PWM channel
- io_pin_allocate(io_pin_config_t *config) — validate mode against capability, detect conflicts, configure GPIO
- io_pin_deallocate(io_pin_config_t *config) — release pin

ROLE CONFIGURATION PARSER:
- Parse JSON ROLE_ASSIGN message into array of io_pin_config_t
- JSON format: { "role": "name", "pins": { "pin_name": { "gpio": N, "mode": "...", ... } } }
- Validate all pins before applying
- Store role config in NVS for cached boot (survives reboot without Jetson)

HMC5883L DRIVER (compass):
- I2C address 0x1E
- Reads 6 bytes: H (0x03), L (0x04), Z (0x05), then H (0x06), L (0x07), Z (0x08) for 16-bit values
- Gain configuration register 0x01 (default 1.3 Ga)
- Self-test: read identification registers A=0x48, B=0x34, C=0x33
- Returns heading in degrees (atan2 of X,Y)

MPU6050 DRIVER (IMU):
- I2C address 0x68 (AD0 low) or 0x69 (AD0 high)
- Reads accel (0x3B-0x40) and gyro (0x43-0x48), 6 bytes each, 16-bit little-endian
- Configures: sample rate divider, DLPF, wake-up
- Self-test: WHO_AM_I register should return 0x68
- Returns 6 values: accel_x, accel_y, accel_z, gyro_x, gyro_y, gyro_z

DIGITAL DRIVER:
- GPIO digital input or output
- read() returns 0.0 or 1.0
- write() sets GPIO HIGH or LOW
- Supports interrupt mode (falling edge, rising edge, any edge)

PWM DRIVER:
- Uses ESP-IDF LEDC peripheral
- Configurable frequency (default 50Hz for servos)
- write() sets duty cycle (0.0-100.0%)
- safe_value = 0.0 (output LOW on boot/safety)

ADC DRIVER:
- Uses ESP-IDF ADC1 with 12-bit resolution (0-4095)
- Configurable attenuation (default 11dB for 0-3.3V range)
- read() returns voltage (0.0-3.3)

Create io_abstraction.h with:
- io_abstraction_init() — initialize all subsystems
- io_abstraction_apply_role(const char *json) — parse JSON and configure all pins
- io_abstraction_read_sensor(uint8_t reg_index, float *value) — read from sensor register
- io_abstraction_write_actuator(uint8_t reg_index, float value) — write to actuator register (with safety check: is safety_state NORMAL?)
- io_abstraction_populate_sensor_regs() — called before each VM tick, reads all configured sensors
- io_abstraction_drain_actuator_regs() — called after each VM tick, writes all dirty actuators
- io_abstraction_selftest() — run all driver self-tests, return results

Build and verify.
```

---

## Prompt 6: Boot Sequence Integration and Role Assignment

```
Integrate all components into the main application with the exact timed boot sequence.

Reference spec: specs/safety/safety_system_spec.md Section 7

Update main.c to implement the complete boot sequence:

T+0ms: Power-on
  - app_main() entry
  - esp_logi("NEXUS", "Boot starting")
  - Initialize NVS
  - Load boot counter, check for FAULT mode (>5 boots in 10 min -> halt)
  - FORCE ALL GPIO OUTPUTS LOW (iterate all possible pins)
  - This is CRITICAL: must happen before ANY other initialization

T+5ms: Hardware Watchdog
  - nexus_watchdog_init(WDT_GPIO)
  - Start 200ms feed timer
  - esp_logi("NEXUS", "Hardware watchdog started")

T+10ms: UART Initialization
  - uart_driver_install(UART_NUM_0, 4096, 0, 0, NULL)
  - uart_param_config(UART_NUM_0, &uart_config) — 115200 baud, 8N1
  - uart_set_pin(UART_NUM_0, TX_PIN, RX_PIN)
  - Initialize protocol layer: nexus_protocol_init(UART_NUM_0)
  - esp_logi("NEXUS", "UART0 initialized at 115200 baud")

T+20ms: Send DEVICE_IDENTITY
  - Build JSON payload: { "mac": "AA:BB:CC:DD:EE:FF", "chip": "ESP32-S3", "flash_mb": 16, "psram_mb": 8, "firmware": "0.1.0", "capabilities": ["pwm","adc","i2c","gpio","uart"] }
  - Send as NEXUS_MSG_DEVICE_IDENTITY (0x01)
  - esp_logi("NEXUS", "Device identity sent")

T+30ms: Send AUTO_DETECT_RESULT
  - Scan I2C bus 0 for devices (probe addresses 0x08-0x77)
  - Scan ADC channels
  - Build JSON: { "i2c_devices": [{"addr": "0x1E", "name": "HMC5883L"}], "adc_channels": 5 }
  - Send as NEXUS_MSG_AUTO_DETECT_RESULT (0x1B)

T+50ms: Send SELFTEST_RESULT
  - Run nexus_safety_selftest()
  - Test all configured output pins for short-circuit
  - Verify ADC reference voltage
  - Verify flash partition CRC
  - Send as NEXUS_MSG_SELFTEST_RESULT (0x04)
  - esp_logi("NEXUS", "Selftest complete")

T+50-300ms: Wait for ROLE_ASSIGN
  - Register handler for NEXUS_MSG_ROLE_ASSIGN (0x02)
  - Wait up to 250ms
  - If received: parse JSON, call io_abstraction_apply_role(json)
  - If timeout: load cached role from NVS, or enter IDLE mode
  - Send NEXUS_MSG_ROLE_ACK (0x03)

T+300ms: Load Reflexes
  - Mount LittleFS partition at /spiffs/reflexes
  - Read all .json files from LittleFS
  - For each reflex: parse JSON, compile to bytecode (or load pre-compiled .bin), load into VM
  - esp_logi("NEXUS", "Loaded %d reflexes", count)

T+500ms: Enter OPERATIONAL
  - Set safety state to SAFE_NORMAL
  - Start heartbeat monitor
  - Start telemetry task (sends TELEMETRY at configured interval)
  - Start VM tick task (runs active reflexes at configured rate)
  - esp_logi("NEXUS", "Operational — role: %s", role_name)
  - Start main loop (handle incoming messages from protocol layer)

MESSAGE HANDLERS to register:
- 0x02 ROLE_ASSIGN: parse, validate, apply role config, load reflexes, send ACK
- 0x07 COMMAND: parse command, execute (write actuator, start/stop reflex), send ACK
- 0x09 REFLEX_DEPLOY: parse JSON reflex, compile to bytecode, load into VM, send ACK
- 0x0A REFLEX_STATUS: build status JSON for all loaded reflexes, send response
- 0x0B OBS_RECORD_START: start observation recording to PSRAM ring buffer
- 0x0C OBS_RECORD_STOP: stop recording
- 0x0E OBS_DUMP_CHUNK: not needed on ESP32 side (ESP32 sends chunks)
- 0x10 IO_RECONFIGURE: dynamic pin reconfiguration at runtime
- 0x11 FIRMWARE_UPDATE_START: begin OTA process
- 0x12 FIRMWARE_UPDATE_CHUNK: write chunk to update partition
- 0x13 FIRMWARE_UPDATE_END: verify SHA-256, set boot partition, prepare reboot
- 0x16 PING: respond with PONG

FREERTOS TASKS to create:
1. safety_supervisor — priority configMAX_PRIORITIES-1, 2048 stack, 10ms period
2. heartbeat_monitor — priority 5, 2048 stack, 100ms period
3. telemetry_sender — priority 3, 4096 stack, variable period (from role config)
4. vm_tick — priority 2, 4096 stack, variable period (from reflex config, default 100Hz)

Build and verify. This should produce a bootable firmware that announces itself on serial and waits for commands.
```

---

## Prompt 7: Jetson Python Package Scaffold and Serial Bridge

```
Create the Jetson cognitive layer as a Python package. This runs on NVIDIA Jetson Orin Nano (Linux, Python 3.11+).

Reference specs:
- specs/jetson/module_interface.py (the base ABC all modules must implement)
- specs/jetson/cluster_api.proto (gRPC service definitions)
- specs/jetson/mqtt_topics.json (MQTT topic hierarchy)

Create this package structure:
```
nexus_cognitive/
├── pyproject.toml
├── README.md
├── nexus_cognitive/
│   ├── __init__.py
│   ├── config.py               # Central configuration (serial ports, MQTT broker, etc.)
│   ├── nexus_module.py         # Base ABC for all modules (from spec)
│   ├── serial_bridge.py        # Serial port management for ESP32 connections
│   ├── serial_protocol.py      # Python implementation of NEXUS wire protocol
│   ├── node_manager.py         # Node discovery, role assignment, topology
│   ├── reflex_orchestrator.py  # Reflex lifecycle management
│   ├── mqtt_bridge.py          # MQTT pub/sub
│   ├── safety_manager.py        # Safety event handling, trust score
│   ├── chat_interface.py        # Chat with LLM (stub for now)
│   ├── learning_pipeline.py     # Pattern discovery (stub for now)
│   └── autonomy_manager.py     # INCREMENTS autonomy state
└── tests/
    ├── __init__.py
    ├── test_serial_protocol.py  # Wire protocol encode/decode tests
    └── test_trust_score.py      # Trust score formula tests
```

pyproject.toml dependencies:
- pyserial >= 3.5
- paho-mqtt >= 2.1
- grpcio >= 1.60
- protobuf >= 4.25
- pyarrow >= 14.0
- numpy >= 1.26
- scikit-learn >= 1.4

config.py — central configuration:
- SERIAL_PORTS: list of USB serial ports for ESP32 connections (auto-detected or configured)
- MQTT_BROKER: "localhost" (or "mqtt.eclipseprojects.io" for testing)
- MQTT_PORT: 1883
- BAUD_RATE: 115200 (initial), upgrade to 921600 after handshake
- HEARTBEAT_INTERVAL_MS: 100
- HEARTBEAT_TIMEOUT_MS: 1000
- DATA_DIR: "/data/nexus" (NVMe SSD)

nexus_module.py — exact ABC from spec:
- @abstractmethod async start() -> None
- @abstractmethod async stop() -> None
- @abstractmethod async health_check() -> ModuleHealth
- @abstractmethod resource_budget() -> ResourceBudget
- async hot_reload(config: dict) -> None
- Dataclasses: ModuleHealth(healthy: bool, message: str, timestamp: float), ResourceBudget(cpu_pct, gpu_pct, ram_mb, vram_mb)

serial_protocol.py — Python implementation of the wire protocol:
- COBS encode/decode (same algorithm as firmware)
- CRC-16/CCITT-FALSE (same polynomial, must match firmware exactly)
- Frame building/parsing: build_frame(msg_type, flags, payload) -> bytes
- Message header packing/unpacking (big-endian 10 bytes)
- All 28 message type constants
- All 75 error code constants
- Unit tests: encode a frame, decode it, verify round-trip, verify CRC

serial_bridge.py:
- Class SerialBridge:
  - __init__(port, baud_rate) — opens serial port
  - async read_loop() — continuously read bytes, feed to COBS frame decoder
  - async send_frame(msg_type, flags, payload) — build and send COBS frame
  - on_message_callback — set by node_manager
  - Auto-detect: scan /dev/ttyUSB* and /dev/ttyACM* for devices that respond with DEVICE_IDENTITY

node_manager.py:
- Class NodeManager:
  - discover_nodes() — scan all serial ports, send PING, collect DEVICE_IDENTITY responses
  - assign_role(node_id, role_config) — send ROLE_ASSIGN, wait for ROLE_ACK
  - get_topology() — return current node map
  - watch_nodes() — monitor heartbeats, detect disconnects

mqtt_bridge.py:
- Class MQTTBridge:
  - connect(broker, port)
  - publish_telemetry(node_id, data)
  - publish_safety_event(node_id, event)
  - subscribe_to_override(topic, callback)
  - QoS levels per mqtt_topics.json spec

Write comprehensive tests for serial_protocol.py covering:
- COBS encode/decode with edge cases (all zeros, 254 non-zeros, single byte)
- CRC-16 matching the check value 0x29B1 for "123456789"
- Frame round-trip for all 28 message types
- Header packing/unpacking with big-endian byte order
- Maximum payload size enforcement

Install with: pip install -e .
Run tests with: pytest tests/ -v
```

---

## Prompt 8: Reflex Orchestrator and Bytecode Compiler

```
Implement the Reflex Orchestrator and JSON-to-Bytecode compiler on the Jetson side.

Reference spec: specs/firmware/reflex_bytecode_vm_spec.md (especially Section 7 on compilation from JSON)

Create/update these files in nexus_cognitive/:

1. reflex_compiler.py — Compiles JSON reflex definitions to bytecode
2. reflex_orchestrator.py — Manages reflex lifecycle across nodes

REFLEX_COMPILER.PY:
The compiler takes a JSON reflex definition and produces a bytecode binary that the ESP32 VM can execute.

JSON input format:
{
  "name": "heading_hold_pid",
  "version": "1.2.0",
  "priority": 10,
  "tick_rate_hz": 10,
  "variables": {
    "integral": {"type": "float32", "initial": 0.0},
    "prev_error": {"type": "float32", "initial": 0.0}
  },
  "sensors": {
    "heading": {"reg": 0, "type": "float32", "unit": "deg"},
    "setpoint": {"reg": 1, "type": "float32", "unit": "deg"}
  },
  "actuators": {
    "rudder": {"reg": 0, "min": -45.0, "max": 45.0, "safe": 0.0}
  },
  "pid_controllers": {
    "heading_pid": {"kp": 1.2, "ki": 0.05, "kd": 0.3, "integral_limit": 1500.0, "output_min": -45.0, "output_max": 45.0}
  },
  "code": "READ_PIN heading; READ_PIN setpoint; PID_COMPUTE heading_pid; CLAMP_F -45.0 45.0; WRITE_PIN rudder"
}

Compiler implementation:
- parse_reflex_json(json_str) -> ReflexDefinition dataclass
- compile_to_bytecode(reflex_def) -> bytes
  1. First pass: allocate variable indices (map variable names to indices 0-255)
  2. Second pass: parse the "code" string into instruction tokens
  3. Token types: READ_PIN <name>, WRITE_PIN <name>, PUSH <value>, PID_COMPUTE <name>,
     CLAMP_F <lo> <hi>, JUMP <label>, JUMP_IF_FALSE <label>, LABEL <name>, SET_STATE <name>
  4. Third pass: resolve labels to byte offsets (label position * 8)
  5. Emit 8-byte instructions for each token
  6. Append HALT sentinel: opcode=0x00, flags=0x80, operand1=0x01 (SYSCALL_HALT)
  7. Run validator on generated bytecode

Instruction encoding helper:
def encode_instruction(opcode, flags=0, operand1=0, operand2=0) -> bytes:
    return struct.pack('<BBHI', opcode, flags, operand1, operand2)

  (H = uint16 big-endian, I = uint32 little-endian)

Validation:
- All jump targets within bytecode bounds
- All variable indices < 256
- All sensor/actuator register indices < 64
- PID controller indices < 8
- Stack depth never exceeds 256 at any point (static analysis)

Reflex definition JSON Schema — write this and validate against it:
- name: string, pattern "^[a-z][a-z0-9_]*$"
- version: string, pattern "^[0-9]+\.[0-9]+\.[0-9]+$"
- priority: integer, 0-255 (lower = higher priority)
- tick_rate_hz: integer, 1-1000
- variables: object mapping name -> {type, initial}
- sensors: object mapping name -> {reg, type, unit}
- actuators: object mapping name -> {reg, min, max, safe}
- pid_controllers: object mapping name -> {kp, ki, kd, integral_limit, output_min, output_max}
- code: string, semicolon-separated instruction tokens

REFLEX_ORCHESTRATOR.PY:
- Class ReflexOrchestrator:
  - deploy_reflex(node_id, reflex_json) — compile JSON to bytecode, send REFLEX_DEPLOY (0x09)
  - remove_reflex(node_id, reflex_name) — send command to remove reflex from node
  - list_reflexes(node_id) — send REFLEX_STATUS request (0x0A), return status
  - get_reflex_status(node_id, reflex_name) — specific reflex status
  - load_reflex_from_file(filepath) — read JSON file, validate schema
  - store_reflex_to_file(filepath, reflex_json) — persist reflex definition

Write comprehensive tests:
- Test compiling a simple counter reflex: increment variable every tick
- Test compiling the heading_hold_pid reflex with PID
- Test all 32 opcodes compile correctly
- Test variable allocation (name to index mapping)
- Test jump target resolution
- Test validation catches out-of-bounds access
- Test that compiled bytecode round-trips (compile -> disassemble -> verify)

Run tests with: pytest tests/ -v
```

---

## Prompt 9: End-to-End Integration — LED Blinker Demo via Chat

```
Implement the simplest possible end-to-end demo: control an LED on the ESP32 by sending a reflex from the Jetson via the chat interface. This proves the entire stack works.

Create/update these files:

1. nexus_cognitive/chat_interface.py — Simple command-line chat that accepts natural language and routes to handlers
2. nexus_cognitive/demo.py — End-to-end demo script

CHAT_INTERFACE.PY:
Simple command-line interface that:
- Accepts text input from the user
- Has a built-in intent router (no LLM needed for demo):
  - "blink led <interval_ms>" -> generates LED blinker reflex JSON, deploys via reflex_orchestrator
  - "stop led" -> removes LED reflex
  - "status" -> queries all node statuses
  - "help" -> shows available commands
- Uses node_manager to find connected nodes
- Uses reflex_orchestrator to deploy/remove reflexes
- Logs all actions

LED BLINKER REFLEX (generate this in code):
{
  "name": "led_blinker",
  "version": "1.0.0",
  "priority": 10,
  "tick_rate_hz": 1,
  "variables": {
    "state": {"type": "float32", "initial": 0.0},
    "last_toggle": {"type": "float32", "initial": 0.0}
  },
  "sensors": {
    "timer": {"reg": 60, "type": "float32", "unit": "ms"}
  },
  "actuators": {
    "led": {"reg": 0, "min": 0.0, "max": 1.0, "safe": 0.0}
  },
  "code": "READ_PIN timer; READ_PIN state; SUB_F; PUSH_I16 500; LTE_F; JUMP_IF_TRUE skip; WRITE_PIN led 1.0; SET_STATE 1.0; JMP done; skip: WRITE_PIN led 0.0; SET_STATE 0.0; done: HALT"
}

DEMO.PY:
1. Initialize serial bridge (auto-detect ESP32)
2. Wait for DEVICE_IDENTITY
3. Send ROLE_ASSIGN: { "role": "led_controller", "pins": {"led": {"gpio": 2, "mode": "output", "safe_value": 0.0}} }
4. Wait for ROLE_ACK
5. Enter chat loop:
   - Print "NEXUS> " prompt
   - Read user input
   - Route to handler
   - If "blink led 500": compile reflex, deploy, confirm
   - If "status": query node, print telemetry
   - If "quit": stop all modules, exit

TESTING PROCEDURE:
1. Flash ESP32 with nexus_limb firmware from Prompts 1-6
2. Connect ESP32 GPIO2 to an LED (with appropriate current-limiting resistor)
3. Connect ESP32 to Jetson via USB-UART adapter
4. Run: python -m nexus_cognitive.demo
5. Type "blink led 500" — LED should start blinking at 1Hz
6. Type "status" — should show node is online, reflex is active
7. Type "blink led 200" — LED should blink faster at 5Hz
8. Type "stop led" — LED should turn off
9. Type "quit"

This is the milestone demo. If this works, the entire protocol stack is functional.
```

---

## Prompt 10: Trust Score and INCREMENTS Autonomy Manager

```
Implement the INCREMENTS autonomy framework: trust score computation and per-subsystem autonomy level management.

Reference spec: specs/safety/trust_score_algorithm_spec.md

Create/update nexus_cognitive/autonomy_manager.py:

TRUST SCORE FORMULA:
T(t+1) = T(t) + alpha_gain * (1 - T(t))       if evaluation is GOOD
T(t+1) = T(t) - alpha_loss * T(t)             if evaluation is BAD
T(t+1) = T(t)                                  if no evaluation

Parameters:
- alpha_gain = 0.002 (trust gained per good evaluation)
- alpha_loss = 0.05 (trust lost per bad evaluation)
- loss_gain_ratio = 25:1

AUTONOMY LEVELS:
LEVEL_0_MANUAL = 0      # Human has full control
LEVEL_1_ASSIST = 1      # System suggests, human approves
LEVEL_2_SEMI_AUTO = 2    # System executes, human can override
LEVEL_3_CONDITIONAL = 3  # Autonomous in defined conditions
LEVEL_4_HIGH = 4         # Autonomous in most conditions
LEVEL_5_FULL = 5         # Autonomous in all conditions

Thresholds (trust score required for level advancement):
- Level 0 -> 1: 0.3 (quick to get basic assist)
- Level 1 -> 2: 0.5
- Level 2 -> 3: 0.7
- Level 3 -> 4: 0.85
- Level 4 -> 5: 0.95

TIME ESTIMATES (at alpha_gain=0.002, one evaluation per minute):
- Level 3: ~120 days of continuous good evaluations
- Level 5: ~300 days

Class AutonomyManager:
- __init__(storage_path: str) — load trust state from SQLite
- evaluate(subsystem: str, is_good: bool) -> TrustUpdate:
  - Returns dataclass TrustUpdate(old_level, new_level, old_score, new_score, changed)
  - Persist to database
- get_trust_score(subsystem: str) -> float
- get_autonomy_level(subsystem: str) -> int
- get_all_subsystems() -> dict[str, SubsystemState]
- set_autonomy_level(subsystem: str, level: int, reason: str) -> None (admin override)
- override(subsystem: str, duration_ms: int) -> None (temporary override for testing)
- get_history(subsystem: str, limit: int) -> list[TrustEvent]

Class SubsystemState dataclass:
- subsystem: str
- trust_score: float (0.0 to 1.0)
- autonomy_level: int (0-5)
- total_evaluations: int
- good_evaluations: int
- bad_evaluations: int
- consecutive_good: int
- consecutive_bad: int
- last_evaluation_at: float (unix timestamp)
- level_reached_at: float
- created_at: float

Class TrustEvent dataclass:
- timestamp: float
- subsystem: str
- is_good: bool
- old_score: float
- new_score: float
- old_level: int
- new_level: int

DATABASE SCHEMA (SQLite):
CREATE TABLE subsystems (
    subsystem TEXT PRIMARY KEY,
    trust_score REAL NOT NULL DEFAULT 0.0,
    autonomy_level INTEGER NOT NULL DEFAULT 0,
    total_evaluations INTEGER NOT NULL DEFAULT 0,
    good_evaluations INTEGER NOT NULL DEFAULT 0,
    bad_evaluations INTEGER NOT NULL DEFAULT 0,
    consecutive_good INTEGER NOT NULL DEFAULT 0,
    consecutive_bad INTEGER NOT NULL DEFAULT 0,
    last_evaluation_at REAL,
    level_reached_at REAL,
    created_at REAL NOT NULL
);

CREATE TABLE trust_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp REAL NOT NULL,
    subsystem TEXT NOT NULL,
    is_good INTEGER NOT NULL,
    old_score REAL NOT NULL,
    new_score REAL NOT NULL,
    old_level INTEGER NOT NULL,
    new_level INTEGER NOT NULL,
    FOREIGN KEY (subsystem) REFERENCES subsystems(subsystem)
);

TESTS (test_trust_score.py):
- Test trust gain from 0.0: verify alpha_gain=0.002
- Test trust loss from 1.0: verify alpha_loss=0.05
- Test 25:1 ratio: 1 bad event after 25 good events should return to approximately the same score
- Test level advancement thresholds: trust scores 0.3, 0.5, 0.7, 0.85, 0.95
- Test consecutive bad events: 2 bad events from 0.9 should drop to ~0.81
- Test database persistence: save, reload, verify exact values
- Test concurrent subsystems: steering and throttle evolve independently
- Test that 300+ consecutive good evaluations reaches level 5

Run tests: pytest tests/test_trust_score.py -v
```

---

## Prompt 11: MQTT Telemetry Bridge

```
Implement the MQTT telemetry bridge that bridges ESP32 telemetry data to dashboards and cloud services.

Reference spec: specs/jetson/mqtt_topics.json

Update nexus_cognitive/mqtt_bridge.py:

TOPIC DEFINITIONS (from spec):
- nexus/telemetry/{node_id}       QoS 0, No retain,  N2J
- nexus/status/{node_id}          QoS 1, Yes retain, N2J
- nexus/safety/{node_id}           QoS 2, No retain,  N2J
- nexus/autonomy/{subsystem}/level QoS 1, Yes retain, J2N
- nexus/autonomy/{subsystem}/override QoS 2, Yes retain, J2N
- nexus/heartbeat/{node_id}        QoS 0, No retain, N2J
- nexus/diagnostic/{node_id}      QoS 0, No retain,  Both

Class MQTTBridge:
- __init__(broker: str, port: int, client_id: str)
- async connect() — connect to broker, set up Last Will for safety
- async disconnect() — clean disconnect
- async publish_telemetry(node_id: str, data: dict) — publish to nexus/telemetry/{node_id}
- async publish_safety_event(node_id: str, event: dict) — publish to nexus/safety/{node_id} (QoS 2!)
- async publish_heartbeat(node_id: str) — publish to nexus/heartbeat/{node_id}
- async publish_status(node_id: str, status: dict) — publish retained status
- async publish_autonomy_level(subsystem: str, level: int) — publish retained
- async subscribe_override(callback) — subscribe to nexus/autonomy/+/override (QoS 2)
- async subscribe_telemetry(callback) — subscribe to nexus/telemetry/+
- async message_handler(topic, message) — internal dispatch
- on_telemetry_callback = None  — set by external code
- on_safety_event_callback = None

TELEMETRY DATA FORMATTING:
- Convert ESP32 telemetry JSON to MQTT payload
- Add metadata: received_at timestamp, node_id
- Handle rate limiting: don't publish faster than configured rate

SAFETY EVENT HANDLING:
- Safety events are QoS 2 (exactly-once delivery) — MUST NOT be lost
- If MQTT connection is down, queue safety events and retry
- On reconnect, flush queued safety events

RETAINED MESSAGES:
- Status and autonomy level messages are retained
- On broker restart, retained messages provide current state to new subscribers
- This is critical: a dashboard that connects late still gets current status

HEARTBEAT BRIDGING:
- Subscribe to ESP32 heartbeats via serial bridge
- Republish to MQTT for dashboards
- Track last heartbeat time per node
- Publish node-online/node-offline status changes

INTEGRATION:
- MQTTBridge is a NexusModule (subclass nexus_module.py)
- start() connects to broker, subscribes to topics
- stop() disconnects cleanly
- health_check() verifies connection is alive
- resource_budget() reports CPU/RAM usage

Write tests that verify:
- Connection and disconnection
- Message publish and subscribe
- Retained message behavior
- Safety event queuing when disconnected
- Heartbeat timeout detection
```

---

## Prompt 12: Chat Interface with LLM Integration

```
Implement the conversational chat interface that allows operators to describe intent in natural language and have the system generate reflex proposals.

Reference spec: specs/jetson/learning_pipeline_spec.md (Section 3 on narration processing)

Update nexus_cognitive/chat_interface.py:

CLASS ChatInterface(NexusModule):
- __init__(llm_api_url: str = None, llm_api_key: str = None)
- async send_message(user_message: str) -> ChatResponse
- async get_history(limit: int) -> list[ChatMessage]
- async set_mode(mode: str)  # "command", "chat", "demonstration"

INTENT ROUTING (no LLM needed for basic intents):
When the user sends a message, classify the intent:
1. "deploy <description>" or "make <description>" -> INTENT_DEPLOY_REFLEX
2. "remove <reflex_name>" or "stop <reflex_name>" -> INTENT_REMOVE_REFLEX
3. "status" or "how is <node>" -> INTENT_STATUS
4. "what happened" or "show events" -> INTENT_EVENT_LOG
5. "learn from <duration>" or "start recording" -> INTENT_START_OBSERVATION
6. "test <reflex_name>" -> INTENT_A_B_TEST
7. "help" -> INTENT_HELP
8. Everything else -> INTENT_GENERAL_CHAT (routes to LLM)

LLM INTEGRATION (for INTENT_GENERAL_CHAT):
- Uses z-ai-web-dev-sdk for local inference:
  import ZAI from 'z-ai-web-dev-sdk'
  const zai = await ZAI.create()
  const completion = await zai.chat.completions.create({
    messages: [
      { role: "system", content: "You are the NEXUS platform assistant. Help the operator manage their robotics system. You can deploy reflexes, check status, explain system behavior." },
      { role: "user", content: user_message }
    ]
  })

NOTE: z-ai-web-dev-sdk is a Node.js package. Create a thin wrapper:
  nexus_cognitive/llm_service.py — Node.js script invoked via subprocess
  OR use the Python subprocess bridge to call Node.js

ALTERNATIVE: Use the local Qwen2.5-Coder-7B model via llama-cpp-python:
  from llama_cpp import Llama
  model = Llama("/path/to/qwen2.5-coder-7b-instruct-q4_k_m.gguf")
  response = model("user prompt here", max_tokens=2048)

SYSTEM PROMPT for reflex generation:
```
You are an expert embedded systems engineer. Generate a NEXUS reflex definition in JSON format.
The reflex controls a microcontroller that reads sensors and drives actuators.

Available sensors (referenced by register index 0-63):
{sensor_list_from_node}

Available actuators (referenced by register index 0-63):
{actuator_list_from_node}

The reflex JSON must have this exact schema:
{
  "name": "descriptive_name",
  "version": "1.0.0",
  "priority": 10,
  "tick_rate_hz": 10,
  "variables": {},
  "sensors": {},
  "actuators": {},
  "pid_controllers": {},
  "code": "instruction1; instruction2; ..."
}

Available instructions: READ_PIN <sensor_name>, WRITE_PIN <actuator_name> <value>, 
PUSH_F32 <value>, PUSH_I16 <value>, PID_COMPUTE <pid_name>, CLAMP_F <lo> <hi>,
JUMP_IF_FALSE <label>, JUMP <label>, SET_STATE <state_name>, HALT

Generate ONLY valid JSON. No explanations outside the JSON.
```

SAFETY-TO-CHAT MESSAGES:
When a safety event occurs, the chat interface should proactively notify the operator:
- "SAFETY: Kill switch activated on node <id>. All actuators deactivated."
- "SAFETY: Overcurrent detected on channel <name>. Output disabled."
- "SAFETY: Heartbeat lost from node <id>. Entering safe-state."

DEMONSTRATION MODE:
- When the user narrates while performing an action (e.g., "I'm throttling up before the turn because I need rudder authority"):
  - Record the narration text with a timestamp
  - Record all sensor/actuator values at that moment
  - Store as a demonstration event for the learning pipeline
  - Later, the pattern discovery engine will correlate narration with sensor data

ChatResponse dataclass:
- message: str (the response text)
- intent: str (classified intent)
- reflex_proposal: Optional[dict] (if intent was to deploy, the generated JSON)
- requires_approval: bool

TESTS:
- Test intent routing for all 8 intent types
- Test reflex JSON generation for known patterns
- Test chat history retrieval
- Test safety event notifications
- Test demonstration narration recording
```

---

## Prompt 13: Observation Pipeline — Recording, Storage, Dump

```
Implement the observation data pipeline: record sensor data on ESP32, transfer to Jetson, store in Parquet files.

Reference spec: specs/jetson/learning_pipeline_spec.md (Section 1)

OBSERVATION DATA MODEL (Python dataclass, on Jetson side):
@dataclass(frozen=True)
class UnifiedObservation:
    timestamp_ns: int
    session_id: str
    sequence_number: int
    # GPS
    gps_latitude: float; gps_longitude: float; gps_speed_m_s: float
    gps_heading_deg: float; gps_hdop: float; gps_sat_count: int
    # IMU
    imu_roll_deg: float; imu_pitch_deg: float; imu_yaw_deg: float
    imu_accel_x_m_s2: float; imu_accel_y_m_s2: float; imu_accel_z_m_s2: float
    imu_gyro_x_deg_s: float; imu_gyro_y_deg_s: float; imu_gyro_z_deg_s: float
    # Environment
    wind_speed_m_s: float; wind_direction_deg: float; air_temp_c: float; water_temp_c: float
    barometric_hpa: float; humidity_pct: float; wave_height_m: float
    # Propulsion
    throttle_pct: float; rudder_angle_deg: float; engine_rpm: float; fuel_flow_L_h: float
    # System Health
    cpu_usage_pct: float; core_temp_c: float; trust_score: float; autonomy_level: int
    # Autonomy
    active_mode: str; active_reflex_id: str; pilot_present: bool; override_active: bool

ESP32 SIDE — Observation recording (add to main/components/nexus_protocol/):
- OBS_RECORD_START (0x0B): Start recording sensor data to PSRAM ring buffer
  - Payload JSON: {"sample_rate_hz": 100, "channels": [0, 1, 2, ...], "max_duration_s": 1800}
  - Allocate PSRAM ring buffer for observation frames
  - 32-byte observation frame format:
    - uint8 frame_type (0x01=standard, 0x02=delta, 0x03=event)
    - uint24 sequence_id (rolling frame counter)
    - uint32 timestamp_ms (time since recording start)
    - uint16 channel_mask (bitmask of active channels)
    - int16[7] channel_data (packed sensor readings, max 7 per frame)
    - uint16 flags
    - uint16 delta_base (for delta encoding)
    - uint32 frame_crc (CRC-32 of bytes 0-27)
- OBS_RECORD_STOP (0x0C): Stop recording, prepare for transfer
  - Payload JSON: {"finalize": true}
- OBS_DUMP_HEADER (0x0D): Metadata before dump
  - Payload JSON: {"total_chunks": N, "sample_rate_hz": 100, "total_frames": M, "duration_s": T, "channels": [...], "checksum": "sha256_of_all_data"}
- OBS_DUMP_CHUNK (0x0E): Binary chunk of observation data
  - Binary payload: 520 bytes per chunk (4-byte chunk_index + 2-byte chunk_size + 2-byte total_chunks + 512 bytes data)
- OBS_DUMP_END (0x0F): End of dump, CRC-32 of concatenated chunk data

JETSON SIDE — Observation management (nexus_cognitive/observation_manager.py):

Class ObservationSession:
- __init__(vessel_id: str, tags: list[str] = None)
- record(observation: UnifiedObservation) -> None
  - Append to in-memory Arrow table
  - Flush to Parquet every 1 second or 10,000 rows
- pause() / resume() / close()
  - On close: flush, write metadata sidecar, compute column statistics, register in session index

Class ObservationManager:
- __init__(data_dir: str)
- start_session(vessel_id, tags) -> ObservationSession
- get_session(session_id) -> ObservationSession
- list_sessions(limit, tags) -> list[SessionSummary]
- export_session(session_id, format="parquet") -> str (file path)
- cleanup_old_sessions() -> int (deleted count)

STORAGE FORMAT:
- Parquet files with Snappy compression (hot) or ZSTD level 3 (warm)
- Partitioned by hour: /data/nexus/hot/{session_id}/hour={YYYYMMDDHH}.parquet
- Row group size: 100,000 rows (~2-5 MB)
- Retention: HOT 7 days, WARM 90 days, COLD 2 years, ARCHIVE delete

SERIAL BRIDGE INTEGRATION:
- When OBS_DUMP_CHUNK messages arrive, reassemble binary data
- Write directly to Parquet on disk
- Track progress: chunks_received / total_chunks
- On OBS_DUMP_END, verify overall CRC-32

Write tests:
- Test observation session creation and recording
- Test Parquet file creation with correct schema
- Test session listing and filtering
- Test retention cleanup
- Test binary chunk reassembly
- Test CRC-32 verification on dump completion
```

---

## Prompt 14: Pattern Discovery Engine

```
Implement the pattern discovery engine that analyzes observation data to find behavioral patterns.

Reference spec: specs/jetson/learning_pipeline_spec.md (Section 2)

Create nexus_cognitive/pattern_discovery.py with 5 discovery algorithms:

1. CROSS-CORRELATION SCANNER:
def cross_correlation_scan(
    session_data: pd.DataFrame,
    sensor_columns: list[str],
    actuator_columns: list[str],
    max_lag_s: float = 60.0,
    lag_resolution_ms: float = 100.0,
    threshold_r: float = 0.6,
    min_overlap: float = 0.5,
) -> list[CorrelationRecord]:
    - Scan all pairs (A, B) using scipy.signal.correlate
    - Resample both columns to uniform 100ms grid
    - Find argmax |r(lag)| in [-60s, +60s]
    - Compute Bonferroni-corrected p-value
    - Return sorted list of significant correlations

2. CHANGE-POINT DETECTION (BOCPD):
def bocpd_detect(
    series: np.ndarray,
    timestamps: np.ndarray,
    sensor_name: str,
    hazard_lambda: float = 0.01,
    run_length_threshold: int = 100,
) -> list[ChangePoint]:
    - Implement Adams & MacKay (2007) Bayesian Online Change Point Detection
    - Normal-Inverse-Gamma conjugate priors
    - Report change points with confidence > 0.5
    - Run per-column in parallel (ThreadPoolExecutor, 4 workers)

3. BEHAVIORAL CLUSTERING (HDBSCAN):
def behavioral_clustering(
    session_data: pd.DataFrame,
    window_seconds: float = 10.0,
    hdbscan_min_cluster_size: int = 10,
) -> list[BehaviorCluster]:
    - Extract 40 features per 10-second window (8 sensors x 5 stats: mean, std, min, max, spectral centroid)
    - Normalize with RobustScaler
    - Reduce to 5 PCA components (keep >=85% variance)
    - Cluster with HDBSCAN(metric='euclidean', min_cluster_size=10, min_samples=3)
    - Characterize each cluster with typical sensor values and temporal pattern

4. TEMPORAL PATTERN MINING:
def mine_temporal_patterns(
    session_data: pd.DataFrame,
    event_definitions: list[str] = None,
    consistency_threshold: float = 0.6,
    min_occurrences: int = 5,
) -> list[TemporalRule]:
    - Parse event definition language (variable comparator threshold AND ...)
    - Detect event occurrences in data
    - Extract actuator response sequences after each event
    - Cluster similar responses using DTW distance + Ward linkage
    - Report rules with > 60% consistency across > 5 occurrences

5. BAYESIAN REWARD INFERENCE:
def compute_reward_inference(
    session_data: pd.DataFrame,
    target_speed: float = None,
    target_heading: float = None,
) -> RewardWeights:
    - Compute 6 reward features: speed_comfort, heading_accuracy, fuel_efficiency, smoothness, safety_margin, wind_compensation
    - Each feature normalized to [0, 1]
    - Use MAP estimation with Normal-Inverse-Gamma priors
    - Return weights + interpretation (human-readable explanation of what the human optimizes for)

Class PatternDiscovery:
- __init__(data_dir: str)
- async analyze_session(session_id: str) -> PatternDiscoveryResult
- get_cross_correlations(session_id) -> list[CorrelationRecord]
- get_change_points(session_id) -> list[ChangePoint]
- get_behavior_clusters(session_id) -> list[BehaviorCluster]
- get_temporal_rules(session_id) -> list[TemporalRule]
- get_reward_weights(session_id) -> RewardWeights

Write tests:
- Test cross-correlation with known sinusoidal signals
- Test BOCPD with step function
- Test behavioral clustering with synthetic behavior data
- Test temporal rule mining with known event-response patterns
- Test reward inference with known preference weights
```

---

## Prompt 15: A/B Testing Framework

```
Implement the A/B testing framework for validating proposed reflexes against human baselines.

Reference spec: specs/jetson/learning_pipeline_spec.md (Section 4)

Create nexus_cognitive/ab_testing.py:

7 STANDARDIZED METRICS:
| Metric | Computation | Target |
|--------|-----------|--------|
| heading_rmse | RMSE of heading error vs target | Lower is better |
| comfort_score | 1 - RMS(jerk) / max_jerk | Higher is better |
| fuel_efficiency | distance / fuel_consumed | Higher is better |
| safety_margin | min(obstacle_distance) / 100 | Higher is better, threshold 10m |
| smoothness | -RMS(jerk_heave) normalized | Higher is better |
| override_frequency | human overrides per hour | Lower, threshold 2/hr |
| response_latency | mean time from event to correction | Lower is better |

STATISTICAL SIGNIFICANCE:
- Paired t-test with Bonferroni correction for 7 metrics
- Significance threshold: p < 0.007 (0.05 / 7)
- Minimum baseline duration: 30 minutes
- Minimum treatment duration: 30 minutes
- Minimum sample size: 30 data points per phase

Class ABTest:
- __init__(test_id: str, reflex_name: str, node_id: str, baseline_duration_min: float = 30, treatment_duration_min: float = 30)
- start_baseline() -> None: begin recording human-operated data
- end_baseline() -> None: stop recording, compute baseline metrics
- start_treatment(reflex_json: dict) -> None: deploy reflex, record data alongside
- end_treatment() -> None: stop reflex, compute treatment metrics
- get_results() -> ABTestResult:
  - Compare metrics: baseline_mean, treatment_mean, delta, p_value, significant
  - Overall recommendation: ACCEPT / REJECT / INCONCLUSIVE
  - Acceptance criteria: treatment not significantly worse on ANY safety metric AND significantly better on at least ONE efficiency metric

Class ABTestResult:
- test_id: str
- reflex_name: str
- baseline_metrics: dict[str, MetricResult]
- treatment_metrics: dict[str, MetricResult]
- comparisons: dict[str, MetricComparison]
- overall_decision: str  # "ACCEPT", "REJECT", "INCONCLUSIVE"
- explanation: str  # Human-readable explanation of the decision
- timestamp: float

Class MetricResult:
- name: str
- mean: float
- std: float
- min: float
- max: float
- count: int
- unit: str

Class ABTestManager:
- __init__(storage_dir: str)
- create_test(reflex_name, node_id, config) -> ABTest
- get_test(test_id) -> ABTest
- list_tests(status_filter=None) -> list[ABTestSummary]
- get_test_results(test_id) -> ABTestResult

Write tests:
- Test with synthetic data where treatment is clearly better
- Test with synthetic data where treatment is clearly worse
- Test with inconclusive data (too few samples)
- Test metric computation (heading_rmse, comfort_score, etc.)
- Test statistical significance with Bonferroni correction
- Test acceptance criteria logic
```

---

## Prompt 16: Cloud Code Generation Pipeline

```
Implement the cloud code generation pipeline that uses LLMs to generate reflex proposals from natural language descriptions.

Reference spec: specs/jetson/learning_pipeline_spec.md (Sections 3 and 5)

Create nexus_cognitive/code_generator.py:

6-STAGE PIPELINE:
1. Intent capture — parse user's natural language description
2. Intent classification — determine if request is reflex generation, query, or other
3. Code generation — LLM generates JSON reflex definition
4. Safety validation — separate LLM reviews for safety violations
5. Simulation — simulate against recorded observation data
6. Human approval — present explanation to operator

Class CodeGenerator(NexusModule):
- __init__(local_model_path: str = None, cloud_api_url: str = None, cloud_api_key: str = None)
- async generate_reflex(description: str, sensor_list: list, actuator_list: list) -> ReflexProposal
- async validate_safety(reflex_json: dict, safety_policy: dict) -> SafetyValidationResult
- async simulate_reflex(reflex_json: dict, observation_session_id: str) -> SimulationResult
- async request_approval(proposal: ReflexProposal) -> ApprovalResult

SAFETY VALIDATION:
- Parse reflex JSON, extract all WRITE_PIN targets
- Check against safety_policy.json rules:
  - No actuator can exceed its defined max value
  - No actuator can change faster than rate limit
  - No reflex can bypass kill switch
  - All PID controllers must have anti-windup
  - All actuators must have safe values defined
- Use a DIFFERENT LLM call for validation (prevent self-validation bias)
- Validation prompt includes the safety rules as a system prompt constraint

SIMULATION:
- Load historical observation data from an ObservationSession
- Replay sensor data through the reflex bytecode (emulate VM execution in Python)
- Compute simulated actuator outputs
- Compare against actual human actuator outputs
- Metrics: RMSE of difference, max deviation, percentage of time within safe bounds

Class ReflexProposal:
- reflex_json: dict  # The generated reflex JSON
- explanation: str  # Human-readable explanation of what the reflex does
- sensor_requirements: list[str]  # Which sensors this reflex needs
- actuator_requirements: list[str]  # Which actuators this reflex controls
- risk_level: str  # "LOW", "MEDIUM", "HIGH"
- validation_passed: bool

Class SafetyValidationResult:
- passed: bool
- violations: list[str]  # List of safety rule violations
- suggestions: list[str]  # Suggested fixes
- risk_assessment: str

Class SimulationResult:
- duration_s: float
- frames_simulated: int
- output_rmse: float
- max_deviation: float
- within_safe_bounds_pct: float
- notes: str

CLOUD FALLBACK:
- If cloud LLM is unavailable (Starlink timeout, API error):
  - Fall back to local model (Qwen2.5-Coder-7B via llama-cpp-python)
  - Log warning about degraded quality
  - Still perform safety validation
- Queue-and-forward for delayed cloud responses

SEPARATE LLM FOR VALIDATION (critical design principle):
- NEVER use the same LLM call for generation and validation
- Generation prompt: "Generate a reflex that does X..."
- Validation prompt: "Review this reflex for safety violations. Rules: [...]. Does it violate any?"
- The $0.01-0.03 per validation call cost is negligible compared to deploying unsafe code

Write tests:
- Test code generation with a simple description
- Test safety validation catches actuator over-speed
- Test safety validation catches missing safe values
- Test simulation with synthetic observation data
- Test cloud fallback when cloud is unavailable
- Test that separate validation catches self-validation bias
```

---

## Prompt 17: Integration Testing and Final Verification

```
Implement the comprehensive integration test suite for the entire NEXUS platform.

Create nexus_cognitive/tests/integration/:

1. test_full_boot_sequence.py:
   - Start serial bridge, wait for DEVICE_IDENTITY
   - Send ROLE_ASSIGN with a known configuration
   - Verify ROLE_ACK response
   - Send HEARTBEAT, verify no error
   - Send PING, verify PONG with correct RTT
   - Measure boot-to-operational time (target < 500ms)

2. test_reflex_deployment_flow.py:
   - Deploy a simple counter reflex via REFLEX_DEPLOY
   - Query status via REFLEX_STATUS
   - Deploy an updated version (same name, higher version)
   - Verify old version is replaced
   - Remove reflex, verify REFLEX_STATUS shows empty

3. test_observation_pipeline.py:
   - Send OBS_RECORD_START
   - Let recording run for 5 seconds
   - Send OBS_RECORD_STOP
   - Request OBS_DUMP_HEADER
   - Receive OBS_DUMP_CHUNK messages
   - Verify OBS_DUMP_END with matching CRC-32
   - Verify Parquet file created with correct schema

4. test_heartbeat_escalation.py:
   - Start heartbeat monitor
   - Stop sending heartbeats
   - Verify WARN state at 500ms (5 missed)
   - Verify DEGRADED state at 1000ms (10 missed)
   - Resume heartbeats
   - Verify recovery to NORMAL

5. test_trust_score_advancement.py:
   - Create a fresh subsystem
   - Feed 100 consecutive GOOD evaluations
   - Verify trust score advances
   - Feed 5 BAD evaluations
   - Verify trust score drops appropriately
   - Verify autonomy level changes at thresholds

6. test_ab_test_workflow.py:
   - Start baseline recording for 30 seconds
   - Deploy a treatment reflex
   - Run treatment for 30 seconds
   - Compute comparison metrics
   - Verify acceptance/rejection decision

7. test_safety_interlock.py:
   - If hardware kill switch is available: test physical kill switch response
   - If not: simulate by sending SAFETY_EVENT message
   - Verify system enters safe state
   - Verify all actuators at safe position
   - Verify recovery requires explicit RESUME

TEST RUNNER:
Create nexus_cognitive/tests/run_integration.py:
- Runs all integration tests in sequence
- Produces JUnit XML report
- Skips tests that require hardware (ESP32 connected) if not available
- Prints summary: X passed, Y failed, Z skipped

Run: pytest tests/integration/ -v --tb=short
```

---

## Prompt 18: Project README and Deployment Documentation

```
Create comprehensive documentation for the NEXUS platform.

Create these files at the repo root:

README.md:
- Project overview: what NEXUS is, post-coding platform for industrial robotics
- Architecture diagram (ASCII art showing 3-tier architecture)
- Quick start guide: flash ESP32, install Jetson package, run demo
- Directory structure for both firmware and cognitive layers
- Hardware requirements with links to compatibility matrix
- Configuration reference (all JSON config files with descriptions)
- Contributing guide: code style, testing requirements, PR process
- License information

DEPLOYMENT.md:
- ESP32 firmware flashing procedure
- Jetson package installation (pip install -e .)
- MQTT broker setup (Mosquitto for single-vessel, EMQX for fleet)
- Production deployment checklist:
  1. Flash factory firmware to all ESP32 nodes
  - 2. Wire RS-422 connections
   - 3. Configure MQTT broker with security (TLS, authentication)
  - 4. Configure JSON config for each node role
  - 5. Test kill switch on every node
  - 6. Run full integration test suite
  - 7. Enable observation recording
  - 8. Perform initial 30-minute calibration recording
  - 9. Run first A/B test
  - 10. Deploy to production
- OTA update procedure
- Backup and recovery procedures
- Monitoring and alerting setup

DOCKER-COMPOSE (for Jetson services):
- Mosquitto MQTT broker
- InfluxDB for time-series telemetry storage
- Grafana dashboard (pre-configured panels for telemetry, safety, trust scores)
- NEXUS cognitive service (all modules in one container)

GRAFANA DASHBOARD CONFIGURATION:
- Panel 1: Real-time sensor telemetry (line charts)
- Panel 2: Safety events timeline (table with color-coded severity)
- Panel 3: Trust score progression per subsystem (gauge charts)
- Panel 4: Active reflexes and their status
- Panel 5: Observation recording status
- Panel 6: Heartbeat connectivity map
- Panel 7: A/B test results

CONFIGURATION FILES (create example configs):
- config/roles/led_controller.json
- config/roles/autopilot_controller.json
- config/roles/sensor_hub.json
- config/safety/safety_policy.json
- config/safety/actuator_profiles.json

Write the README with installation commands for:
- ESP-IDF v5.2+ setup
- Python 3.11+ with dependencies
- Docker Compose for services
- Pre-commit hooks (pytest on commit, clang-format for C code)

This should be the final prompt. After this, the platform is fully documented and ready for deployment.
```

---

## Appendix A: File Dependency Graph

```
PROMPT 1 (Project Scaffold)
    │
    v
PROMPT 2 (Wire Protocol)
    │
    v
PROMPT 3 (Safety System) ───────────── depends on Prompt 2
    │
    v
PROMPT 4 (Bytecode VM) ────────────────── depends on Prompt 2
    │
    v
PROMPT 5 (I/O Abstraction) ────────────── depends on Prompt 2
    │
    v
PROMPT 6 (Boot Integration) ───────────── depends on Prompts 2,3,4,5
    │
    ├──> ESP32 FIRMWARE COMPLETE (can be built and flashed)
    │
PROMPT 7 (Jetson Python Package) ── NEW PARALLEL TRACK
    │
    v
PROMPT 8 (Reflex Compiler) ────────────── depends on Prompt 7
    │
    v
PROMPT 9 (E2E LED Demo) ──────────────── depends on Prompts 6,7,8
    │
    ├──> MINIMUM VIABLE PRODUCT DEMO
    │
PROMPT 10 (Trust Score) ─────────────── depends on Prompt 7
PROMPT 11 (MQTT Bridge) ─────────────── depends on Prompt 7
PROMPT 12 (Chat Interface) ─────────── depends on Prompts 7,8,10
PROMPT 13 (Observation Pipeline) ─────── depends on Prompts 7,6
PROMPT 14 (Pattern Discovery) ──────── depends on Prompt 13
PROMPT 15 (A/B Testing) ─────────────── depends on Prompts 13,14
PROMPT 16 (Code Generation) ─────────── depends on Prompts 7,8,10
    │
    v
PROMPT 17 (Integration Tests) ───────── depends on ALL above
    │
    v
PROMPT 18 (Documentation) ────────────── depends on ALL above
    │
    ├──> PRODUCTION-READY PLATFORM
```

---

## Appendix B: Estimated Claude Code Session Times

| Prompt | Estimated Claude Code Time | Notes |
|--------|-------------------------|-------|
| 1. Project Scaffold | 3-5 minutes | Simple file creation |
| 2. Wire Protocol | 15-20 minutes | COBS, CRC, framing, 28 message types |
| 3. Safety System | 10-15 minutes | ISR, watchdog, heartbeat state machine |
| 4. Bytecode VM | 20-30 minutes | 32 opcodes, memory model, syscalls — most complex firmware component |
| 5. I/O Abstraction | 10-15 minutes | Driver vtable, 8 drivers |
| 6. Boot Integration | 5-10 minutes | Glue code, FreeRTOS tasks |
| 7. Jetson Python | 5-10 minutes | Package scaffold, serial protocol Python port |
| 8. Reflex Compiler | 10-15 minutes | JSON parsing, bytecode emission, validation |
| 9. E2E LED Demo | 5-10 minutes | Integration of all previous firmware + Jetson code |
| 10. Trust Score | 5-8 minutes | Formula, SQLite, thresholds |
| 11. MQTT Bridge | 5-8 minutes | Topic definitions, QoS, retained messages |
| 12. Chat Interface | 10-15 minutes | Intent routing, LLM integration, narration |
| 13. Observation Pipeline | 8-12 minutes | Binary frames, Parquet, retention |
| 14. Pattern Discovery | 15-25 minutes | 5 ML algorithms — most complex Jetson code |
| 15. A/B Testing | 8-12 minutes | Metrics, statistics, decision logic |
| 16. Code Generation | 10-15 minutes | LLM calls, safety validation, simulation |
| 17. Integration Tests | 10-15 minutes | 7 test scenarios |
| 18. Documentation | 8-12 minutes | README, deployment, Docker, Grafana |
| **TOTAL** | **~200-300 minutes** | **3-5 full Claude Code sessions** |

---

## Appendix C: Minimum Claude Code Setup

Claude Code needs these settings for best results:

1. **Model**: Use Claude 3.7 Sonnet or better (Opus for complex prompts like 4, 14, 16)
2. **Context window**: 200K tokens minimum (the bytecode VM spec alone is ~2500 lines)
3. **Auto-accept**: Enable for build commands (`idf.py build`, `pip install`, `pytest`)
4. **Allowed tools**: Full file system access, terminal commands, web access for spec lookups
5. **Working directory**: Must be the repo root where specs/ directory is located
6. **Skip prompts for hardware-dependent tests**: Prompts 17 tests that require a physical ESP32 connected can be run with `--hw-available` flag

```bash
# Start Claude Code from the repo root:
cd /path/to/nexus-platform
claude --model claude-sonnet-4-20250514

# Verify spec files are accessible:
ls specs/protocol/wire_protocol_spec.md
ls specs/firmware/reflex_bytecode_vm_spec.md
ls specs/safety/safety_system_spec.md
ls specs/jetson/module_interface.py
ls specs/jetson/learning_pipeline_spec.md
```
