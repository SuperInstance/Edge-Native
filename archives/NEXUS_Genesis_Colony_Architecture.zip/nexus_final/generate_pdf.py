#!/usr/bin/env python3
"""Generate NEXUS Platform Final Synthesis PDF Report."""

import os
from reportlab.lib.pagesizes import letter
from reportlab.lib.units import inch, mm
from reportlab.lib.colors import HexColor, white, black
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.enums import TA_JUSTIFY, TA_LEFT, TA_CENTER, TA_RIGHT
from reportlab.platypus import (
    BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer,
    Table, TableStyle, PageBreak, KeepTogether, NextPageTemplate,
    Flowable, HRFlowable
)
from reportlab.platypus.tableofcontents import TableOfContents
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas

# ─── Paths ───
OUTPUT_PATH = "/home/z/my-project/download/nexus_final/NEXUS_Platform_Final_Synthesis.pdf"
TNR_PATH = "/usr/share/fonts/truetype/english/Times-New-Roman.ttf"
DJS_PATH = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"

# ─── Colors ───
DARK_BLUE = HexColor("#1F4E79")
LIGHT_GRAY = HexColor("#F5F5F5")
ACCENT_BLUE = HexColor("#2E75B6")
MEDIUM_BLUE = HexColor("#5B9BD5")
DARK_TEXT = HexColor("#333333")
COVER_BG = HexColor("#1F4E79")
COVER_ACCENT = HexColor("#2E75B6")

# ─── Page Dimensions ───
PAGE_W, PAGE_H = letter
MARGIN_L = 0.9 * inch
MARGIN_R = 0.9 * inch
MARGIN_T = 0.85 * inch
MARGIN_B = 0.85 * inch
CONTENT_W = PAGE_W - MARGIN_L - MARGIN_R

# ─── Register Fonts ───
pdfmetrics.registerFont(TTFont("TimesNewRoman", TNR_PATH))
pdfmetrics.registerFont(TTFont("DejaVuSans", DJS_PATH))
from reportlab.pdfbase.pdfmetrics import registerFontFamily
registerFontFamily("TimesNewRoman", normal="TimesNewRoman", bold="TimesNewRoman", italic="TimesNewRoman", boldItalic="TimesNewRoman")
registerFontFamily("DejaVuSans", normal="DejaVuSans", bold="DejaVuSans", italic="DejaVuSans", boldItalic="DejaVuSans")

# ─── Styles ───
sBody = ParagraphStyle(
    "Body", fontName="TimesNewRoman", fontSize=10.5, leading=16,
    alignment=TA_JUSTIFY, textColor=DARK_TEXT, spaceAfter=6,
    firstLineIndent=0
)
sBodyIndent = ParagraphStyle(
    "BodyIndent", parent=sBody, leftIndent=18
)
sBullet = ParagraphStyle(
    "Bullet", fontName="TimesNewRoman", fontSize=10.5, leading=16,
    alignment=TA_JUSTIFY, textColor=DARK_TEXT, spaceAfter=4,
    leftIndent=24, bulletIndent=12, bulletFontSize=10.5,
    bulletFontName="TimesNewRoman"
)
sNumbered = ParagraphStyle(
    "Numbered", fontName="TimesNewRoman", fontSize=10.5, leading=16,
    alignment=TA_JUSTIFY, textColor=DARK_TEXT, spaceAfter=4,
    leftIndent=24, bulletIndent=12
)
sH1 = ParagraphStyle(
    "H1", fontName="TimesNewRoman", fontSize=18, leading=22,
    alignment=TA_LEFT, textColor=DARK_BLUE, spaceBefore=18, spaceAfter=10
)
sH2 = ParagraphStyle(
    "H2", fontName="TimesNewRoman", fontSize=14, leading=18,
    alignment=TA_LEFT, textColor=DARK_BLUE, spaceBefore=14, spaceAfter=8
)
sH3 = ParagraphStyle(
    "H3", fontName="TimesNewRoman", fontSize=12, leading=16,
    alignment=TA_LEFT, textColor=ACCENT_BLUE, spaceBefore=10, spaceAfter=6
)
sTableHeader = ParagraphStyle(
    "TableHeader", fontName="TimesNewRoman", fontSize=9, leading=12,
    alignment=TA_CENTER, textColor=white
)
sTableCell = ParagraphStyle(
    "TableCell", fontName="TimesNewRoman", fontSize=9, leading=12,
    alignment=TA_LEFT, textColor=DARK_TEXT
)
sTableCellCenter = ParagraphStyle(
    "TableCellCenter", fontName="TimesNewRoman", fontSize=9, leading=12,
    alignment=TA_CENTER, textColor=DARK_TEXT
)
sCodeBlock = ParagraphStyle(
    "CodeBlock", fontName="DejaVuSans", fontSize=7.5, leading=10,
    alignment=TA_LEFT, textColor=HexColor("#2D2D2D"),
    backColor=HexColor("#F8F8F8"), leftIndent=12, rightIndent=12,
    spaceBefore=6, spaceAfter=6, borderPadding=4
)
sCoverTitle = ParagraphStyle(
    "CoverTitle", fontName="TimesNewRoman", fontSize=28, leading=34,
    alignment=TA_CENTER, textColor=white
)
sCoverSubtitle = ParagraphStyle(
    "CoverSubtitle", fontName="TimesNewRoman", fontSize=16, leading=22,
    alignment=TA_CENTER, textColor=HexColor("#BDD7EE")
)
sCoverMeta = ParagraphStyle(
    "CoverMeta", fontName="TimesNewRoman", fontSize=11, leading=16,
    alignment=TA_CENTER, textColor=HexColor("#D6E4F0")
)
sTOCTitle = ParagraphStyle(
    "TOCTitle", fontName="TimesNewRoman", fontSize=20, leading=26,
    alignment=TA_LEFT, textColor=DARK_BLUE, spaceBefore=6, spaceAfter=18
)


# ─── TocDocTemplate ───
class TocDocTemplate(BaseDocTemplate):
    """Document template with auto-generated Table of Contents."""
    def __init__(self, filename, **kwargs):
        super().__init__(filename, **kwargs)
        self.page_count = 0
        self.toc_entries = []
        
        # Cover page frame (full page)
        cover_frame = Frame(0, 0, PAGE_W, PAGE_H, id="cover", leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)
        # TOC frame
        toc_frame = Frame(MARGIN_L, MARGIN_B, CONTENT_W, PAGE_H - MARGIN_T - MARGIN_B, id="toc")
        # Content frame
        content_frame = Frame(MARGIN_L, MARGIN_B, CONTENT_W, PAGE_H - MARGIN_T - MARGIN_B, id="content")

        self.addPageTemplates([
            PageTemplate(id="Cover", frames=[cover_frame], onPage=self._cover_page),
            PageTemplate(id="TOC", frames=[toc_frame], onPage=self._toc_page),
            PageTemplate(id="Content", frames=[content_frame], onPage=self._content_page),
        ])

    def _cover_page(self, canvas_obj, doc):
        pass  # Cover handled by flowables

    def _toc_page(self, canvas_obj, doc):
        canvas_obj.saveState()
        canvas_obj.setFillColor(DARK_BLUE)
        canvas_obj.rect(0, PAGE_H - 18, PAGE_W, 18, fill=1, stroke=0)
        canvas_obj.rect(0, 0, PAGE_W, 18, fill=1, stroke=0)
        canvas_obj.setFillColor(white)
        canvas_obj.setFont("TimesNewRoman", 8)
        canvas_obj.drawCentredString(PAGE_W / 2, 5, "NEXUS Platform - Final Production Synthesis Report")
        canvas_obj.drawCentredString(PAGE_W / 2, PAGE_H - 13, "NEXUS Platform - Final Production Synthesis Report")
        canvas_obj.restoreState()

    def _content_page(self, canvas_obj, doc):
        canvas_obj.saveState()
        # Header line
        canvas_obj.setStrokeColor(DARK_BLUE)
        canvas_obj.setLineWidth(0.5)
        canvas_obj.line(MARGIN_L, PAGE_H - MARGIN_T + 6, PAGE_W - MARGIN_R, PAGE_H - MARGIN_T + 6)
        canvas_obj.setFillColor(DARK_BLUE)
        canvas_obj.setFont("TimesNewRoman", 8)
        canvas_obj.drawString(MARGIN_L, PAGE_H - MARGIN_T + 10, "NEXUS Platform - Final Synthesis")
        canvas_obj.drawRightString(PAGE_W - MARGIN_R, PAGE_H - MARGIN_T + 10, "Version 1.0.0")
        # Footer line
        canvas_obj.line(MARGIN_L, MARGIN_B - 6, PAGE_W - MARGIN_R, MARGIN_B - 6)
        canvas_obj.setFont("TimesNewRoman", 8)
        canvas_obj.drawCentredString(PAGE_W / 2, MARGIN_B - 18, f"Page {doc.page}")
        canvas_obj.drawString(MARGIN_L, MARGIN_B - 18, "AI Architecture Team")
        canvas_obj.drawRightString(PAGE_W - MARGIN_R, MARGIN_B - 18, "2026-03-29")
        canvas_obj.restoreState()

    def afterFlowable(self, flowable):
        """Capture TOC entries from heading paragraphs."""
        if hasattr(flowable, "_bookmark_name"):
            key = flowable._bookmark_name
            text = flowable._bookmark_text
            level = flowable._bookmark_level
            self.canv.bookmarkPage(key)
            self.canv.addOutlineEntry(text, key, level, 0)
            self.toc_entries.append((level, text, self.page, key))


# ─── Heading Flowables with bookmark attributes ───
class Heading1(Paragraph):
    def __init__(self, text, bookmark_name, bookmark_text=None):
        self._bookmark_name = bookmark_name
        self._bookmark_level = 0
        self._bookmark_text = bookmark_text or text
        super().__init__(text, sH1)

class Heading2(Paragraph):
    def __init__(self, text, bookmark_name, bookmark_text=None):
        self._bookmark_name = bookmark_name
        self._bookmark_level = 1
        self._bookmark_text = bookmark_text or text
        super().__init__(text, sH2)

class Heading3(Paragraph):
    def __init__(self, text, bookmark_name, bookmark_text=None):
        self._bookmark_name = bookmark_name
        self._bookmark_level = 2
        self._bookmark_text = bookmark_text or text
        super().__init__(text, sH3)


# ─── Helper Functions ───
def body(text):
    return Paragraph(text, sBody)

def body_indent(text):
    return Paragraph(text, sBodyIndent)

def bullet(text):
    return Paragraph(text, sBullet, bulletText="•")

def numbered(text, num):
    return Paragraph(text, sNumbered, bulletText=str(num) + ".")

def code_block(text):
    safe = text.replace("&", "&").replace("<", "<").replace(">", ">").replace("\n", "<br/>")
    return Paragraph(safe, sCodeBlock)

def make_table(headers, rows, col_widths=None):
    """Create a styled table with Paragraph objects in all cells."""
    header_cells = [Paragraph(str(h), sTableHeader) for h in headers]
    data = [header_cells]
    for row in rows:
        data.append([Paragraph(str(c), sTableCell) for c in row])

    if col_widths is None:
        col_widths = [CONTENT_W / len(headers)] * len(headers)

    t = Table(data, colWidths=col_widths, repeatRows=1)
    style_cmds = [
        ("BACKGROUND", (0, 0), (-1, 0), DARK_BLUE),
        ("TEXTCOLOR", (0, 0), (-1, 0), white),
        ("FONTNAME", (0, 0), (-1, 0), "TimesNewRoman"),
        ("FONTSIZE", (0, 0), (-1, 0), 9),
        ("BOTTOMPADDING", (0, 0), (-1, 0), 6),
        ("TOPPADDING", (0, 0), (-1, 0), 6),
        ("ALIGN", (0, 0), (-1, 0), "CENTER"),
        ("FONTNAME", (0, 1), (-1, -1), "TimesNewRoman"),
        ("FONTSIZE", (0, 1), (-1, -1), 9),
        ("TOPPADDING", (0, 1), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 1), (-1, -1), 4),
        ("LEFTPADDING", (0, 0), (-1, -1), 5),
        ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("GRID", (0, 0), (-1, -1), 0.5, HexColor("#CCCCCC")),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [white, LIGHT_GRAY]),
    ]
    t.setStyle(TableStyle(style_cmds))
    return t

def spacer(h=6):
    return Spacer(1, h)

def thin_rule():
    return HRFlowable(width="100%", thickness=0.5, color=DARK_BLUE, spaceBefore=6, spaceAfter=6)


# ─── Build Document ───
def build_pdf():
    doc = TocDocTemplate(
        OUTPUT_PATH,
        pagesize=letter,
        title="NEXUS_Platform_Final_Synthesis",
        author="Z.ai",
        creator="Z.ai",
        subject="NEXUS Post-Coding Distributed Intelligence Platform Production Specification",
        leftMargin=MARGIN_L, rightMargin=MARGIN_R,
        topMargin=MARGIN_T, bottomMargin=MARGIN_B
    )

    story = []

    # ═══════════════ COVER PAGE ═══════════════
    story.append(CoverPage())
    story.append(NextPageTemplate("TOC"))
    story.append(PageBreak())

    # ═══════════════ TABLE OF CONTENTS ═══════════════
    toc = TableOfContents()
    toc.levelStyles = [
        ParagraphStyle("TOC0", fontName="TimesNewRoman", fontSize=11, leading=18, leftIndent=0, spaceBefore=4, spaceAfter=2, textColor=DARK_BLUE),
        ParagraphStyle("TOC1", fontName="TimesNewRoman", fontSize=10, leading=16, leftIndent=18, spaceBefore=2, spaceAfter=1, textColor=DARK_TEXT),
        ParagraphStyle("TOC2", fontName="TimesNewRoman", fontSize=9, leading=14, leftIndent=36, spaceBefore=1, spaceAfter=1, textColor=DARK_TEXT),
    ]
    story.append(Paragraph("Table of Contents", sTOCTitle))
    story.append(toc)
    story.append(NextPageTemplate("Content"))
    story.append(PageBreak())

    # ═══════════════ SECTION 1: EXECUTIVE SUMMARY ═══════════════
    story.append(Heading1("1. Executive Summary", "sec1"))
    story.append(body(
        "The NEXUS Platform is a production-ready specification for a <b>post-coding distributed intelligence system</b> "
        "designed for general-purpose industrial robotics. The platform eliminates the need for humans to write code. "
        "Instead, operators wire hardware, describe intent in natural language, demonstrate desired behaviors, and approve "
        "or reject AI-generated proposals. The system learns from observation, synthesizes reflexes, validates them through "
        "A/B testing, and progressively earns trust to operate with increasing autonomy."
    ))
    story.append(body(
        "The architecture is built on a two-tier hardware model: <b>ESP32-class microcontrollers</b> serve as universal "
        '"limbs" that directly interface with sensors and actuators, while <b>NVIDIA Jetson Orin Nano</b> boards serve as '
        'the "brains" that handle AI inference, pattern discovery, and cloud connectivity. The platform was designed from '
        "the ground up to be <b>hardware-agnostic</b> — any MCU meeting modest minimum specifications can serve as a limb, "
        "and the cognitive services can run on any Linux-capable edge computer."
    ))
    story.append(body(
        "This report synthesizes seven phases of iterative design work spanning marine autopilot engineering, vessel robotics "
        "platforms, and the final evolution to a general-purpose post-coding architecture. It presents 21 specification files "
        "totaling approximately 19,200 lines, 28 architecture decision records with confidence levels, a four-tier safety "
        "system compliant with IEC 61508 (SIL 1), and a complete build guide with effort estimates."
    ))
    story.append(spacer(4))

    story.append(Heading3("Key Design Numbers", "sec1_key"))
    story.append(make_table(
        ["Metric", "Value"],
        [
            ["Specification files", "21"],
            ["Total specification lines", "~19,200"],
            ["Architecture Decision Records", "28"],
            ["Wire protocol message types", "28"],
            ["Error codes defined", "75"],
            ["VM opcodes defined", "32 (fixed ISA)"],
            ["I2C drivers specified", "9+"],
            ["MCU compatibility evaluations", "13"],
            ["Estimated build effort (3 devs, parallel)", "12-16 weeks"],
            ["Fastest path to demo (LED reflex via chat)", "8 weeks"],
            ["Full autopilot with learning", "16 weeks"],
        ],
        col_widths=[CONTENT_W * 0.55, CONTENT_W * 0.45]
    ))
    story.append(spacer(8))

    # ═══════════════ SECTION 2: PLATFORM VISION ═══════════════
    story.append(Heading1("2. Platform Vision: The Post-Coding Age", "sec2"))
    story.append(Heading2("2.1 Core Premise", "sec2_1"))
    story.append(body(
        "In the NEXUS platform, <b>no human ever writes, reads, or debugs code</b>. Code is a hidden artifact — "
        "generated by AI, validated by a separate AI instance, tested in simulation, and deployed to hardware automatically. "
        "The human's role is limited to four activities:"
    ))
    for i, txt in enumerate([
        "<b>Wiring hardware</b> — physically connecting sensors, actuators, and power (the only manual technical task).",
        "<b>Describing intent</b> — telling the system what should happen using natural language, either through a chat interface or voice narration (e.g., 'When the wind exceeds 25 knots, reduce throttle to 40% and angle the trim tabs down 5 degrees').",
        "<b>Demonstrating behaviors</b> — performing an action while the system records sensor data and narrating the reasoning (e.g., 'I'm throttling up before turning into the wind because I need more rudder authority').",
        "<b>Approving or rejecting proposals</b> — the AI generates a proposed reflex based on observations, the human reviews it (presented as a natural-language explanation, not code), and approves or rejects it.",
    ], 1):
        story.append(numbered(txt, i))

    story.append(Heading2("2.2 The Learning Loop", "sec2_2"))
    story.append(body("The system's intelligence grows through a continuous cycle:"))
    story.append(code_block(
        "Observe Human Action\n"
        "       |\n"
        "       v\n"
        "Record Sensor Data + Narration\n"
        "       |\n"
        "       v\n"
        "Pattern Discovery (offline analysis)\n"
        "  - Cross-correlation scanning\n"
        "  - Change-point detection\n"
        "  - Behavioral clustering\n"
        "  - Temporal rule mining\n"
        "  - Bayesian reward inference\n"
        "       |\n"
        "       v\n"
        "Synthesize Reflex Proposal\n"
        "  - AI generates JSON state machine\n"
        "  - Compiled to bytecode for ESP32\n"
        "  - Separate LLM validates safety\n"
        "       |\n"
        "       v\n"
        "A/B Test Against Human Baseline\n"
        "  - Run proposed reflex alongside human\n"
        "  - Compare metrics (comfort, efficiency, safety)\n"
        "  - Statistical significance testing\n"
        "       |\n"
        "       v\n"
        "Human Approves or Rejects\n"
        "       |\n"
        "       v (if approved)\n"
        "Deploy to Production\n"
        "  - Trust score incremented\n"
        "  - Autonomy level may increase\n"
        "  - Reflex becomes default behavior"
    ))

    story.append(Heading2("2.3 Cross-Domain Applicability", "sec2_3"))
    story.append(body(
        "While the platform was originally designed for marine autopilot, the architecture is intentionally domain-agnostic. "
        "The same system can control:"
    ))
    for txt in [
        "<b>Marine vessels</b> — autopilot, engine management, bilge monitoring, anchor winch",
        "<b>Agricultural equipment</b> — irrigation, fertilization, harvest timing, greenhouse climate",
        "<b>HVAC systems</b> — zone control, predictive maintenance, energy optimization",
        "<b>Factory automation</b> — conveyor control, quality inspection, safety interlocks",
        "<b>Mining operations</b> — ventilation, pump control, environmental monitoring",
        "<b>Home automation</b> — lighting scenes, security responses, energy management",
    ]:
        story.append(bullet(txt))
    story.append(body(
        "Each domain is defined entirely by configuration (sensor types, actuator types, safety rules) and equipment "
        "templates — not by custom code."
    ))

    # ═══════════════ SECTION 3: SYSTEM ARCHITECTURE ═══════════════
    story.append(Heading1("3. System Architecture Overview", "sec3"))
    story.append(Heading2("3.1 Three-Tier Architecture", "sec3_1"))
    story.append(body(
        "The NEXUS platform operates across three tiers, each with distinct responsibilities and failure modes:"
    ))
    story.append(code_block(
        "+------------------------------------------------------------------+\n"
        "|                    TIER 3: CLOUD (Optional)                       |\n"
        "|  Heavy reasoning, simulation, training, fleet management          |\n"
        "|  Response: seconds to hours | Connectivity: Starlink/5G          |\n"
        "|  Authority: Can suggest but cannot command actuators directly     |\n"
        "+------------------------------------------------------------------+\n"
        "          |\n"
        "          v (via Starlink/5G, queue-and-forward)\n"
        "+------------------------------------------------------------------+\n"
        "|                    TIER 2: JETSON COGNITIVE LAYER                 |\n"
        "|  AI inference, pattern discovery, reflex orchestration, chat     |\n"
        "|  Response: 10-500ms | Connectivity: RS-422 serial, WiFi, MQTT    |\n"
        "|  Authority: Can deploy reflexes and send commands to limbs        |\n"
        "+------------------------------------------------------------------+\n"
        "          |\n"
        "          v (via RS-422 serial, 921600 baud)\n"
        "+------------------------------------------------------------------+\n"
        "|                    TIER 1: MCU REFLEX LAYER                       |\n"
        "|  Real-time control, sensor polling, safety enforcement            |\n"
        "|  Response: 10us-1ms | Connectivity: Direct GPIO, I2C, UART       |\n"
        "|  Authority: Executes reflexes; safety override is absolute        |\n"
        "+------------------------------------------------------------------+"
    ))
    story.append(body(
        "<b>Tier 1 (MCU Reflex Layer)</b> — ESP32-class microcontrollers run a universal firmware binary that executes "
        "compiled bytecode reflexes at 1kHz. These are the 'limbs' of the system — they read sensors, compute control "
        "outputs, and drive actuators. They operate independently of the Jetson and can maintain basic functionality "
        "(reflex-based control) even when all higher tiers fail."
    ))
    story.append(body(
        "<b>Tier 2 (Jetson Cognitive Layer)</b> — NVIDIA Jetson Orin Nano boards handle AI inference, natural language "
        "understanding, pattern discovery from observation data, reflex compilation and deployment, MQTT telemetry bridging, "
        "and the chat interface. Three or more Jetson units form a cognitive cluster with role specialization "
        "(chatbot, vision, STT/TTS, data analysis)."
    ))
    story.append(body(
        "<b>Tier 3 (Cloud)</b> — Optional offloading for heavy computational tasks that exceed the Jetson's 8GB VRAM "
        "or require large model inference. Connected via Starlink satellite link with queue-and-forward semantics. Used "
        "for training, large-scale simulation, fleet management, and generating complex reflex proposals."
    ))

    story.append(Heading2("3.2 Data Flow Architecture", "sec3_2"))
    story.append(code_block(
        "Sensors --> ESP32 (ADC/GPIO/I2C) --> Observation Buffer (PSRAM ring buffer)\n"
        "                                                |\n"
        "                                                v (RS-422, COBS-framed)\n"
        "                                         Jetson Serial Bridge\n"
        "                                                |\n"
        "                                    +-----------+-----------+\n"
        "                                    |           |           |\n"
        "                                    v           v           v\n"
        "                              Learning    Reflex      Telemetry\n"
        "                              Pipeline   Orchestrator  MQTT Bridge\n"
        "                                    |           |           |\n"
        "                                    v           v           v\n"
        "                              Pattern     Deploy      Cloud/\n"
        "                              Discovery   Bytecode    Dashboard"
    ))

    # ═══════════════ SECTION 4: HARDWARE PLATFORM ═══════════════
    story.append(Heading1("4. Hardware Platform", "sec4"))
    story.append(Heading2("4.1 Reference Implementation: ESP32-S3 + Jetson Orin Nano Super", "sec4_1"))
    story.append(body(
        "The reference implementation uses ESP32-S3 microcontrollers and NVIDIA Jetson Orin Nano Super Developer Kits. "
        "These components were selected for their performance, availability, power efficiency, and ecosystem maturity."
    ))

    story.append(Heading3("ESP32-S3 'Limb' Nodes:", "sec4_1_esp"))
    story.append(make_table(
        ["Parameter", "Value"],
        [
            ["SoC", "ESP32-S3 (Xtensa LX7 dual-core, 240MHz)"],
            ["SRAM", "512 KB"],
            ["PSRAM", "8 MB (Octal SPI)"],
            ["Flash", "16 MB (Quad/Octal SPI)"],
            ["WiFi", "802.11 b/g/n (2.4 GHz)"],
            ["Bluetooth", "BLE 5.0"],
            ["GPIO", "45 configurable pins"],
            ["ADC", "2x 12-bit SAR, 20 channels"],
            ["I2C", "2x I2C (up to 1 MHz)"],
            ["SPI", "2x SPI (up to 80 MHz)"],
            ["UART", "3x UART (up to 5 Mbps)"],
            ["USB", "USB-OTG (device/host)"],
            ["Price", "~$6-10 per unit"],
        ],
        col_widths=[CONTENT_W * 0.30, CONTENT_W * 0.70]
    ))
    story.append(spacer(6))

    story.append(Heading3("Jetson Orin Nano Super 'Brain' Nodes:", "sec4_1_jet"))
    story.append(make_table(
        ["Parameter", "Value"],
        [
            ["SoC", "NVIDIA Jetson Orin Nano Super"],
            ["GPU", "1024-core Ampere architecture, 40 TOPS INT8"],
            ["CPU", "6-core ARM Cortex-A78AE (up to 1.5 GHz)"],
            ["Memory", "8 GB LPDDR5 (68 GB/s bandwidth)"],
            ["Storage", "NVMe M.2 slot (not included)"],
            ["Video Encode", "4x 4K@60 or 16x 1080p@60"],
            ["Video Decode", "4x 4K@60"],
            ["Connectivity", "1x GbE, 1x USB 3.2, 1x USB 2.0, PCIe Gen4 x1"],
            ["Power", "15-25W"],
            ["Price", "~$249 per unit"],
        ],
        col_widths=[CONTENT_W * 0.30, CONTENT_W * 0.70]
    ))
    story.append(spacer(6))

    story.append(Heading3("Recommended Cluster Configuration:", "sec4_1_clust"))
    story.append(make_table(
        ["Jetson Unit", "Primary Role", "Backup Role"],
        [
            ["Jetson 1", "Chat interface + NLP + LLM inference", "Node management"],
            ["Jetson 2", "Vision processing + STT/TTS", "Pattern discovery"],
            ["Jetson 3", "Data analysis + telemetry + MQTT bridge", "Cloud sync"],
        ],
        col_widths=[CONTENT_W * 0.20, CONTENT_W * 0.42, CONTENT_W * 0.38]
    ))

    story.append(Heading2("4.2 Physical Interconnection", "sec4_2"))
    story.append(body(
        "Each ESP32 connects to the Jetson cluster via <b>RS-422 full-duplex serial</b> using Cat-5e/6 cable with RJ-45 "
        "connectors. The physical layer specification includes:"
    ))
    for txt in [
        "<b>Default baud rate:</b> 921,600 bps (upgradeable from 115,200 at boot)",
        "<b>Transceiver:</b> TI THVD1500 (3.3V, 50 Mbps, auto-bias)",
        "<b>Cable length:</b> Up to 100m at 115,200 bps; 10m at 921,600 bps",
        "<b>Termination:</b> 120-ohm differential at each end",
        "<b>Flow control:</b> Hardware CTS/RTS always enabled",
        "<b>Connector pinout:</b> 8-pin RJ-45 (TX+/TX-/RX+/RX-/GND/CTS/RTS/SHIELD)",
    ]:
        story.append(bullet(txt))

    # ═══════════════ SECTION 5: MINIMUM HARDWARE SPECS ═══════════════
    story.append(Heading1("5. Minimum Hardware Specifications", "sec5"))
    story.append(body(
        "The NEXUS platform is designed to be completely hardware-agnostic. The following minimum specifications define "
        "the lowest-bar hardware that can serve as a limb node:"
    ))

    story.append(Heading2("5.1 MCU Minimum Specifications (Tier 1)", "sec5_1"))
    story.append(make_table(
        ["Resource", "Minimum", "Recommended", "Notes"],
        [
            ["Architecture", "ARM Cortex-M4 or equivalent", "ARM Cortex-M7, Xtensa LX7", "Must support 32-bit integers and IEEE 754 float"],
            ["CPU Clock", "200 MHz (dual-core)", "240 MHz (dual-core)", "Single-core possible but limits concurrency"],
            ["SRAM", "512 KB", "512 KB+", "Stack, VM execution, protocol buffers"],
            ["Flash", "4 MB", "8-16 MB", "Firmware (~320KB) + reflex storage + OTA"],
            ["External RAM", "Optional (PSRAM)", "8 MB", "Observation buffer (PSRAM ring buffer preferred)"],
            ["UART", "1x (minimum)", "2-3x", "Primary serial link + debug"],
            ["GPIO", "8+", "20+", "Sensor and actuator connections"],
            ["ADC", "1x 12-bit (4 channels)", "2x 12-bit (8+ channels)", "Analog sensor input"],
            ["I2C", "1x (100 kHz minimum)", "2x (400 kHz)", "Compass, IMU, environmental sensors"],
            ["RTOS", "FreeRTOS or equivalent", "FreeRTOS 10.x+", "Required for task management"],
            ["Interrupt controller", "NVIC with configurable priority", "Nested vectored interrupts", "For safety ISR (kill switch)"],
        ],
        col_widths=[CONTENT_W * 0.18, CONTENT_W * 0.24, CONTENT_W * 0.26, CONTENT_W * 0.32]
    ))

    story.append(Heading2("5.2 Evaluated MCU Compatibility", "sec5_2"))
    story.append(body("The hardware compatibility matrix evaluates 13 MCU families against these specifications:"))
    story.append(make_table(
        ["MCU Family", "Meets Min?", "Flash", "SRAM", "PSRAM", "Clock", "Porting"],
        [
            ["ESP32-S3", "Yes (ref)", "16 MB", "512 KB", "8 MB", "240 MHz", "None"],
            ["ESP32-S2", "Yes", "4 MB", "320 KB", "2 MB", "240 MHz", "Low"],
            ["ESP32 (orig)", "Partial", "4 MB", "520 KB", "None", "240 MHz", "Low"],
            ["STM32H743", "Yes", "2 MB", "1 MB", "Opt", "480 MHz", "Med"],
            ["STM32F767", "Yes", "1 MB", "512 KB", "Opt", "216 MHz", "Med"],
            ["RP2040", "No", "2 MB", "264 KB", "No", "133 MHz", "Med"],
            ["nRF52840", "No", "1 MB", "256 KB", "No", "64 MHz", "High"],
            ["SAMD51", "Yes", "1 MB", "256 KB", "No", "120 MHz", "Med"],
            ["Teensy 4.1", "Yes", "8 MB", "1 MB", "Opt", "600 MHz", "Low"],
            ["CH32V307", "Partial", "256 KB", "64 KB", "No", "144 MHz", "High"],
            ["ATSAME54", "Yes", "1 MB", "256 KB", "No", "120 MHz", "Med"],
            ["ESP32-C6", "Yes", "4 MB", "512 KB", "No", "160 MHz", "Low"],
            ["ESP32-P4", "Yes", "32 MB", "512 KB", "16 MB", "400 MHz", "Low"],
        ],
        col_widths=[CONTENT_W * 0.15, CONTENT_W * 0.12, CONTENT_W * 0.12, CONTENT_W * 0.12, CONTENT_W * 0.10, CONTENT_W * 0.13, CONTENT_W * 0.10]
    ))

    story.append(Heading2("5.3 Cognitive Layer Minimum Specifications (Tier 2)", "sec5_3"))
    story.append(make_table(
        ["Resource", "Minimum", "Recommended"],
        [
            ["CPU", "4-core ARM Cortex-A72/A78", "6-core ARM Cortex-A78AE"],
            ["GPU", "4 TOPS INT8", "40 TOPS INT8"],
            ["RAM", "4 GB LPDDR4", "8 GB LPDDR5"],
            ["Storage", "64 GB NVMe SSD", "256 GB NVMe SSD"],
            ["OS", "Linux (Debian/Ubuntu based)", "JetPack 6.x"],
            ["Python", "3.10+", "3.11"],
            ["Network", "1x GbE", "1x GbE + WiFi 6"],
        ],
        col_widths=[CONTENT_W * 0.22, CONTENT_W * 0.38, CONTENT_W * 0.40]
    ))

    # ═══════════════ SECTION 6: FIRMWARE ARCHITECTURE ═══════════════
    story.append(Heading1("6. Firmware Architecture: Universal Limb", "sec6"))
    story.append(Heading2("6.1 Design Philosophy: One Binary to Rule Them All", "sec6_1"))
    story.append(body(
        "The NEXUS firmware ships as a <b>single universal binary</b> (~320 KB) that runs on every ESP32 in the system. "
        "Role is determined entirely by JSON configuration sent at boot from the Jetson. This design provides several "
        "critical advantages:"
    ))
    for txt in [
        "<b>Hot-swap field replacement:</b> If an ESP32 fails, any fresh unit can be plugged in and will automatically receive its role. A fisherman does not need a laptop — the system provisions itself.",
        "<b>Simplified testing and signing:</b> Only one binary needs to be tested, validated, and cryptographically signed. Per-role testing is unnecessary.",
        "<b>Operational simplicity:</b> Inventory management requires stocking only one firmware image. No risk of flashing the wrong binary to the wrong node.",
    ]:
        story.append(bullet(txt))
    story.append(body(
        "The trade-off is increased flash usage (~320 KB vs ~150 KB for minimal per-role builds). This is acceptable on "
        "ESP32-S3 with 16 MB flash — the overhead is approximately 2% of available storage."
    ))

    story.append(Heading2("6.2 Boot Sequence (Timed)", "sec6_2"))
    story.append(body("The boot sequence is safety-critical and must complete within 500ms. Every timing milestone has been specified and measured:"))
    story.append(make_table(
        ["Time (ms)", "Event"],
        [
            ["T+0", "Power-on. All GPIO outputs forced LOW (safe state)."],
            ["T+5", "Hardware watchdog feeding begins (MAX6818, 200ms kick interval)."],
            ["T+10", "UART initialization at 115,200 baud."],
            ["T+20", "Send DEVICE_IDENTITY (0x01) — MAC address, chip type, firmware version, capabilities."],
            ["T+30", "Send AUTO_DETECT_RESULT (0x1B) — I2C bus scan, ADC probe."],
            ["T+50", "Send SELFTEST_RESULT (0x04) — per-pin continuity, CRC verification."],
            ["T+50-300", "Wait for ROLE_ASSIGN (0x02) from Jetson."],
            ["T+300", "Apply role configuration, load cached reflexes from LittleFS."],
            ["T+500", "Enter OPERATIONAL state. Begin normal heartbeat, telemetry, reflex execution."],
        ],
        col_widths=[CONTENT_W * 0.18, CONTENT_W * 0.82]
    ))
    story.append(body(
        "If no Jetson is connected, the node enters IDLE mode after 30 seconds, sending heartbeats only, and retries "
        "role assignment every 10 seconds."
    ))

    story.append(Heading2("6.3 I/O Abstraction Layer", "sec6_3"))
    story.append(body(
        "The I/O abstraction layer decouples pin configurations from the compiled firmware. At boot, the Jetson sends a "
        "ROLE_ASSIGN message containing the complete pin map:"
    ))
    story.append(code_block(
        '{\n'
        '  "role": "autopilot_controller",\n'
        '  "pins": {\n'
        '    "rudder_pwm": {"gpio": 4, "mode": "pwm", "freq_hz": 50, "safe_value": 1500},\n'
        '    "throttle_relay": {"gpio": 5, "mode": "output", "safe_value": 0},\n'
        '    "compass_sda": {"gpio": 21, "mode": "i2c", "bus": 0, "addr": "0x1E"},\n'
        '    "kill_switch": {"gpio": 22, "mode": "input", "pull": "up", "interrupt": "falling"}\n'
        '  },\n'
        '  "telemetry_interval_ms": 100,\n'
        '  "reflexes": ["heading_hold_pid"]\n'
        '}'
    ))
    story.append(body(
        "The I/O driver interface is defined as a C header (io_driver_interface.h) with a driver vtable that every hardware "
        "driver must implement. The vtable includes 7 mandatory functions: init(), read(), write(), configure(), selftest(), "
        "deinit(), and get_info(). Nine I2C drivers are specified with exact register sequences, self-test procedures, "
        "and known limitations."
    ))

    story.append(Heading2("6.4 Flash Partition Table", "sec6_4"))
    story.append(make_table(
        ["Partition", "Type", "Subtype", "Size", "Description"],
        [
            ["nvs", "data", "nvs", "24 KB", "Non-volatile storage (boot count, safety events, cached role)"],
            ["otadata", "data", "ota", "8 KB", "OTA update state machine"],
            ["phy_init", "data", "phy", "4 KB", "PHY calibration data"],
            ["factory", "app", "factory", "512 KB", "Trusted factory firmware (never OTA-modified)"],
            ["ota_0", "app", "ota_0", "1.5 MB", "Primary OTA slot"],
            ["ota_1", "app", "ota_1", "1.5 MB", "Backup OTA slot (for rollback)"],
            ["reflexes", "data", "spiffs", "2 MB", "LittleFS partition for reflex JSON + compiled bytecode"],
            ["obs_buffer", "data", "nvs", "8 MB", "PSRAM ring buffer for observation data"],
            ["coredump", "data", "coredump", "64 KB", "Crash dump storage"],
        ],
        col_widths=[CONTENT_W * 0.12, CONTENT_W * 0.10, CONTENT_W * 0.10, CONTENT_W * 0.10, CONTENT_W * 0.58]
    ))
    story.append(body(
        "The factory partition is <b>never modified by OTA</b>. It serves as the trusted recovery image. If both OTA slots "
        "fail validation, the system boots from factory firmware and enters safe provisioning mode."
    ))

    # ═══════════════ SECTION 7: REFLEX VM ═══════════════
    story.append(Heading1("7. Reflex Bytecode Virtual Machine", "sec7"))
    story.append(Heading2("7.1 Why Bytecode Instead of JSON Interpretation", "sec7_1"))
    story.append(body(
        "Reflex behaviors need to execute at 100Hz-1kHz on resource-constrained microcontrollers. Interpreting JSON at "
        "every tick cycle would consume 500-2000 microseconds of the 1000-microsecond budget at 1kHz, leaving insufficient "
        "time for actual computation. The bytecode VM approach reduces per-cycle execution to less than 100 microseconds "
        "— a 10x improvement — while providing deterministic timing, bounded memory, and zero heap allocation."
    ))
    story.append(make_table(
        ["Property", "JSON Interpretation", "NEXUS Bytecode VM"],
        [
            ["Deterministic timing", "No (variable string parsing)", "Yes (fixed cycle count per opcode)"],
            ["Memory model", "Dynamic allocation (fragmentation risk)", "Static 3KB footprint (zero allocation)"],
            ["Garbage collection", "Required", "None"],
            ["Auditability", "Hard to validate pre-execution", "Single linear pass validation"],
            ["Security boundary", "JSON injection possible", "Type-safe, bounds-checked sandbox"],
            ["Execution speed", "~1000x slower than native", "~50x slower than native"],
            ["Code size", "8-15 KB (parser only)", "~12 KB (complete VM)"],
        ],
        col_widths=[CONTENT_W * 0.22, CONTENT_W * 0.38, CONTENT_W * 0.40]
    ))

    story.append(Heading2("7.2 ISA Summary: 32 Fixed Opcodes", "sec7_2"))
    story.append(body(
        "The VM implements a stack machine with exactly 32 opcodes (0x00-0x1F) organized into 10 categories. Every "
        "instruction is exactly 8 bytes: 1 byte opcode + 1 byte flags + 2 bytes operand1 + 4 bytes operand2."
    ))
    story.append(make_table(
        ["Category", "Opcodes", "Operations"],
        [
            ["Stack", "0x00-0x07", "NOP, PUSH_I8, PUSH_I16, PUSH_F32, POP, DUP, SWAP, ROT"],
            ["Arithmetic", "0x08-0x10", "ADD_F, SUB_F, MUL_F, DIV_F, NEG_F, ABS_F, MIN_F, MAX_F, CLAMP_F"],
            ["Comparison", "0x11-0x15", "EQ_F, LT_F, GT_F, LTE_F, GTE_F"],
            ["Logic", "0x16-0x19", "AND_B, OR_B, XOR_B, NOT_B"],
            ["I/O", "0x1A-0x1C", "READ_PIN, WRITE_PIN, READ_TIMER_MS"],
            ["Control", "0x1D-0x1F", "JUMP, JUMP_IF_FALSE, JUMP_IF_TRUE"],
        ],
        col_widths=[CONTENT_W * 0.16, CONTENT_W * 0.14, CONTENT_W * 0.70]
    ))
    story.append(body(
        "Extended operations (CALL, RET, HALT, PID_COMPUTE, RECORD_SNAPSHOT, EMIT_EVENT) are implemented as pseudo-instructions "
        "using the NOP opcode with the SYSCALL flag (bit 7 of flags byte). Variable access uses READ_PIN/WRITE_PIN with "
        "operand1 >= 64 (mapping to variable index = operand1 - 64, range 0-255)."
    ))

    story.append(Heading2("7.3 Memory Model", "sec7_3"))
    story.append(make_table(
        ["Resource", "Size", "Description"],
        [
            ["Data stack", "256 x uint32 (1 KB)", "Stack for computation, max depth 256"],
            ["Call stack", "16 entries (256 B)", "Return addresses and frame pointers"],
            ["Variables", "256 x float32 (1 KB)", "Persistent variables across ticks"],
            ["Sensor registers", "64 x float32 (256 B)", "Populated by firmware before each tick"],
            ["Actuator registers", "64 x float32 (256 B)", "Drained by firmware after each tick"],
            ["PID controllers", "8 x 32 bytes (256 B)", "PID state (Kp, Ki, Kd, integral, prev_error)"],
            ["Snapshot buffer", "16 x 128 bytes (2 KB)", "Debug/observation snapshots"],
            ["Event ring buffer", "32 x 8 bytes (256 B)", "Asynchronous event queue"],
            ["<b>Total VM footprint</b>", "<b>~3 KB</b>", "<b>Fits entirely in SRAM</b>"],
        ],
        col_widths=[CONTENT_W * 0.22, CONTENT_W * 0.24, CONTENT_W * 0.54]
    ))

    story.append(Heading2("7.4 Safety Invariants", "sec7_4"))
    story.append(body("The VM enforces five critical safety invariants on every tick:"))
    for i, txt in enumerate([
        "<b>Stack bounds:</b> Every PUSH checks SP < 256; every POP checks SP > 0. Violation causes immediate HALT.",
        "<b>Cycle budget:</b> Maximum 10,000 cycles per tick. If exceeded, VM halts and places actuators in safe position.",
        "<b>Actuator clamping:</b> All actuator register values are clamped to configured min/max bounds after VM execution, regardless of bytecode output.",
        "<b>Jump target validation:</b> All jump targets are verified to be within bytecode bounds and 8-byte aligned at compile time.",
        "<b>Division safety:</b> Division by zero returns 0.0 instead of NaN/Inf.",
    ], 1):
        story.append(numbered(txt, i))

    story.append(Heading2("7.5 JSON-to-Bytecode Compilation", "sec7_5"))
    story.append(body("Reflexes are authored in JSON (human-readable source of truth) and compiled to bytecode by the Jetson before deployment. The JSON reflex format supports:"))
    story.append(code_block(
        '{\n'
        '  "name": "heading_hold_pid",\n'
        '  "version": "1.2.0",\n'
        '  "priority": 10,\n'
        '  "tick_rate_hz": 10,\n'
        '  "variables": {\n'
        '    "integral": {"type": "float32", "initial": 0.0},\n'
        '    "prev_error": {"type": "float32", "initial": 0.0}\n'
        '  },\n'
        '  "sensors": {\n'
        '    "heading": {"pin": 0, "type": "float32", "unit": "deg"},\n'
        '    "setpoint": {"pin": 1, "type": "float32", "unit": "deg"}\n'
        '  },\n'
        '  "actuators": {\n'
        '    "rudder": {"pin": 0, "min": -45.0, "max": 45.0, "safe": 0.0}\n'
        '  },\n'
        '  "pid_controllers": {\n'
        '    "heading_pid": {"kp": 1.2, "ki": 0.05, "kd": 0.3,\n'
        '      "integral_limit": 1500.0, "output_min": -45.0, "output_max": 45.0}\n'
        '  },\n'
        '  "code": "READ_PIN heading; READ_PIN setpoint; PID_COMPUTE heading_pid;\n'
        '          CLAMP_F -45.0 45.0; WRITE_PIN rudder"\n'
        '}'
    ))
    story.append(body(
        "The compiler (compiler.c on the Jetson side) parses this JSON, validates the schema, allocates variable indices, "
        "generates bytecode with correct offsets, and runs the validator. The compiled bytecode is sent to the ESP32 via "
        "REFLEX_DEPLOY (message 0x09)."
    ))

    # ═══════════════ SECTION 8: WIRE PROTOCOL ═══════════════
    story.append(Heading1("8. NEXUS Serial Wire Protocol", "sec8"))
    story.append(Heading2("8.1 Protocol Overview", "sec8_1"))
    story.append(body("All communication between Jetson and ESP32 nodes uses the NEXUS Serial Wire Protocol, built on three layers:"))
    for i, txt in enumerate([
        "<b>Physical layer:</b> RS-422 full-duplex, 921,600 bps default, RJ-45 connectors",
        "<b>Framing layer:</b> COBS (Consistent Overhead Byte Stuffing) encoding with 0x00 delimiters",
        "<b>Message layer:</b> 10-byte fixed header with type, flags, sequence number, timestamp, and payload length",
    ], 1):
        story.append(numbered(txt, i))

    story.append(Heading2("8.2 COBS Framing", "sec8_2"))
    story.append(body("COBS encoding was chosen over newline-delimited JSON and SLIP for several reasons:"))
    for txt in [
        "<b>Binary payload support:</b> Observation buffer dumps (5.5 MB of binary data) cannot be encoded as JSON without 33% base64 overhead. COBS adds only 0.4% overhead.",
        "<b>Unambiguous framing:</b> The 0x00 delimiter can never appear inside COBS-encoded data, making frame detection trivial and self-synchronizing.",
        "<b>No escaping complexity:</b> Unlike SLIP, there is no confusion between start and end delimiters (0xC0 in SLIP serves both roles).",
    ]:
        story.append(bullet(txt))
    story.append(body("CRC-16/CCITT-FALSE (polynomial 0x1021, initial value 0xFFFF) provides integrity checking over the decoded frame."))

    story.append(Heading2("8.3 Message Type Summary", "sec8_3"))
    story.append(body("The protocol defines <b>28 message types</b> organized into 8 categories:"))
    story.append(make_table(
        ["Category", "Messages", "Purpose"],
        [
            ["Boot & Identity", "DEVICE_IDENTITY, SELFTEST_RESULT, AUTO_DETECT_RESULT", "Node announcement and hardware discovery"],
            ["Role Management", "ROLE_ASSIGN, ROLE_ACK", "Dynamic role assignment"],
            ["Link Health", "HEARTBEAT, PING, PONG, BAUD_UPGRADE", "Keep-alive, latency, speed negotiation"],
            ["Telemetry & Data", "TELEMETRY, CLOUD_CONTEXT_REQUEST, CLOUD_RESULT", "Sensor data and cloud analysis"],
            ["Commands & Control", "COMMAND, COMMAND_ACK, IO_RECONFIGURE", "Actuator control and reconfiguration"],
            ["Reflex Engine", "REFLEX_DEPLOY, REFLEX_STATUS", "Deploy and monitor bytecode reflexes"],
            ["Observation System", "OBS_RECORD_START/STOP, OBS_DUMP_HEADER/CHUNK/END", "Record and transfer observation data"],
            ["Firmware OTA", "FIRMWARE_UPDATE_START/CHUNK/END/RESULT", "Over-the-air firmware updates"],
            ["Error & Safety", "ERROR, SAFETY_EVENT", "Error reporting and safety notifications"],
        ],
        col_widths=[CONTENT_W * 0.20, CONTENT_W * 0.40, CONTENT_W * 0.40]
    ))

    story.append(Heading2("8.4 Reliability Mechanisms", "sec8_4"))
    for txt in [
        "<b>Acknowledgement and retry:</b> Messages with criticality >= 1 require ACK. Up to 3 retries with exponential backoff (200ms, 400ms, 800ms).",
        "<b>Sequence number validation:</b> 16-bit rolling counter with sliding window (8 entries) for duplicate/gap detection.",
        "<b>Heartbeat with escalation:</b> 4-state escalation (HEALTHY -> WARN -> DEGRADED -> FAILSAFE) based on consecutive missed heartbeats.",
        "<b>Priority queuing:</b> 4-level priority (Safety > Critical > Normal > Bulk) with preemption rules.",
        "<b>Flow control:</b> Hardware CTS/RTS with backpressure at 50% buffer capacity.",
    ]:
        story.append(bullet(txt))

    story.append(Heading2("8.5 Error Code Registry", "sec8_5"))
    story.append(body("75 error codes are organized into 6 categories:"))
    story.append(make_table(
        ["Category", "Prefix", "Count", "Examples"],
        [
            ["General", "0x00", "7", "UNKNOWN, TIMEOUT, BUFFER_OVERFLOW"],
            ["Hardware", "0x10", "10", "GPIO_INIT_FAILED, I2C_BUS_LOCKED, ADC_READ_ERROR"],
            ["I/O", "0x20", "7", "PIN_MODE_INVALID, PIN_ALREADY_IN_USE"],
            ["Reflex", "0x30", "7", "REFLEX_PARSE_ERROR, REFLEX_CYCLE_DETECTED"],
            ["Safety", "0x40", "8", "KILL_SWITCH_ACTIVATED, OVERCURRENT_DETECTED, THERMAL_SHUTDOWN"],
            ["Protocol", "0x50", "13", "FRAME_TOO_LARGE, CRC_MISMATCH, COBS_DECODE_ERROR"],
            ["Firmware", "0x60", "7", "OTA_HASH_MISMATCH, OTA_BOOT_VERIFICATION_FAILED"],
        ],
        col_widths=[CONTENT_W * 0.18, CONTENT_W * 0.12, CONTENT_W * 0.10, CONTENT_W * 0.60]
    ))
    story.append(body("Four severity levels: Info (logged only), Warning (logged + rate-limited), Error (operation aborted), Critical (safe-state entry)."))

    # ═══════════════ SECTION 9: JETSON COGNITIVE LAYER ═══════════════
    story.append(Heading1("9. Jetson Cognitive Layer", "sec9"))
    story.append(Heading2("9.1 Cluster Architecture", "sec9_1"))
    story.append(body(
        "The cognitive layer runs on 3+ Jetson Orin Nano Super units organized as a microservice cluster. Inter-Jetson "
        "communication uses <b>gRPC</b> for synchronous operations and <b>MQTT</b> for asynchronous telemetry. A gRPC proto "
        "file (cluster_api.proto) defines 6 services with 80+ message types:"
    ))
    story.append(make_table(
        ["Service", "Methods", "Purpose"],
        [
            ["NodeDiscovery", "ListNodes, GetNodeInfo, WatchNodes", "Serial port enumeration and node topology"],
            ["NodeManager", "AssignRole, ReassignRole, GetRoleConfig", "Dynamic role assignment"],
            ["ReflexOrchestrator", "DeployReflex, ListReflexes, RemoveReflex", "Reflex lifecycle management"],
            ["LearningService", "StartSession, StopSession, GetPatterns, TriggerAnalysis", "Observation and learning control"],
            ["AutonomyManager", "GetTrustScore, SetAutonomyLevel, GetOverrides", "INCREMENTS autonomy state"],
            ["ChatService", "SendMessage, GetHistory, SetMode", "Conversational interface"],
        ],
        col_widths=[CONTENT_W * 0.22, CONTENT_W * 0.40, CONTENT_W * 0.38]
    ))

    story.append(Heading2("9.2 Module Interface", "sec9_2"))
    story.append(body(
        "All Jetson modules implement a Python ABC (module_interface.py) with standardized lifecycle management:"
    ))
    story.append(code_block(
        "class NexusModule(ABC):\n"
        "    @abstractmethod\n"
        "    async def start(self) -> None: ...\n"
        "\n"
        "    @abstractmethod\n"
        "    async def stop(self) -> None: ...\n"
        "\n"
        "    @abstractmethod\n"
        "    async def health_check(self) -> ModuleHealth: ...\n"
        "\n"
        "    @abstractmethod\n"
        "    def resource_budget(self) -> ResourceBudget: ...\n"
        "\n"
        "    async def hot_reload(self, config: dict) -> None:\n"
        '        """Reload configuration without restart."""\n'
        "        ..."
    ))
    story.append(body(
        "Every module reports resource budgets (CPU%, GPU%, RAM, VRAM) and can be hot-reloaded at runtime. A ThrottleMonitor "
        "class is provided as a concrete example that sheds non-essential services when the Jetson approaches thermal "
        "throttling (85C)."
    ))

    story.append(Heading2("9.3 MQTT Topic Hierarchy", "sec9_3"))
    story.append(body("13 MQTT topics are defined with specific QoS levels and publisher/subscriber assignments:"))
    story.append(make_table(
        ["Topic", "QoS", "Retain", "Dir.", "Purpose"],
        [
            ["nexus/telemetry/{node_id}", "0", "No", "N2J", "Sensor telemetry"],
            ["nexus/status/{node_id}", "1", "Yes", "N2J", "Node status"],
            ["nexus/safety/{node_id}", "2", "No", "N2J", "Safety events"],
            ["nexus/autonomy/{sub}/level", "1", "Yes", "J2N", "Autonomy level commands"],
            ["nexus/autonomy/{sub}/override", "2", "Yes", "J2N", "Override commands"],
            ["nexus/learning/session/{id}/ctrl", "1", "No", "J2N", "Recording control"],
            ["nexus/cloud/result/{node_id}", "1", "No", "J2N", "Cloud analysis results"],
            ["nexus/reflex/{id}/deploy", "1", "No", "J2N", "Reflex deployment"],
            ["nexus/heartbeat/{node_id}", "0", "No", "N2J", "Heartbeat"],
            ["nexus/diagnostic/{node_id}", "0", "No", "Both", "Diagnostic data"],
        ],
        col_widths=[CONTENT_W * 0.30, CONTENT_W * 0.07, CONTENT_W * 0.08, CONTENT_W * 0.08, CONTENT_W * 0.47]
    ))
    story.append(body("Override topics use QoS 2 (exactly-once delivery) because a missed override command could have safety implications."))

    story.append(Heading2("9.4 AI Model Stack", "sec9_4"))
    story.append(make_table(
        ["Function", "Model", "Quant.", "VRAM", "Speed", "Notes"],
        [
            ["Code generation", "Qwen2.5-Coder-7B-Instruct", "Q4_K_M", "~4 GB", "12 tok/s", "Primary reflex generation"],
            ["Intent classification", "Phi-3-mini-4K", "Q4", "~2 GB", "40+ tok/s", "Routes chat to handler"],
            ["Safety validation", "GPT-4o / Claude (cloud)", "N/A", "N/A", "~2 s/call", "Separate from codegen"],
            ["Speech-to-text", "Whisper-small.en", "FP16", "~1 GB", "Real-time", "Local STT for voice"],
            ["Text-to-speech", "Piper", "N/A", "~500 MB", "Real-time", "Local TTS for status"],
        ],
        col_widths=[CONTENT_W * 0.16, CONTENT_W * 0.24, CONTENT_W * 0.09, CONTENT_W * 0.10, CONTENT_W * 0.11, CONTENT_W * 0.30]
    ))
    story.append(body(
        "The code generation model (Qwen2.5-Coder-7B) generates typical 500-token reflex JSON in ~40 seconds, which is "
        "acceptable for interactive use but may feel slow. A 3B model achieving comparable quality at 30+ tok/s would be "
        "preferred if available."
    ))

    # ═══════════════ SECTION 10: SAFETY SYSTEM ═══════════════
    story.append(Heading1("10. Safety System", "sec10"))
    story.append(Heading2("10.1 Four-Tier Defense in Depth", "sec10_1"))
    story.append(body(
        "The safety system implements four independent tiers, each providing an absolute safety barrier. No single tier is "
        "sufficient; the system is safe only when all four are operational."
    ))

    story.append(body(
        "<b>Tier 1: Hardware Interlock (Response: <1ms, Authority: ABSOLUTE)</b>"
    ))
    for txt in [
        "Physical NC mushroom-head kill switch (IP67, 22N-50N actuation force) wired in series with actuator power",
        "External MAX6818 hardware watchdog IC (1.0s timeout, non-software-configurable)",
        "PTC polyfuses per actuator channel (self-resetting, 1.5x hold / 2.0x trip current)",
        "10K-ohm pull-down resistors on all MOSFET gates (fail-safe to LOW)",
        "Flyback diodes on all inductive loads",
        "TVS diodes for ESD protection on RS-422 lines",
    ]:
        story.append(bullet(txt))

    story.append(body(
        "<b>Tier 2: Firmware Safety Guard (Response: <10ms, Authority: overrides all software)</b>"
    ))
    for txt in [
        "Kill switch GPIO ISR (highest interrupt priority, <100us trigger to response)",
        "Overcurrent detection ISR (INA219 alert pin to GPIO interrupt)",
        "Sensor stale detection (periodic check, <10ms response)",
        "All ISR code in IRAM (not flash) to ensure execution even during flash operations",
        "ISR actions: set outputs to safe state, disable PWM, notify deferred handler",
    ]:
        story.append(bullet(txt))

    story.append(body(
        "<b>Tier 3: Supervisory Task (Response: <100ms, Authority: can override control tasks)</b>"
    ))
    for txt in [
        "Highest-priority FreeRTOS task, runs every 10ms",
        "Heartbeat monitoring (Jetson -> ESP32, 100ms interval)",
        "Task watchdog (feeds hardware WDT every 200ms, monitors all tasks)",
        "Safety state machine management (NORMAL -> DEGRADED -> SAFE_STATE)",
        "Heap monitoring and memory leak detection",
    ]:
        story.append(bullet(txt))

    story.append(body(
        "<b>Tier 4: Application Control (Response: <10ms, Authority: lowest)</b>"
    ))
    for txt in [
        "PID loops, reflex execution, AI inference",
        "All actuator writes pass through safety guard API (rate limiting, enable checks)",
        "Cannot disable any safety mechanism",
        "Subject to all constraints from Tiers 1-3",
    ]:
        story.append(bullet(txt))

    story.append(Heading2("10.2 Kill Switch Specification", "sec10_2"))
    story.append(body("The kill switch is the PRIMARY safety mechanism. It is a physical, hardware-level power interrupt:"))
    for txt in [
        "<b>Contact type:</b> Normally Closed (NC), breaks on press",
        "<b>Wiring:</b> In series with +12V actuator power supply, BEFORE any fuse",
        "<b>Sense wire:</b> Dedicated GPIO with external 10K pull-up (broken wire = safe state)",
        "<b>ISR response time:</b> <1ms from contact break to all outputs at safe state",
        "<b>Recovery:</b> System enters PROVISIONING state (never auto-resumes)",
        "<b>Test schedule:</b> Weekly manual, quarterly instrumented (oscilloscope), annual comprehensive",
    ]:
        story.append(bullet(txt))

    story.append(Heading2("10.3 Compliance Targets", "sec10_3"))
    story.append(make_table(
        ["Standard", "Target", "Notes"],
        [
            ["IEC 61508", "SIL 1", "Four-tier architecture provides redundancy"],
            ["ISO 26262", "ASIL-B equivalent", "Hazard analysis and FMEA documented"],
            ["IEC 60945", "Marine", "Environmental testing for salt spray, vibration, EMI"],
            ["ISO 13850", "E-Stop", "Mushroom-head, twist-to-release, IP67"],
        ],
        col_widths=[CONTENT_W * 0.20, CONTENT_W * 0.22, CONTENT_W * 0.58]
    ))

    # ═══════════════ SECTION 11: INCREMENTS ═══════════════
    story.append(Heading1("11. INCREMENTS Autonomy Framework", "sec11"))
    story.append(Heading2("11.1 Six-Level Autonomy Scale", "sec11_1"))
    story.append(body(
        "The INCREMENTS framework defines six levels of autonomy per subsystem, similar in concept to SAE J3016 for "
        "self-driving vehicles but adapted for industrial robotics:"
    ))
    story.append(make_table(
        ["Level", "Name", "Description", "Example (Marine)"],
        [
            ["0", "MANUAL", "Human has full control. System only monitors and records.", "Captain steers manually, system logs all sensor data."],
            ["1", "ASSIST", "System provides suggestions. Human approves every action.", '"Suggested rudder correction: +5 degrees" displayed.'],
            ["2", "SEMI-AUTO", "System executes approved reflexes. Human can override.", "Heading-hold PID runs, captain can grab the wheel."],
            ["3", "CONDITIONAL", "Autonomous within defined conditions. Human monitors.", "Autopilot holds course in calm weather, hands over in storms."],
            ["4", "HIGH", "Autonomous in most conditions. Human is available.", "Full autopilot including course changes, captain on bridge."],
            ["5", "FULL", "Autonomous in all conditions. Human is optional.", "Unmanned vessel transit."],
        ],
        col_widths=[CONTENT_W * 0.07, CONTENT_W * 0.13, CONTENT_W * 0.40, CONTENT_W * 0.40]
    ))

    story.append(Heading2("11.2 Per-Subsystem Autonomy", "sec11_2"))
    story.append(body(
        "Each subsystem (steering, throttle, lighting, bilge, etc.) has an independent autonomy level. This allows "
        "asymmetric trust — the system can be at Level 4 for steering but Level 0 for engine management simultaneously."
    ))

    story.append(Heading2("11.3 Asymmetric Trust Model", "sec11_3"))
    story.append(body("Trust is gained slowly and lost quickly, matching human psychology research (Lee & See, 2004):"))
    story.append(make_table(
        ["Parameter", "Value", "Meaning"],
        [
            ["alpha_gain", "0.002", "Trust gained per good evaluation"],
            ["alpha_loss", "0.05", "Trust lost per bad evaluation"],
            ["Loss:Gain ratio", "25:1", "A single bad event erases ~25 good events"],
            ["Level 3 threshold", "0.7", "~120 days of flawless operation"],
            ["Level 5 threshold", "0.95", "~300 days of flawless operation"],
        ],
        col_widths=[CONTENT_W * 0.22, CONTENT_W * 0.18, CONTENT_W * 0.60]
    ))
    story.append(body(
        "Gaining 0.1 trust from T=0.5 requires approximately 50 consecutive good evaluations. Losing 0.1 from T=0.9 requires "
        "only 2 bad evaluations. This produces realistic advancement timelines and prevents the system from prematurely "
        "earning trust."
    ))

    story.append(Heading2("11.4 Trust Score Formula", "sec11_4"))
    story.append(code_block(
        "T(t+1) = T(t) + alpha_gain * (1 - T(t))       if evaluation is GOOD\n"
        "T(t+1) = T(t) - alpha_loss * T(t)             if evaluation is BAD\n"
        "T(t+1) = T(t)                                  if no evaluation this tick\n"
        "\n"
        "where:\n"
        "  T(t) = trust score at time t, range [0, 1]\n"
        "  alpha_gain = 0.002 (configurable per-subsystem)\n"
        "  alpha_loss = 0.05 (configurable per-subsystem)"
    ))
    story.append(body(
        "The trust score is computed on the Jetson side in Python, taking less than 10ms per evaluation, and stored "
        "persistently in a local database."
    ))

    # ═══════════════ SECTION 12: LEARNING ═══════════════
    story.append(Heading1("12. Learning from Demonstration Pipeline", "sec12"))
    story.append(Heading2("12.1 Observation Data Model", "sec12_1"))
    story.append(body(
        "Every observation is a single timestamped row in an Apache Parquet file. The UnifiedObservation schema contains "
        "72 fields covering navigation (GPS), attitude (IMU), environment (wind, temperature, waves), propulsion (throttle, "
        "rudder, RPM), auxiliary actuators, perception (lidar, radar, camera), system health, and autonomy state."
    ))
    story.append(body("At 100 Hz sampling rate, the data rate is approximately 32 MB/minute or 1.9 GB/hour. Storage uses a three-tier retention policy:"))
    story.append(make_table(
        ["Tier", "Duration", "Storage", "Compression", "Disk Budget"],
        [
            ["HOT", "7 days", "NVMe SSD", "Snappy (2:1)", "~65 GB"],
            ["WARM", "90 days", "NVMe SSD", "ZSTD level 3 (5:1)", "~850 GB"],
            ["COLD", "2 years", "Cloud (S3/GCS)", "ZSTD level 3", "Cloud storage"],
            ["ARCHIVE", "> 2 years", "Deleted", "N/A", "N/A"],
        ],
        col_widths=[CONTENT_W * 0.12, CONTENT_W * 0.14, CONTENT_W * 0.20, CONTENT_W * 0.26, CONTENT_W * 0.28]
    ))

    story.append(Heading2("12.2 Pattern Discovery Algorithms", "sec12_2"))
    story.append(body("Five algorithms operate on observation data after each recording session closes:"))

    story.append(body("<b>1. Cross-Correlation Scanner</b>"))
    story.append(body_indent(
        "Identifies time-lagged relationships between all sensor variables and actuator commands. Scans all C(72,2) = 2,556 "
        "pairs with lags from -60s to +60s at 100ms resolution. Uses Pearson correlation with Bonferroni correction. "
        "Typical runtime: ~8 seconds per 1-hour session on Jetson Orin."
    ))
    story.append(body("<b>2. Bayesian Online Change-Point Detection (BOCPD)</b>"))
    story.append(body_indent(
        "Detects abrupt shifts in sensor statistics using the Adams & MacKay (2007) algorithm. Uses Normal-Inverse-Gamma "
        "conjugate priors with configurable hazard rate (default 0.01). Reports change points with confidence > 0.5 and "
        "minimum run length of 100 observations."
    ))
    story.append(body("<b>3. Behavioral Clustering (HDBSCAN)</b>"))
    story.append(body_indent(
        "Groups 10-second windows of vessel behavior into distinct clusters (cruising, docking, rough-weather maneuvering). "
        "Extracts 40 statistical features per window (8 sensors x 5 features: mean, std, min, max, spectral centroid), "
        "reduces to 5 PCA components, then applies HDBSCAN clustering."
    ))
    story.append(body("<b>4. Temporal Pattern Mining</b>"))
    story.append(body_indent(
        "Discovers recurrent event-response patterns using DTW (Dynamic Time Warping) clustering. Defines events in a "
        "structured language (e.g., 'wind_speed_m_s > 12 AND wave_height_m > 1.5'), extracts response sequences, clusters "
        "similar responses, and reports rules with > 60% consistency across > 5 occurrences."
    ))
    story.append(body("<b>5. Bayesian Reward Inference</b>"))
    story.append(body_indent(
        "Infers a scalar reward function from observed behavior across 6 weighted features: speed comfort, heading accuracy, "
        "fuel efficiency, smoothness, safety margin, and wind compensation. Uses Maximum A Posteriori (MAP) estimation with "
        "Normal-Inverse-Gamma priors seeded by human narration."
    ))

    # ═══════════════ SECTION 13: A/B TESTING ═══════════════
    story.append(Heading1("13. A/B Testing Framework", "sec13"))
    story.append(Heading2("13.1 Purpose", "sec13_1"))
    story.append(body(
        "When the learning pipeline generates a proposed reflex, it must be validated against the human's actual behavior "
        "before deployment. The A/B testing framework runs the proposed reflex alongside the human operator for a "
        "configurable period, collects metrics, and determines statistical significance."
    ))

    story.append(Heading2("13.2 Test Protocol", "sec13_2"))
    for i, txt in enumerate([
        "<b>Baseline phase (A):</b> Record human-operated data for a minimum period (default: 30 minutes).",
        "<b>Treatment phase (B):</b> Activate proposed reflex while human monitors. Human can override at any time.",
        "<b>Comparison:</b> Compute standardized metrics for both phases.",
        "<b>Decision:</b> If treatment is not statistically worse on any safety metric and is significantly better on at least one efficiency metric, recommend acceptance.",
    ], 1):
        story.append(numbered(txt, i))

    story.append(Heading2("13.3 Standardized Metrics", "sec13_3"))
    story.append(make_table(
        ["Metric", "Computation", "Target"],
        [
            ["Heading RMSE", "Root mean square of heading error", "Lower is better"],
            ["Comfort score", "1 - RMS(jerk) / max_jerk", "Higher is better"],
            ["Fuel efficiency", "distance / fuel_consumed", "Higher is better"],
            ["Safety margin", "min(obstacle_distance) over window", "Higher is better (threshold: 10m)"],
            ["Smoothness", "-RMS(jerk_heave) normalized to [0,1]", "Higher is better"],
            ["Override frequency", "count of human overrides per hour", "Lower is better (threshold: 2/hr)"],
            ["Response latency", "mean time from event to corrective action", "Lower is better"],
        ],
        col_widths=[CONTENT_W * 0.22, CONTENT_W * 0.45, CONTENT_W * 0.33]
    ))
    story.append(body(
        "Statistical significance is assessed using paired t-tests with Bonferroni correction for multiple comparisons "
        "(7 metrics = significance threshold p < 0.007)."
    ))

    # ═══════════════ SECTION 14: CLOUD ═══════════════
    story.append(Heading1("14. Cloud Offloading and Code Generation", "sec14"))
    story.append(Heading2("14.1 Cloud Connectivity", "sec14_1"))
    story.append(body("Cloud connectivity is optional but provides heavy computational capabilities not available on the Jetson:"))
    story.append(make_table(
        ["Function", "Local (Jetson)", "Cloud"],
        [
            ["Code generation", "Qwen2.5-Coder-7B (12 tok/s)", "GPT-4o / Claude (100+ tok/s)"],
            ["Safety validation", "Rule-based + separate LLM call", "Full MISRA-C analysis + simulation"],
            ["Simulation", "Limited (5-minute horizon)", "Extended (hours of simulated operation)"],
            ["Training", "On-device fine-tuning (small models)", "Full training pipeline"],
            ["Fleet management", "Single-vessel SQLite", "Multi-vessel PostgreSQL"],
        ],
        col_widths=[CONTENT_W * 0.20, CONTENT_W * 0.38, CONTENT_W * 0.42]
    ))
    story.append(body(
        "Connectivity is via Starlink with queue-and-forward semantics. Cloud requests have a 60-second timeout with "
        "automatic retry. The local model handles approximately 70% of code generation requests without cloud connectivity."
    ))

    story.append(Heading2("14.2 Code Generation Pipeline", "sec14_2"))
    story.append(body("The cloud coding pipeline follows a 6-stage process:"))
    for i, txt in enumerate([
        "<b>Intent capture:</b> Human describes desired behavior in natural language (chat or voice).",
        "<b>Intent classification:</b> Phi-3-mini routes the request to the correct handler.",
        "<b>Code generation:</b> LLM generates JSON reflex definition (80% JSON, 15% C fallback, 5% Python utilities).",
        "<b>Safety validation:</b> Separate LLM reviews generated code against safety rules. This is a DIFFERENT model call to prevent self-validation bias.",
        "<b>Simulation:</b> Generated code is simulated against recorded observation data.",
        "<b>Human approval:</b> Natural-language explanation presented to operator. Approval deploys; rejection returns to step 2.",
    ], 1):
        story.append(numbered(txt, i))

    story.append(Heading2("14.3 Separate LLM for Validation", "sec14_3"))
    story.append(body(
        "A critical design decision: the LLM that generates code MUST NOT be the same LLM that validates it. When the same "
        "model generates and validates code, it tends to approve its own work because the validation context includes the "
        "reasoning that led to the design. This is a well-documented cognitive bias called 'self-validation bias.' The "
        "$0.01-0.03 per validation call cost is negligible compared to deploying unsafe code."
    ))

    # ═══════════════ SECTION 15: ADRs ═══════════════
    story.append(Heading1("15. Architecture Decision Records", "sec15"))
    story.append(body(
        "28 Architecture Decision Records (ADRs) capture every significant design choice. The following table summarizes "
        "all decisions with their confidence levels:"
    ))
    story.append(make_table(
        ["ADR", "Decision", "Conf.", "Key Rationale"],
        [
            ["001", "Universal firmware (not per-role)", "HIGH", "Hot-swap simplicity outweighs 170KB flash overhead"],
            ["002", "Bytecode VM (not JSON interpretation)", "HIGH", "10x faster, deterministic timing"],
            ["003", "COBS framing (not newline JSON)", "HIGH", "Binary payload support, 0.4% vs 33% overhead"],
            ["004", "RS-422 serial (not WiFi)", "V.HIGH", "Marine EMI immunity, wired reliability"],
            ["005", "Separate LLM for safety validation", "V.HIGH", "Prevents self-validation bias"],
            ["006", "Asymmetric trust 25:1 ratio", "HIGH", "Matches human psychology research"],
            ["007", "Hardware NC kill switch", "V.HIGH", "Software crashes; physics doesn't"],
            ["008", "Serial OTA (not WiFi OTA)", "V.HIGH", "Wired is reliable; WiFi can be added later"],
            ["009", "JSON state machines (not behavior trees)", "MED", "Better explainability; less composability"],
            ["010", "jsmn + cJSON split parsers", "HIGH", "jsmn minimal for runtime, cJSON for config"],
            ["011", "PSRAM ring buffer for observations", "V.HIGH", "5.5MB buffer; SRAM too small"],
            ["012", "gRPC + MQTT (not REST)", "MED", "Better for streaming and async"],
            ["013", "Qwen2.5-Coder-7B local model", "MED", "Best balance today; model landscape changes fast"],
            ["014", "Factory partition never OTA-modified", "V.HIGH", "Trusted recovery image"],
            ["015", "80/15/5 JSON/C/Python code ratio", "HIGH", "JSON for reflexes, C for performance-critical"],
            ["016", "Whisper-small.en for local STT", "HIGH", "Good quality, fits in VRAM budget"],
            ["017", "Inverse RL for pattern discovery", "LOW", "Academic, limited industrial validation"],
            ["018", "INCREMENTS 6-level (not SAE 5-level)", "MED", "Better granularity for subsystem control"],
            ["019", "Per-subsystem autonomy", "HIGH", "Asymmetric trust across subsystems"],
            ["020", "Hardcoded 32 opcodes", "HIGH", "Smaller dispatch table, better branch prediction"],
            ["021", "CRC-16 (not CRC-32)", "HIGH", "Faster on MCU, sufficient for serial frames"],
            ["022", "8-byte fixed instruction size", "V.HIGH", "Direct PC indexing, predictable timing"],
            ["023", "LittleFS (not SPIFFS)", "MED", "Journaling protects against power loss"],
            ["024", "Phi-3-mini for intent classification", "MED", "Fast but 4K context window limitation"],
            ["025", "PTC polyfuse for current backup", "V.HIGH", "Passive, non-software-dependent"],
            ["026", "MAX6818 external watchdog", "HIGH", "Independent of internal MCU watchdog"],
            ["027", "QoS 2 for override MQTT", "HIGH", "Exactly-once delivery for safety commands"],
            ["028", "HDBSCAN for behavioral clustering", "MED", "No preset cluster count, handles noise"],
        ],
        col_widths=[CONTENT_W * 0.06, CONTENT_W * 0.36, CONTENT_W * 0.09, CONTENT_W * 0.49]
    ))

    # ═══════════════ SECTION 16: LOW-CONFIDENCE ═══════════════
    story.append(Heading1("16. Low-Confidence Decisions: Second-Place Alternatives", "sec16"))
    story.append(body(
        "The following decisions were made with MEDIUM or LOW confidence. For each, the runner-up alternative is documented "
        "with pros, cons, and what would change our mind."
    ))

    story.append(Heading2("16.1 ADR-009: JSON State Machines vs Behavior Trees", "sec16_1"))
    story.append(body("<b>Chosen:</b> JSON State Machines (Confidence: MEDIUM) | <b>Runner-up:</b> Behavior Trees (BehaviorTree.CPP)"))
    story.append(make_table(
        ["Aspect", "JSON State Machines (Chosen)", "Behavior Trees (Runner-up)"],
        [
            ["Explainability", "Excellent", "Poor (requires explaining decorator sequences)"],
            ["Composability", "Limited (hard to combine)", "Excellent (complex from simple subtrees)"],
            ["Verification", "Straightforward (deadlock analysis)", "Harder (tree structure with decorators)"],
            ["Industry adoption", "Niche (our design)", "Standard in game AI and robotics"],
            ["JSON representation", "Natural (states + transitions)", "Awkward (nested tree structure)"],
        ],
        col_widths=[CONTENT_W * 0.18, CONTENT_W * 0.41, CONTENT_W * 0.41]
    ))
    story.append(body(
        "<b>What would change our mind:</b> If we encounter use cases requiring deeply nested conditional logic (more than 5 "
        "levels), behavior trees become necessary. We could support both representations in the VM."
    ))

    story.append(Heading2("16.2 ADR-013: Qwen2.5-Coder-7B as Local Codegen Model", "sec16_2"))
    story.append(body("<b>Chosen:</b> Qwen2.5-Coder-7B-Instruct Q4_K_M (Confidence: MEDIUM) | <b>Runner-up:</b> DeepSeek-Coder-6.7B"))
    story.append(make_table(
        ["Aspect", "Qwen2.5-Coder-7B (Chosen)", "DeepSeek-Coder-6.7B (Runner-up)"],
        [
            ["Code quality", "Excellent at embedded constraints", "Comparable, slightly better at Python"],
            ["Instruction following", "Good, follows system prompts well", "Good"],
            ["Inference speed", "12 tok/s on Jetson", "~15 tok/s on Jetson"],
            ["VRAM footprint", "~4 GB Q4_K_M", "~4 GB Q4"],
            ["Jetson testing", "Extensively tested", "Less tested on Jetson"],
            ["Context window", "32K tokens", "16K tokens"],
        ],
        col_widths=[CONTENT_W * 0.20, CONTENT_W * 0.40, CONTENT_W * 0.40]
    ))
    story.append(body(
        "<b>What would change our mind:</b> New models are released monthly. If a 3B model achieves comparable code quality "
        "at 30+ tok/s, we should switch. The model interface is abstracted behind a simple generate_code(prompt, max_tokens) "
        "API, making swaps straightforward."
    ))

    story.append(Heading2("16.3 ADR-017: Inverse RL for Pattern Discovery", "sec16_3"))
    story.append(body("<b>Chosen:</b> Bayesian Reward Inference (Confidence: LOW) | <b>Runner-up:</b> Cross-correlation only"))
    story.append(make_table(
        ["Aspect", "Bayesian Reward Inference (Chosen)", "Cross-correlation Only (Runner-up)"],
        [
            ["Insight depth", "Infers WHY human acts (motivation)", "Only WHAT correlates with what"],
            ["Data requirements", "Days of observation", "Minutes to hours"],
            ["Computational cost", "High (offline only, 30+ min)", "Low (8 seconds per session)"],
            ["Reliability", "Unstable, academic validation limited", "Very reliable, well-understood"],
            ["Coverage", "Handles 20% of use cases", "Handles 80% of use cases"],
        ],
        col_widths=[CONTENT_W * 0.20, CONTENT_W * 0.40, CONTENT_W * 0.40]
    ))
    story.append(body(
        "<b>What would change our mind:</b> If IRL proves unstable or unreliable in field testing, it should be demoted to "
        "an optional analysis tool. Cross-correlation and change-point detection alone are sufficient for 80% of use cases."
    ))

    story.append(Heading2("16.4 ADR-018: INCREMENTS 6-Level vs SAE J3016 5-Level", "sec16_4"))
    story.append(body("<b>Chosen:</b> INCREMENTS 6 levels (0-5) per subsystem (Confidence: MEDIUM) | <b>Runner-up:</b> SAE J3016"))
    story.append(make_table(
        ["Aspect", "INCREMENTS 6-Level (Chosen)", "SAE J3016 5-Level (Runner-up)"],
        [
            ["Granularity", "6 levels per subsystem", "5 levels system-wide"],
            ["Per-subsystem", "Yes (independent levels)", "Typically system-wide"],
            ["Industry recognition", "Custom (our design)", "Widely recognized (automotive)"],
            ["ASSIST level", "Explicit suggestion-only mode", "Not clearly defined"],
            ["CONDITIONAL vs HIGH", "Separates condition-limited from general", "Combined into one level"],
        ],
        col_widths=[CONTENT_W * 0.20, CONTENT_W * 0.40, CONTENT_W * 0.40]
    ))
    story.append(body(
        "<b>What would change our mind:</b> If regulatory bodies require SAE J3016 compliance for certification, we would need "
        "to map INCREMENTS levels to SAE levels. The mapping is straightforward: INCREMENTS 0-1 = SAE 0-1, INCREMENTS 2-3 "
        "= SAE 2, INCREMENTS 4 = SAE 3, INCREMENTS 5 = SAE 4-5."
    ))

    story.append(Heading2("16.5 ADR-023: LittleFS vs SPIFFS", "sec16_5"))
    story.append(body("<b>Chosen:</b> LittleFS (Confidence: MEDIUM) | <b>Runner-up:</b> SPIFFS with manual journaling or FAT32"))
    story.append(make_table(
        ["Aspect", "LittleFS (Chosen)", "SPIFFS (Runner-up)"],
        [
            ["Power-loss resilience", "Excellent (copy-on-write + journaling)", "Poor (no journaling, corruption risk)"],
            ["Wear leveling", "Dynamic wear leveling", "Static wear leveling (simpler)"],
            ["Directory support", "Yes", "No (flat namespace)"],
            ["ESP-IDF maturity", "Stable, well-integrated", "Mature, widely used"],
        ],
        col_widths=[CONTENT_W * 0.20, CONTENT_W * 0.40, CONTENT_W * 0.40]
    ))

    story.append(Heading2("16.6 ADR-012: gRPC + MQTT vs REST", "sec16_6"))
    story.append(body("<b>Chosen:</b> gRPC (synchronous) + MQTT (asynchronous) (Confidence: MEDIUM) | <b>Runner-up:</b> REST + WebSocket"))
    story.append(make_table(
        ["Aspect", "gRPC + MQTT (Chosen)", "REST + WebSocket (Runner-up)"],
        [
            ["Streaming", "Native (bidirectional)", "WebSocket for async, REST for sync"],
            ["Code generation", "Automatic (proto -> stubs)", "Manual (OpenAPI -> client code)"],
            ["Payload efficiency", "Protobuf binary (small)", "JSON (larger)"],
            ["Browser compatibility", "Requires gRPC-Web proxy", "Native"],
            ["Complexity", "Higher (two protocols)", "Lower (HTTP everywhere)"],
        ],
        col_widths=[CONTENT_W * 0.20, CONTENT_W * 0.40, CONTENT_W * 0.40]
    ))

    story.append(Heading2("16.7 ADR-028: HDBSCAN vs K-Means", "sec16_7"))
    story.append(body("<b>Chosen:</b> HDBSCAN (Confidence: MEDIUM) | <b>Runner-up:</b> K-Means with silhouette-based selection"))
    story.append(make_table(
        ["Aspect", "HDBSCAN (Chosen)", "K-Means (Runner-up)"],
        [
            ["Cluster count", "Automatic (no preset)", "Must specify K in advance"],
            ["Noise handling", "Excellent (outlier trips as noise)", "No noise model"],
            ["Cluster shape", "Arbitrary (density-based)", "Spherical only"],
            ["Stability", "Deterministic", "Depends on initialization"],
            ["Computational cost", "Higher (~30 seconds per session)", "Lower (~2 seconds per session)"],
        ],
        col_widths=[CONTENT_W * 0.20, CONTENT_W * 0.40, CONTENT_W * 0.40]
    ))

    # ═══════════════ SECTION 17: BUILD GUIDE ═══════════════
    story.append(Heading1("17. Build Guide and Effort Estimates", "sec17"))
    story.append(Heading2("17.1 Build Priority Order", "sec17_1"))
    story.append(body("The critical path to a working demo follows this sequence:"))
    story.append(make_table(
        ["#", "Component", "Effort", "Developer Skill"],
        [
            ["1", "Wire protocol (COBS + framing + dispatch)", "2-3 weeks", "Senior embedded C"],
            ["2", "Kill switch ISR + hardware relay control", "1-2 weeks", "Embedded C + hardware"],
            ["3", "VM safety invariants + execution engine", "3-4 weeks", "Senior embedded C + VM/compiler"],
            ["4", "JSON-to-bytecode compiler", "1-2 weeks", "C + JSON parsing"],
            ["5", "I/O abstraction + 5 drivers", "3-4 weeks", "Embedded C + hardware"],
            ["6", "Boot sequence + role assignment", "1-2 weeks", "Embedded C (ESP-IDF)"],
            ["7", "Observation buffer + serial bridge", "1-2 weeks", "Python + embedded protocols"],
            ["8", "Node manager + reflex orchestrator", "2-3 weeks", "Python + gRPC"],
            ["9", "Trust score + autonomy state", "1-2 weeks", "Python + statistics"],
            ["10", "Chat interface + LLM integration", "2-3 weeks", "Python + NLP"],
            ["11", "Learning pipeline", "4-6 weeks", "Python + ML"],
            ["12", "A/B testing framework", "2-3 weeks", "Python + statistics"],
            ["13", "Cloud code generation pipeline", "3-4 weeks", "Python + LLM API"],
            ["14", "Testing (unit + integration + HIL)", "4-6 weeks", "All of the above"],
        ],
        col_widths=[CONTENT_W * 0.05, CONTENT_W * 0.40, CONTENT_W * 0.18, CONTENT_W * 0.37]
    ))

    story.append(Heading2("17.2 Effort Summary", "sec17_2"))
    story.append(make_table(
        ["Team Size", "Calendar Time", "Notes"],
        [
            ["1 senior full-stack + embedded developer", "30-40 weeks", "Sequential, all components"],
            ["3 developers (parallel work)", "12-16 weeks", "Critical path: weeks 1-8 for wire protocol + VM + safety"],
            ["5 developers (maximum parallelism)", "10-12 weeks", "Firmware and Jetson work fully parallelized"],
        ],
        col_widths=[CONTENT_W * 0.35, CONTENT_W * 0.18, CONTENT_W * 0.47]
    ))

    story.append(Heading2("17.3 Fastest Path to Demo", "sec17_3"))
    story.append(body("<b>Week 8: LED Blinker Reflex Controlled by Chat</b>"))
    for i, txt in enumerate([
        "Wire protocol (COBS encode/decode, message dispatch)",
        "Kill switch + watchdog",
        "VM safety invariants + basic execution",
        "Simple LED GPIO driver",
        "Jetson serial bridge + node manager",
        "Chat interface sends REFLEX_DEPLOY",
        'User types "blink the LED every 500ms" -> reflex deploys -> LED blinks',
    ], 1):
        story.append(numbered(txt, i))

    story.append(spacer(6))
    story.append(body("<b>Week 16: Full Marine Autopilot with Learning</b>"))
    for i, txt in enumerate([
        "Complete all 32 VM opcodes including PID_COMPUTE",
        "I2C compass driver + rudder PWM driver",
        "Full observation pipeline",
        "Cross-correlation pattern discovery",
        "Heading-hold PID reflex generated from demonstration",
        "A/B test proposed reflex against human baseline",
        "Trust score tracking and autonomy level progression",
    ], 1):
        story.append(numbered(txt, i))

    # ═══════════════ SECTION 18: RISK MATRIX ═══════════════
    story.append(Heading1("18. Risk Matrix", "sec18"))
    story.append(make_table(
        ["Risk", "Likelihood", "Impact", "Mitigation"],
        [
            ["VM bytecode bug causes incorrect actuator output", "Medium", "Critical", "Extensive unit tests for every opcode; formal cycle-count verification; actuator clamping"],
            ["COBS edge case with 256 consecutive zero bytes", "Low", "Medium", "Fuzz testing with random binary payloads; reference C implementation"],
            ["Observation buffer corrupts during power loss", "Low", "Medium", "PSRAM buffer is volatile-by-design; LittleFS journaling protects reflex files"],
            ["Cloud LLM generates unsafe code passing validation", "Medium", "Critical", "Separate LLM for validation; MISRA-C rules; simulation; human approval"],
            ["Trust score parameters poorly tuned", "Medium", "Medium", "Configurable per-subsystem; start conservative (alpha_gain=0.001)"],
            ["Jetson thermal throttling under load", "Medium", "Medium", "Monitor temperature; reduce LLM concurrency; shed services at 85C"],
            ["Starlink latency causes timeout", "Medium", "Low", "60-second timeout; queue-and-forward; local model handles 70%"],
            ["MCU flash wear from frequent OTA updates", "Low", "Medium", "Flash wear-leveling in LittleFS; OTA writes to dedicated partition"],
            ["I2C bus lockup in noisy environment", "Medium", "Medium", "Bus recovery procedure; 100kHz fallback; lock detection ISR"],
            ["Kill switch contact corrosion (marine)", "Low", "Critical", "IP67 sealed switch; weekly manual test; annual replacement if >10ms"],
        ],
        col_widths=[CONTENT_W * 0.28, CONTENT_W * 0.10, CONTENT_W * 0.10, CONTENT_W * 0.52]
    ))

    # ═══════════════ SECTION 19: FILE MANIFEST ═══════════════
    story.append(Heading1("19. Complete File Manifest", "sec19"))

    story.append(Heading2("19.1 NEXUS Specifications (nexus_specs/)", "sec19_1"))
    story.append(make_table(
        ["File", "Lines", "Description"],
        [
            ["00_MASTER_INDEX.md", "139", "Master index of all specification files with statistics"],
            ["ARCHITECTURE_DECISION_RECORDS.md", "~800", "28 ADRs with confidence levels, alternatives, triggers"],
            ["SENIOR_ENGINEER_BUILD_GUIDE.md", "~700", "Reading order, 9 build steps, test strategy, metrics"],
            ["protocol/wire_protocol_spec.md", "1,047", "COBS framing, 10-byte header, 28 message types, 75 error codes"],
            ["protocol/message_payloads.json", "2,156", "JSON Schema for all 23 JSON message payloads"],
            ["firmware/reflex_bytecode_vm_spec.md", "2,487", "Complete 32-opcode ISA, 8-byte encoding, memory model, safety"],
            ["firmware/io_driver_interface.h", "829", "C header with driver vtable, pin config types, error codes"],
            ["firmware/io_driver_registry.json", "2,408", "9+ I2C drivers with register sequences and selftest procedures"],
            ["firmware/memory_map_and_partitions.md", "685", "SRAM/PSRAM maps, flash partition table, DMA allocation"],
            ["jetson/cluster_api.proto", "934", "6 gRPC services, 80+ message types"],
            ["jetson/mqtt_topics.json", "668", "13 MQTT topics with QoS/retain, payload schemas"],
            ["jetson/module_interface.py", "1,153", "Python ABC for Jetson modules with lifecycle, hot-reload"],
            ["jetson/learning_pipeline_spec.md", "2,140", "5 pattern discovery algorithms, A/B testing, reflex synthesis"],
            ["safety/safety_policy.json", "864", "10 global safety rules, 7 actuator profiles, 6-stage validation"],
            ["safety/safety_system_spec.md", "1,296", "Four-tier architecture, kill switch, watchdog, heartbeat"],
            ["safety/trust_score_algorithm_spec.md", "2,414", "Mathematical trust formula, 12 parameters, C and Python implementations"],
            ["ports/hardware_compatibility_matrix.json", "2,128", "13 MCU evaluations with porting effort"],
        ],
        col_widths=[CONTENT_W * 0.36, CONTENT_W * 0.08, CONTENT_W * 0.56]
    ))

    story.append(Heading2("19.2 Post-Coding Platform (post_coding_platform/)", "sec19_2"))
    story.append(make_table(
        ["File", "Description"],
        [
            ["Post_Coding_Platform_Developer_Guide.pdf", "25-page annotated developer guide with 15 key decisions"],
            ["schemas/node_role_config.json", "ESP32 role configuration schema"],
            ["schemas/reflex_definition.json", "Reflex behavior definition schema"],
            ["schemas/serial_protocol.json", "COBS-framed wire protocol spec"],
            ["schemas/autonomy_state.json", "INCREMENTS autonomy state tracking schema"],
        ],
        col_widths=[CONTENT_W * 0.40, CONTENT_W * 0.60]
    ))

    story.append(Heading2("19.3 Autopilot Design (autopilot_design/)", "sec19_3"))
    story.append(make_table(
        ["File", "Description"],
        [
            ["01_marine_pid_engineering.txt", "PID engineering brief with Iron Mike comparison"],
            ["02_esp32_architecture.txt", "ESP32 autopilot architecture design"],
            ["03_hydraulic_control.txt", "Hydraulic steering system design"],
            ["04_opensource_analysis.txt", "Open-source autopilot analysis"],
            ["05_consensus_architecture.txt", "Multi-sensor consensus architecture"],
            ["06_pid_simulation.py", "6-scenario PID simulation with plots"],
            ["07_simulation_results.txt", "Simulation results analysis"],
            ["08_expert_review.txt", "Expert review with 33 issues identified"],
            ["09_fixes_applied.txt", "14 safety fixes applied"],
            ["config/", "6 JSON configuration files (safety, firmware, pins, etc.)"],
            ["plots/", "6 simulation result plots (PNG)"],
        ],
        col_widths=[CONTENT_W * 0.40, CONTENT_W * 0.60]
    ))

    story.append(Heading2("19.4 Vessel Platform (vessel_platform/)", "sec19_4"))
    story.append(make_table(
        ["File", "Description"],
        [
            ["10_esp32_firmware_architecture.txt", "Universal ESP32 firmware design"],
            ["11_jetson_cluster_architecture.txt", "3-Jetson cluster architecture"],
            ["12_network_physical_architecture.txt", "RS-422 network design"],
            ["13_calibration_onboarding.txt", "8-step calibration wizard"],
            ["14_marine_ai_systems.txt", "Marine AI and fish identification"],
            ["15_redundancy_failover.txt", "Dual-ESP32 redundancy with <100ms failover"],
            ["16_master_consensus_architecture.txt", "Master consensus across all subsystems"],
            ["config/", "6 JSON configuration files (cluster, roles, network, etc.)"],
        ],
        col_widths=[CONTENT_W * 0.40, CONTENT_W * 0.60]
    ))

    # ═══════════════ SECTION 20: EVOLUTION HISTORY ═══════════════
    story.append(Heading1("20. Evolution History: From Autopilot to General Platform", "sec20"))

    story.append(Heading3("Phase 1: ESP32 AI Chatbot Comparison", "sec20_p1"))
    story.append(body(
        "Research into ESP32-based AI chatbot approaches, including Espressif's private agents platform. Established that "
        "on-device LLM inference is not viable on ESP32-class hardware, driving the split between MCU limbs and Jetson brains."
    ))

    story.append(Heading3("Phase 2: Jetson + ESP32 Serial JSON Architecture", "sec20_p2"))
    story.append(body(
        "Designed the fundamental architecture: Jetson as the cognitive brain, ESP32 as the real-time limb, connected via "
        "serial JSON. Established the philosophical separation between thinking (Jetson) and acting (ESP32)."
    ))

    story.append(Heading3("Phase 3: Marine Autopilot with PID/Iron Mike", "sec20_p3"))
    story.append(body(
        "Engineering-focused autopilot design. Implemented PID heading-hold control at 10Hz with comprehensive simulation "
        "across 6 scenarios (step response, wind disturbance, course tracking, Jetson failure, gain comparison, sea state "
        "sensitivity). Identified and resolved 33 issues."
    ))

    story.append(Heading3("Phase 4: Expert Review and Safety Fixes", "sec20_p4"))
    story.append(body(
        "14 critical safety fixes applied: NC kill switch added, TC4420 gate driver (MOSFET voltage mismatch), integral "
        "anti-windup 5->1500 deg*sec, heading wraparound, solenoid timeout, I2C derating, watchdog hardening, startup self-test."
    ))

    story.append(Heading3("Phase 5: Full Vessel Robotics Platform", "sec20_p5"))
    story.append(body(
        "Scaled from single autopilot to complete vessel robotics: 3+ Jetson cluster, dual-ESP32 redundancy (<100ms failover), "
        "fish identification, 8-step calibration wizard, comprehensive configuration system."
    ))

    story.append(Heading3("Phase 6: Post-Coding Platform Design", "sec20_p6"))
    story.append(body(
        "Philosophical breakthrough: humans never write code. ESP32s as universal limbs (one binary for all roles), Jetsons "
        "as brains that learn from observation. Introduced the learning loop: observe -> discover patterns -> synthesize reflex "
        "-> A/B test -> accept/reject. Produced annotated developer guide."
    ))

    story.append(Heading3("Phase 7: Production Specification Synthesis (This Report)", "sec20_p7"))
    story.append(body(
        "Simulated all ideas into specific schemas. Documented every architecture choice with confidence levels and "
        "second-place alternatives. Produced 21 specification files (~19,200 lines) covering every layer from hardware pins "
        "to cloud connectivity. Delivered production-ready documentation for a senior engineer to build the complete system."
    ))

    # ─── Build ───
    doc.multiBuild(story)
    return doc


class CoverPage(Flowable):
    """Custom cover page flowable."""
    def __init__(self):
        super().__init__()
        self.width = PAGE_W
        self.height = PAGE_H

    def draw(self):
        c = self.canv
        w = PAGE_W
        h = PAGE_H

        # Background
        c.setFillColor(COVER_BG)
        c.rect(0, 0, w, h, fill=1, stroke=0)

        # Accent bar at top
        c.setFillColor(COVER_ACCENT)
        c.rect(0, h - 8, w, 8, fill=1, stroke=0)

        # Accent bar at bottom
        c.rect(0, 0, w, 8, fill=1, stroke=0)

        # Side accent
        c.setFillColor(HexColor("#2E75B6"))
        c.rect(0, h * 0.15, 4, h * 0.55, fill=1, stroke=0)

        # Title block
        c.setFillColor(white)
        c.setFont("TimesNewRoman", 32)
        c.drawCentredString(w / 2, h * 0.62, "NEXUS Platform")

        c.setFont("TimesNewRoman", 16)
        c.drawCentredString(w / 2, h * 0.57, "Final Production Synthesis Report")

        # Divider line
        c.setStrokeColor(MEDIUM_BLUE)
        c.setLineWidth(2)
        c.line(w * 0.25, h * 0.53, w * 0.75, h * 0.53)

        # Subtitle
        c.setFillColor(HexColor("#BDD7EE"))
        c.setFont("TimesNewRoman", 13)
        c.drawCentredString(w / 2, h * 0.48, "Post-Coding Distributed Intelligence Platform")
        c.drawCentredString(w / 2, h * 0.45, "Production Specification")

        # Metadata
        c.setFillColor(HexColor("#D6E4F0"))
        c.setFont("TimesNewRoman", 11)
        y = h * 0.35
        c.drawCentredString(w / 2, y, "Version 1.0.0  |  2026-03-29")
        c.drawCentredString(w / 2, y - 20, "Classification: Production-Ready Specification")
        c.drawCentredString(w / 2, y - 40, "Author: AI Architecture Team")
        c.drawCentredString(w / 2, y - 60, "Status: Ready for Senior Engineer Review")

        # Bottom tagline
        c.setFillColor(HexColor("#8DB4E2"))
        c.setFont("TimesNewRoman", 9)
        c.drawCentredString(w / 2, h * 0.10, "21 Specification Files  |  ~19,200 Lines  |  28 ADRs  |  SIL 1 Safety")


if __name__ == "__main__":
    print("Building NEXUS Platform PDF...")
    doc = build_pdf()
    # Get page count
    import subprocess
    result = subprocess.run(
        ["python3", "-c",
         f"from reportlab.lib.pagesizes import letter; from PyPDF2 import PdfReader; "
         f"r = PdfReader('{OUTPUT_PATH}'); print(len(r.pages))"],
        capture_output=True, text=True
    )
    try:
        page_count = int(result.stdout.strip())
    except Exception:
        page_count = "unknown"
    print(f"PDF generated successfully: {OUTPUT_PATH}")
    print(f"Total pages: {page_count}")
