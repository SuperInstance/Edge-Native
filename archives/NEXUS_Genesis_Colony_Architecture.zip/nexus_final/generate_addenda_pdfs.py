#!/usr/bin/env python3
"""
Generate PDF versions of all 7 NEXUS engineering addendum documents.
Uses reportlab to create professionally formatted PDFs from markdown source files.
"""

import os
import re
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import inch
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.colors import HexColor, black, white, Color
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_JUSTIFY
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    PageBreak, HRFlowable, KeepTogether, Preformatted
)
from reportlab.platypus.flowables import Flowable
from reportlab.lib import colors

# ─── Configuration ───────────────────────────────────────────────────────────

OUTPUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "addenda")

MARKDOWN_FILES = [
    "00_Master_Addendum_Index.md",
    "01_Engineering_Pitfalls_and_Gotchas.md",
    "02_Performance_Budgets_and_Optimization.md",
    "03_Hardware_BringUp_Checklist.md",
    "04_Safety_Validation_Playbook.md",
    "05_Integration_Test_Plan.md",
    "06_Code_Review_Checklist.md",
]

PAGE_WIDTH, PAGE_HEIGHT = A4
LEFT_MARGIN = RIGHT_MARGIN = TOP_MARGIN = BOTTOM_MARGIN = inch
CONTENT_WIDTH = PAGE_WIDTH - LEFT_MARGIN - RIGHT_MARGIN

# Colors
NEXUS_BLUE = HexColor("#1a365d")
NEXUS_ACCENT = HexColor("#2b6cb0")
NEXUS_GRAY = HexColor("#4a5568")
NEXUS_LIGHT_GRAY = HexColor("#f7fafc")
NEXUS_BORDER = HexColor("#cbd5e0")
CODE_BG = HexColor("#f0f4f8")
TABLE_HEADER_BG = HexColor("#1a365d")
TABLE_ALT_ROW = HexColor("#edf2f7")
QUOTE_BORDER = HexColor("#2b6cb0")
QUOTE_BG = HexColor("#ebf8ff")


# ─── Styles ──────────────────────────────────────────────────────────────────

def build_styles(doc_title):
    """Build all paragraph styles for the document."""
    styles = {}

    styles["title"] = ParagraphStyle(
        "NEXUSTitle",
        fontName="Helvetica-Bold",
        fontSize=18,
        leading=22,
        textColor=NEXUS_BLUE,
        spaceAfter=4,
        alignment=TA_LEFT,
    )

    styles["subtitle"] = ParagraphStyle(
        "NEXUSSubtitle",
        fontName="Helvetica",
        fontSize=9,
        leading=12,
        textColor=NEXUS_GRAY,
        spaceAfter=12,
    )

    styles["h1"] = ParagraphStyle(
        "NEXUSH1",
        fontName="Helvetica-Bold",
        fontSize=16,
        leading=20,
        textColor=NEXUS_BLUE,
        spaceBefore=16,
        spaceAfter=8,
        borderWidth=0,
        borderColor=NEXUS_BLUE,
        borderPadding=0,
    )

    styles["h2"] = ParagraphStyle(
        "NEXUSH2",
        fontName="Helvetica-Bold",
        fontSize=13,
        leading=17,
        textColor=NEXUS_ACCENT,
        spaceBefore=14,
        spaceAfter=6,
    )

    styles["h3"] = ParagraphStyle(
        "NEXUSH3",
        fontName="Helvetica-Bold",
        fontSize=11,
        leading=14,
        textColor=NEXUS_GRAY,
        spaceBefore=10,
        spaceAfter=4,
    )

    styles["body"] = ParagraphStyle(
        "NEXUSBody",
        fontName="Helvetica",
        fontSize=9,
        leading=12,  # ~1.3x line spacing for 9pt
        textColor=black,
        spaceAfter=4,
        alignment=TA_JUSTIFY,
    )

    styles["bold_text"] = ParagraphStyle(
        "NEXUSBoldBody",
        parent=styles["body"],
        fontName="Helvetica-Bold",
    )

    styles["bullet"] = ParagraphStyle(
        "NEXUSBullet",
        fontName="Helvetica",
        fontSize=9,
        leading=12,
        textColor=black,
        leftIndent=18,
        bulletIndent=6,
        spaceAfter=2,
        alignment=TA_LEFT,
    )

    styles["bullet_nested"] = ParagraphStyle(
        "NEXUSBulletNested",
        fontName="Helvetica",
        fontSize=9,
        leading=12,
        textColor=black,
        leftIndent=36,
        bulletIndent=24,
        spaceAfter=2,
        alignment=TA_LEFT,
    )

    styles["quote"] = ParagraphStyle(
        "NEXUSQuote",
        fontName="Helvetica-Oblique",
        fontSize=8.5,
        leading=11,
        textColor=NEXUS_GRAY,
        leftIndent=14,
        rightIndent=8,
        spaceBefore=4,
        spaceAfter=4,
        borderWidth=0,
        borderColor=QUOTE_BORDER,
        borderPadding=4,
    )

    styles["code"] = ParagraphStyle(
        "NEXUSCode",
        fontName="Courier",
        fontSize=7,
        leading=9,
        textColor=HexColor("#2d3748"),
        backColor=CODE_BG,
        leftIndent=8,
        rightIndent=8,
        spaceBefore=2,
        spaceAfter=2,
        borderWidth=0.5,
        borderColor=NEXUS_BORDER,
        borderPadding=4,
    )

    styles["table_header"] = ParagraphStyle(
        "NEXUSTableHeader",
        fontName="Helvetica-Bold",
        fontSize=8,
        leading=10,
        textColor=white,
        alignment=TA_CENTER,
    )

    styles["table_cell"] = ParagraphStyle(
        "NEXUSTableCell",
        fontName="Helvetica",
        fontSize=8,
        leading=10,
        textColor=black,
        alignment=TA_LEFT,
    )

    styles["table_cell_center"] = ParagraphStyle(
        "NEXUSTableCellCenter",
        fontName="Helvetica",
        fontSize=8,
        leading=10,
        textColor=black,
        alignment=TA_CENTER,
    )

    styles["checkbox"] = ParagraphStyle(
        "NEXUSCheckbox",
        fontName="Helvetica",
        fontSize=9,
        leading=12,
        textColor=black,
        leftIndent=18,
        spaceAfter=2,
    )

    return styles


# ─── Custom Flowables ────────────────────────────────────────────────────────

class HorizontalRule(Flowable):
    """A horizontal rule flowable."""
    def __init__(self, width, thickness=0.5, color=NEXUS_BORDER, dash=None):
        Flowable.__init__(self)
        self.width = width
        self.height = thickness + 4
        self.thickness = thickness
        self.color = color
        self.dash = dash

    def draw(self):
        self.canv.setStrokeColor(self.color)
        self.canv.setLineWidth(self.thickness)
        if self.dash:
            self.canv.setDash(self.dash)
        self.canv.line(0, 2, self.width, 2)


class QuoteBlock(Flowable):
    """A blockquote with left border and background."""
    def __init__(self, text, width, style):
        Flowable.__init__(self)
        self.text = text
        self._width = width
        self.style = style
        # Pre-calculate height
        p = Paragraph(text, style)
        w, h = p.wrap(width - 20, 1000)
        self.height = h + 8
        self.width = width

    def draw(self):
        # Background
        self.canv.setFillColor(QUOTE_BG)
        self.canv.rect(0, 0, self._width, self.height, stroke=0, fill=1)
        # Left border
        self.canv.setStrokeColor(QUOTE_BORDER)
        self.canv.setLineWidth(3)
        self.canv.line(0, 0, 0, self.height)
        # Text
        p = Paragraph(self.text, self.style)
        p.wrap(self._width - 20, 1000)
        p.drawOn(self.canv, 14, 4)


# ─── Markdown Parser ─────────────────────────────────────────────────────────

def escape_xml(text):
    """Escape special XML characters for reportlab Paragraph."""
    text = text.replace("&", "&amp;")
    text = text.replace("<", "&lt;")
    text = text.replace(">", "&gt;")
    return text


def inline_format(text):
    """Apply inline markdown formatting (bold, italic, code)."""
    # Escape XML first
    text = escape_xml(text)

    # Inline code: `code`
    text = re.sub(
        r'`([^`]+)`',
        r'<font name="Courier" size="8" color="#c53030">\1</font>',
        text
    )

    # Bold + Italic: ***text***
    text = re.sub(
        r'\*\*\*(.+?)\*\*\*',
        r'<b><i>\1</i></b>',
        text
    )

    # Bold: **text**
    text = re.sub(
        r'\*\*(.+?)\*\*',
        r'<b>\1</b>',
        text
    )

    # Italic: *text* (but not within already-formatted tags)
    text = re.sub(
        r'(?<!\*)\*(?!\*)(.+?)(?<!\*)\*(?!\*)',
        r'<i>\1</i>',
        text
    )

    return text


def parse_table(lines):
    """Parse markdown table lines into a reportlab Table."""
    rows = []
    header_done = False

    for line in lines:
        stripped = line.strip()
        if not stripped.startswith("|"):
            continue
        # Remove leading/trailing pipes and split
        cells = [c.strip() for c in stripped.strip("|").split("|")]
        if not cells:
            continue
        # Skip separator rows like |---|---|
        if all(re.match(r'^[-:]+$', c) for c in cells):
            header_done = True
            continue

        row = []
        for cell in cells:
            formatted = inline_format(cell)
            row.append(formatted)
        rows.append(row)

    return rows


def parse_markdown(md_content, styles, doc_name):
    """Parse markdown content into a list of reportlab flowables."""
    elements = []
    lines = md_content.split("\n")
    i = 0
    first_h1 = True
    title_text = ""

    # Determine document name from filename
    doc_name_clean = doc_name.replace("_", " ").replace(".md", "").replace("-", " ")

    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        # ── Empty line ──
        if not stripped:
            i += 1
            continue

        # ── Horizontal rule ──
        if re.match(r'^---+$', stripped):
            elements.append(Spacer(1, 4))
            elements.append(HorizontalRule(CONTENT_WIDTH))
            elements.append(Spacer(1, 4))
            i += 1
            continue

        # ── Code blocks ──
        if stripped.startswith("```"):
            code_lines = []
            lang = stripped[3:].strip()
            i += 1
            while i < len(lines) and not lines[i].strip().startswith("```"):
                code_lines.append(lines[i])
                i += 1
            i += 1  # skip closing ```
            code_text = "\n".join(code_lines)
            if code_text:
                # Use Preformatted for exact whitespace preservation
                code_escaped = escape_xml(code_text)
                code_style = ParagraphStyle(
                    "codeBlock",
                    fontName="Courier",
                    fontSize=7,
                    leading=9,
                    textColor=HexColor("#2d3748"),
                )
                p = Preformatted(code_escaped, code_style)
                # Wrap in a table for background
                t = Table([[p]], colWidths=[CONTENT_WIDTH - 8])
                t.setStyle(TableStyle([
                    ("BACKGROUND", (0, 0), (-1, -1), CODE_BG),
                    ("BOX", (0, 0), (-1, -1), 0.5, NEXUS_BORDER),
                    ("LEFTPADDING", (0, 0), (-1, -1), 8),
                    ("RIGHTPADDING", (0, 0), (-1, -1), 8),
                    ("TOPPADDING", (0, 0), (-1, -1), 4),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
                ]))
                elements.append(Spacer(1, 2))
                elements.append(t)
                elements.append(Spacer(1, 2))
            continue

        # ── Tables ──
        if stripped.startswith("|") and i + 1 < len(lines):
            # Collect all table rows
            table_lines = []
            j = i
            while j < len(lines) and lines[j].strip().startswith("|"):
                table_lines.append(lines[j])
                j += 1
            rows = parse_table(table_lines)
            if rows:
                # Build table flowable
                table_data = []
                for ri, row in enumerate(rows):
                    table_row = []
                    for cell in row:
                        if ri == 0:
                            table_row.append(Paragraph(cell, styles["table_header"]))
                        else:
                            # Check if cell content looks like it should be centered
                            clean = cell.replace("&lt;", "").replace("&gt;", "").replace("&amp;", "").strip()
                            if len(clean) < 30 and not clean.startswith("<"):
                                table_row.append(Paragraph(cell, styles["table_cell_center"]))
                            else:
                                table_row.append(Paragraph(cell, styles["table_cell"]))
                    table_data.append(table_row)

                # Calculate column widths
                num_cols = len(rows[0]) if rows else 1
                col_width = CONTENT_WIDTH / num_cols
                col_widths = [col_width] * num_cols

                t = Table(table_data, colWidths=col_widths, repeatRows=1)
                style_cmds = [
                    ("BACKGROUND", (0, 0), (-1, 0), TABLE_HEADER_BG),
                    ("TEXTCOLOR", (0, 0), (-1, 0), white),
                    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                    ("FONTSIZE", (0, 0), (-1, 0), 8),
                    ("BOTTOMPADDING", (0, 0), (-1, 0), 4),
                    ("TOPPADDING", (0, 0), (-1, 0), 4),
                    ("GRID", (0, 0), (-1, -1), 0.5, NEXUS_BORDER),
                    ("LEFTPADDING", (0, 0), (-1, -1), 4),
                    ("RIGHTPADDING", (0, 0), (-1, -1), 4),
                    ("TOPPADDING", (0, 1), (-1, -1), 3),
                    ("BOTTOMPADDING", (0, 1), (-1, -1), 3),
                    ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ]
                # Alternating row colors
                for ri in range(1, len(table_data)):
                    if ri % 2 == 0:
                        style_cmds.append(("BACKGROUND", (0, ri), (-1, ri), TABLE_ALT_ROW))

                t.setStyle(TableStyle(style_cmds))
                elements.append(Spacer(1, 4))
                elements.append(t)
                elements.append(Spacer(1, 4))

            i = j
            continue

        # ── Blockquotes ──
        if stripped.startswith(">"):
            quote_lines = []
            while i < len(lines) and lines[i].strip().startswith(">"):
                quote_text = lines[i].strip().lstrip("> ").strip()
                quote_lines.append(quote_text)
                i += 1
            quote_text = " ".join(quote_lines)
            if quote_text:
                formatted = inline_format(quote_text)
                elements.append(QuoteBlock(formatted, CONTENT_WIDTH, styles["quote"]))
            continue

        # ── Checkbox items ──
        if re.match(r'^- \[[ x]\]', stripped):
            check = "☐" if "[ ]" in stripped else "☑"
            text = stripped.replace("- [ ]", "").replace("- [x]", "").strip()
            text = check + " " + text
            elements.append(Paragraph(inline_format(escape_xml(text)), styles["checkbox"]))
            i += 1
            continue

        # ── Bullet lists ──
        if stripped.startswith("- "):
            bullet_items = []
            while i < len(lines) and (lines[i].strip().startswith("- ") or
                                       (lines[i].strip() and not lines[i].strip().startswith("#") and
                                        not lines[i].strip().startswith("|") and
                                        not lines[i].strip().startswith("```") and
                                        not re.match(r'^---+$', lines[i].strip()) and
                                        lines[i].startswith("  "))):
                item_text = lines[i].strip()
                if item_text.startswith("- "):
                    bullet_items.append(("bullet", item_text[2:]))
                elif item_text.startswith("  - "):
                    bullet_items.append(("nested", item_text.strip().lstrip("- ")))
                else:
                    bullet_items.append(("bullet", item_text[2:] if item_text.startswith("- ") else item_text))
                i += 1

            for btype, btext in bullet_items:
                style_key = "bullet_nested" if btype == "nested" else "bullet"
                bullet_char = "•" if btype == "bullet" else "◦"
                elements.append(Paragraph(
                    f'{bullet_char} {inline_format(btext)}',
                    styles[style_key]
                ))
            continue

        # ── Numbered lists ──
        if re.match(r'^\d+\.\s', stripped):
            num_match = re.match(r'^(\d+)\.\s(.+)$', stripped)
            if num_match:
                num = num_match.group(1)
                text = num_match.group(2)
                elements.append(Paragraph(
                    f'{num}. {inline_format(text)}',
                    styles["bullet"]
                ))
                i += 1
                continue

        # ── Headings ──
        if stripped.startswith("### "):
            text = stripped[4:]
            elements.append(Paragraph(inline_format(text), styles["h3"]))
            i += 1
            continue

        if stripped.startswith("## "):
            text = stripped[3:]
            elements.append(Paragraph(inline_format(text), styles["h2"]))
            i += 1
            continue

        if stripped.startswith("# "):
            text = stripped[2:]
            if first_h1:
                title_text = text
                first_h1 = False
            elements.append(Paragraph(inline_format(text), styles["h1"]))
            i += 1
            continue

        # ── Regular paragraphs ──
        # Collect multi-line paragraph
        para_lines = [stripped]
        i += 1
        while i < len(lines):
            next_stripped = lines[i].strip()
            if (not next_stripped or
                next_stripped.startswith("#") or
                next_stripped.startswith("|") or
                next_stripped.startswith("- ") or
                next_stripped.startswith("```") or
                next_stripped.startswith(">") or
                re.match(r'^---+$', next_stripped) or
                re.match(r'^\d+\.\s', next_stripped)):
                break
            para_lines.append(next_stripped)
            i += 1

        para_text = " ".join(para_lines)
        formatted = inline_format(para_text)
        elements.append(Paragraph(formatted, styles["body"]))

    return elements, title_text


# ─── Page Templates ──────────────────────────────────────────────────────────

def header_footer(canvas, doc, doc_name):
    """Draw header and footer on each page."""
    canvas.saveState()

    # Header
    canvas.setFont("Helvetica-Bold", 7)
    canvas.setFillColor(NEXUS_BLUE)
    canvas.drawString(LEFT_MARGIN, PAGE_HEIGHT - 30, "NEXUS Engineering Addenda")

    canvas.setFont("Helvetica", 7)
    canvas.setFillColor(NEXUS_GRAY)
    # Right-align doc name
    header_text = doc_name
    canvas.drawRightString(PAGE_WIDTH - RIGHT_MARGIN, PAGE_HEIGHT - 30, header_text)

    # Header line
    canvas.setStrokeColor(NEXUS_BLUE)
    canvas.setLineWidth(1)
    canvas.line(LEFT_MARGIN, PAGE_HEIGHT - 35, PAGE_WIDTH - RIGHT_MARGIN, PAGE_HEIGHT - 35)

    # Footer
    canvas.setStrokeColor(NEXUS_BORDER)
    canvas.setLineWidth(0.5)
    canvas.line(LEFT_MARGIN, BOTTOM_MARGIN - 10, PAGE_WIDTH - RIGHT_MARGIN, BOTTOM_MARGIN - 10)

    canvas.setFont("Helvetica", 7)
    canvas.setFillColor(NEXUS_GRAY)
    canvas.drawString(LEFT_MARGIN, BOTTOM_MARGIN - 22, "NEXUS Platform — Confidential")

    # Page number
    page_num = canvas.getPageNumber()
    canvas.drawRightString(PAGE_WIDTH - RIGHT_MARGIN, BOTTOM_MARGIN - 22, f"Page {page_num}")

    canvas.restoreState()


def first_page_header(canvas, doc, doc_name):
    """Draw header/footer on the first page."""
    canvas.saveState()

    # Header
    canvas.setFont("Helvetica-Bold", 7)
    canvas.setFillColor(NEXUS_BLUE)
    canvas.drawString(LEFT_MARGIN, PAGE_HEIGHT - 30, "NEXUS Engineering Addenda")

    canvas.setFont("Helvetica", 7)
    canvas.setFillColor(NEXUS_GRAY)
    canvas.drawRightString(PAGE_WIDTH - RIGHT_MARGIN, PAGE_HEIGHT - 30, doc_name)

    # Header line
    canvas.setStrokeColor(NEXUS_BLUE)
    canvas.setLineWidth(1)
    canvas.line(LEFT_MARGIN, PAGE_HEIGHT - 35, PAGE_WIDTH - RIGHT_MARGIN, PAGE_HEIGHT - 35)

    # Footer
    canvas.setStrokeColor(NEXUS_BORDER)
    canvas.setLineWidth(0.5)
    canvas.line(LEFT_MARGIN, BOTTOM_MARGIN - 10, PAGE_WIDTH - RIGHT_MARGIN, BOTTOM_MARGIN - 10)

    canvas.setFont("Helvetica", 7)
    canvas.setFillColor(NEXUS_GRAY)
    canvas.drawString(LEFT_MARGIN, BOTTOM_MARGIN - 22, "NEXUS Platform — Confidential")
    page_num = canvas.getPageNumber()
    canvas.drawRightString(PAGE_WIDTH - RIGHT_MARGIN, BOTTOM_MARGIN - 22, f"Page {page_num}")

    canvas.restoreState()


# ─── PDF Generation ──────────────────────────────────────────────────────────

def generate_pdf(md_path, pdf_path, doc_name):
    """Generate a PDF from a markdown file."""
    print(f"  Reading: {md_path}")
    with open(md_path, "r", encoding="utf-8") as f:
        md_content = f.read()

    # Build styles
    styles = build_styles(doc_name)

    # Create document
    doc = SimpleDocTemplate(
        pdf_path,
        pagesize=A4,
        leftMargin=LEFT_MARGIN,
        rightMargin=RIGHT_MARGIN,
        topMargin=TOP_MARGIN,
        bottomMargin=BOTTOM_MARGIN,
        title=f"NEXUS Engineering Addenda — {doc_name}",
        author="NEXUS Engineering Team",
        subject="NEXUS Platform Engineering Addenda",
    )

    # Parse markdown
    elements, title_text = parse_markdown(md_content, styles, doc_name)

    # Add title page header if not already present in content
    # (The content already has its own H1, so we just build the flowables)

    # Build with page templates
    doc.build(
        elements,
        onFirstPage=lambda c, d: first_page_header(c, d, doc_name),
        onLaterPages=lambda c, d: header_footer(c, d, doc_name),
    )

    return pdf_path


def main():
    """Generate all 7 PDF documents."""
    print("=" * 60)
    print("NEXUS Engineering Addenda — PDF Generator")
    print("=" * 60)
    print()

    os.makedirs(OUTPUT_DIR, exist_ok=True)

    generated = []
    errors = []

    for md_file in MARKDOWN_FILES:
        md_path = os.path.join(OUTPUT_DIR, md_file)
        pdf_name = md_file.replace(".md", ".pdf")
        pdf_path = os.path.join(OUTPUT_DIR, pdf_name)
        doc_name = md_file.replace(".md", "").replace("_", " ")

        if not os.path.exists(md_path):
            print(f"  ERROR: Source file not found: {md_path}")
            errors.append(md_file)
            continue

        try:
            print(f"Generating: {pdf_name}")
            generate_pdf(md_path, pdf_path, doc_name)
            file_size = os.path.getsize(pdf_path)
            generated.append((pdf_name, file_size))
            print(f"  OK — {file_size:,} bytes")
        except Exception as e:
            print(f"  ERROR: {e}")
            errors.append(md_file)

    # ── Summary ──
    print()
    print("=" * 60)
    print(f"Generated: {len(generated)}/{len(MARKDOWN_FILES)} PDFs")
    print()

    if generated:
        print("Files created:")
        for name, size in generated:
            print(f"  {name:55s} {size:>10,} bytes")

    if errors:
        print()
        print("Errors:")
        for name in errors:
            print(f"  FAILED: {name}")

    print()
    print("=" * 60)

    return len(errors) == 0


if __name__ == "__main__":
    success = main()
    exit(0 if success else 1)
