#!/usr/bin/env python3
"""Generate NEXUS Claude Code Prompt Series PDF from Markdown source."""

import re
import os
import sys
from reportlab.lib.pagesizes import letter
from reportlab.lib.units import inch, cm
from reportlab.lib.colors import HexColor, white, black
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_JUSTIFY, TA_LEFT, TA_CENTER
from reportlab.platypus import (
    BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer,
    Table, TableStyle, PageBreak, KeepTogether, NextPageTemplate,
    Flowable, HRFlowable
)
from reportlab.platypus.tableofcontents import TableOfContents
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase.pdfmetrics import registerFontFamily

# ─── Paths ───
OUTPUT_PATH = "/home/z/my-project/download/nexus_final/NEXUS_Claude_Code_Prompt_Series.pdf"
MD_PATH = "/home/z/my-project/download/nexus_final/NEXUS_Claude_Code_Prompt_Series.md"
TNR_PATH = "/usr/share/fonts/truetype/english/Times-New-Roman.ttf"
DJS_PATH = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"

# ─── Colors ───
DARK_BLUE = HexColor("#1F4E79")
LIGHT_GRAY = HexColor("#F5F5F5")
ACCENT_BLUE = HexColor("#2E75B6")
DARK_TEXT = HexColor("#333333")
CODE_BG = HexColor("#F5F5F5")
CODE_BORDER = HexColor("#DDDDDD")
WHITE = white

# ─── Page Dimensions ───
PAGE_W, PAGE_H = letter
MARGIN_L = 0.85 * inch
MARGIN_R = 0.85 * inch
MARGIN_T = 0.8 * inch
MARGIN_B = 0.8 * inch
CONTENT_W = PAGE_W - MARGIN_L - MARGIN_R

# ─── Register Fonts ───
pdfmetrics.registerFont(TTFont("TimesNewRoman", TNR_PATH))
pdfmetrics.registerFont(TTFont("DejaVuSans", DJS_PATH))
registerFontFamily("TimesNewRoman", normal="TimesNewRoman", bold="TimesNewRoman", italic="TimesNewRoman", boldItalic="TimesNewRoman")
registerFontFamily("DejaVuSans", normal="DejaVuSans", bold="DejaVuSans", italic="DejaVuSans", boldItalic="DejaVuSans")

# ─── Styles ───
sBody = ParagraphStyle(
    "Body", fontName="TimesNewRoman", fontSize=10, leading=14,
    alignment=TA_LEFT, textColor=DARK_TEXT, spaceAfter=4,
)
sH1 = ParagraphStyle(
    "H1", fontName="TimesNewRoman", fontSize=16, leading=20,
    alignment=TA_LEFT, textColor=DARK_BLUE, spaceBefore=18, spaceAfter=10,
)
sH2 = ParagraphStyle(
    "H2", fontName="TimesNewRoman", fontSize=13, leading=17,
    alignment=TA_LEFT, textColor=DARK_BLUE, spaceBefore=14, spaceAfter=8,
)
sH3 = ParagraphStyle(
    "H3", fontName="TimesNewRoman", fontSize=11, leading=14,
    alignment=TA_LEFT, textColor=ACCENT_BLUE, spaceBefore=10, spaceAfter=6,
)
sBullet = ParagraphStyle(
    "Bullet", fontName="TimesNewRoman", fontSize=10, leading=14,
    alignment=TA_LEFT, textColor=DARK_TEXT, spaceAfter=3,
    leftIndent=24, bulletIndent=12, bulletFontSize=10,
    bulletFontName="TimesNewRoman",
)
sNumbered = ParagraphStyle(
    "Numbered", fontName="TimesNewRoman", fontSize=10, leading=14,
    alignment=TA_LEFT, textColor=DARK_TEXT, spaceAfter=3,
    leftIndent=24, bulletIndent=12,
)
sCodeInline = ParagraphStyle(
    "CodeInline", fontName="DejaVuSans", fontSize=8.5, leading=11,
    alignment=TA_LEFT, textColor=HexColor("#2D2D2D"),
    backColor=CODE_BG, leftIndent=8, rightIndent=8,
    spaceBefore=3, spaceAfter=3,
    borderPadding=4,
)
sCodeBlock = ParagraphStyle(
    "CodeBlock", fontName="DejaVuSans", fontSize=7.5, leading=10,
    alignment=TA_LEFT, textColor=HexColor("#2D2D2D"),
    leftIndent=12, spaceBefore=2, spaceAfter=2,
)
sTableHeader = ParagraphStyle(
    "TableHeader", fontName="TimesNewRoman", fontSize=9, leading=12,
    alignment=TA_CENTER, textColor=white,
)
sTableCell = ParagraphStyle(
    "TableCell", fontName="TimesNewRoman", fontSize=9, leading=12,
    alignment=TA_LEFT, textColor=DARK_TEXT,
)
sTableCellCenter = ParagraphStyle(
    "TableCellCenter", fontName="TimesNewRoman", fontSize=9, leading=12,
    alignment=TA_CENTER, textColor=DARK_TEXT,
)
sCoverTitle = ParagraphStyle(
    "CoverTitle", fontName="TimesNewRoman", fontSize=28, leading=34,
    alignment=TA_CENTER, textColor=white,
)
sCoverSubtitle = ParagraphStyle(
    "CoverSubtitle", fontName="TimesNewRoman", fontSize=14, leading=20,
    alignment=TA_CENTER, textColor=HexColor("#BDD7EE"),
)
sCoverMeta = ParagraphStyle(
    "CoverMeta", fontName="TimesNewRoman", fontSize=11, leading=16,
    alignment=TA_CENTER, textColor=HexColor("#D6E4F0"),
)
sTOCTitle = ParagraphStyle(
    "TOCTitle", fontName="TimesNewRoman", fontSize=20, leading=26,
    alignment=TA_LEFT, textColor=DARK_BLUE, spaceBefore=6, spaceAfter=18,
)


# ─── Cover Page Flowable ───
class CoverPage(Flowable):
    def __init__(self, width=PAGE_W, height=PAGE_H):
        Flowable.__init__(self)
        self.width = width
        self.height = height

    def draw(self):
        c = self.canv
        # Full background
        c.setFillColor(DARK_BLUE)
        c.rect(0, 0, self.width, self.height, fill=1, stroke=0)

        # Accent stripe
        c.setFillColor(ACCENT_BLUE)
        c.rect(0, self.height * 0.38, self.width, 4, fill=1, stroke=0)

        # Title
        c.setFillColor(white)
        c.setFont("TimesNewRoman", 30)
        c.drawCentredString(self.width / 2, self.height * 0.72, "NEXUS Platform")
        c.setFont("TimesNewRoman", 22)
        c.drawCentredString(self.width / 2, self.height * 0.65, "Claude Code Build Prompts")

        # Subtitle
        c.setFillColor(HexColor("#BDD7EE"))
        c.setFont("TimesNewRoman", 13)
        c.drawCentredString(self.width / 2, self.height * 0.50,
                            "18 Sequential Prompts to Build a Post-Coding")
        c.drawCentredString(self.width / 2, self.height * 0.47,
                            "Distributed Intelligence Platform from a Blank Repository")

        # Bottom info
        c.setFillColor(HexColor("#D6E4F0"))
        c.setFont("TimesNewRoman", 11)
        c.drawCentredString(self.width / 2, self.height * 0.15, "Author: Z.ai")
        c.drawCentredString(self.width / 2, self.height * 0.12, "Claude Code Prompt Series v1.0")
        c.drawCentredString(self.width / 2, self.height * 0.08, "ESP32-S3 + Jetson Orin Nano")

        # Decorative lines
        c.setStrokeColor(HexColor("#2E75B6"))
        c.setLineWidth(1)
        c.line(self.width * 0.2, self.height * 0.55, self.width * 0.8, self.height * 0.55)
        c.line(self.width * 0.2, self.height * 0.20, self.width * 0.8, self.height * 0.20)


# ─── TocDocTemplate ───
class TocDocTemplate(BaseDocTemplate):
    def __init__(self, filename, **kwargs):
        super().__init__(filename, **kwargs)
        self.page_count = 0
        self.toc_entries = []

        cover_frame = Frame(0, 0, PAGE_W, PAGE_H, id="cover",
                            leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)
        toc_frame = Frame(MARGIN_L, MARGIN_B, CONTENT_W, PAGE_H - MARGIN_T - MARGIN_B, id="toc")
        content_frame = Frame(MARGIN_L, MARGIN_B, CONTENT_W, PAGE_H - MARGIN_T - MARGIN_B, id="content")

        self.addPageTemplates([
            PageTemplate(id="Cover", frames=[cover_frame], onPage=self._cover_page),
            PageTemplate(id="TOC", frames=[toc_frame], onPage=self._toc_page),
            PageTemplate(id="Content", frames=[content_frame], onPage=self._content_page),
        ])

    def _cover_page(self, canvas_obj, doc):
        pass

    def _toc_page(self, canvas_obj, doc):
        canvas_obj.saveState()
        canvas_obj.setFillColor(DARK_BLUE)
        canvas_obj.rect(0, PAGE_H - 18, PAGE_W, 18, fill=1, stroke=0)
        canvas_obj.rect(0, 0, PAGE_W, 18, fill=1, stroke=0)
        canvas_obj.setFillColor(white)
        canvas_obj.setFont("TimesNewRoman", 8)
        canvas_obj.drawCentredString(PAGE_W / 2, 5, "NEXUS Platform - Claude Code Build Prompts")
        canvas_obj.drawCentredString(PAGE_W / 2, PAGE_H - 13, "NEXUS Platform - Claude Code Build Prompts")
        canvas_obj.restoreState()

    def _content_page(self, canvas_obj, doc):
        canvas_obj.saveState()
        canvas_obj.setStrokeColor(DARK_BLUE)
        canvas_obj.setLineWidth(0.5)
        canvas_obj.line(MARGIN_L, PAGE_H - MARGIN_T + 6, PAGE_W - MARGIN_R, PAGE_H - MARGIN_T + 6)
        canvas_obj.setFillColor(DARK_BLUE)
        canvas_obj.setFont("TimesNewRoman", 8)
        canvas_obj.drawString(MARGIN_L, PAGE_H - MARGIN_T + 10, "NEXUS Platform - Claude Code Prompt Series")
        canvas_obj.drawRightString(PAGE_W - MARGIN_R, PAGE_H - MARGIN_T + 10, "Z.ai")
        canvas_obj.line(MARGIN_L, MARGIN_B - 6, PAGE_W - MARGIN_R, MARGIN_B - 6)
        canvas_obj.setFont("TimesNewRoman", 8)
        canvas_obj.drawCentredString(PAGE_W / 2, MARGIN_B - 18, f"Page {doc.page}")
        canvas_obj.restoreState()

    def afterFlowable(self, flowable):
        if hasattr(flowable, "_bookmark_name") and flowable._bookmark_name:
            key = flowable._bookmark_name
            text = flowable._bookmark_text
            level = flowable._bookmark_level
            self.canv.bookmarkPage(key)
            if level <= 2:
                self.canv.addOutlineEntry(text, key, level, 0)
            self.toc_entries.append((level, text, self.page, key))


# ─── Heading Flowables ───
class Heading1(Paragraph):
    def __init__(self, text, bookmark_name, bookmark_text=None):
        self._bookmark_name = bookmark_name
        self._bookmark_level = 0
        self._bookmark_text = bookmark_text or text
        super().__init__(text, sH1)

class Heading2(Paragraph):
    def __init__(self, text, bookmark_name, bookmark_text=None):
        self._bookmark_name = bookmark_name
        self._bookmark_level = 1
        self._bookmark_text = bookmark_text or text
        super().__init__(text, sH2)

class Heading3(Paragraph):
    def __init__(self, text, bookmark_name=None, bookmark_text=None):
        if bookmark_name:
            self._bookmark_name = bookmark_name
        else:
            self._bookmark_name = None
        self._bookmark_level = 2
        self._bookmark_text = bookmark_text or text
        super().__init__(text, sH3)


# ─── Markdown Parser ───
def escape_xml(text):
    """Escape text for XML/Paragraph."""
    text = text.replace("&", "&amp;")
    text = text.replace("<", "&lt;")
    text = text.replace(">", "&gt;")
    return text

def inline_format(text):
    """Apply inline formatting: bold, italic, code."""
    # Inline code
    text = re.sub(r'`([^`]+)`', r'<font name="DejaVuSans" size="8.5">\1</font>', text)
    # Bold
    text = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', text)
    # Italic
    text = re.sub(r'\*(.+?)\*', r'<i>\1</i>', text)
    return text

def make_code_block(text, style=sCodeBlock):
    """Create a code block with background using a table wrapper."""
    safe = escape_xml(text)
    content = Paragraph(safe, style)
    code_width = CONTENT_W - 2 * cm
    t = Table([[content]], colWidths=[code_width])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), CODE_BG),
        ("BOX", (0, 0), (-1, -1), 0.5, CODE_BORDER),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ("RIGHTPADDING", (0, 0), (-1, -1), 8),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    return t

def make_table(headers, rows, col_widths=None):
    """Create a styled table."""
    header_cells = [Paragraph(escape_xml(h), sTableHeader) for h in headers]
    data = [header_cells]
    for row in rows:
        data.append([Paragraph(inline_format(escape_xml(c)), sTableCell) for c in row])

    if col_widths is None:
        col_widths = [CONTENT_W / len(headers)] * len(headers)

    t = Table(data, colWidths=col_widths, repeatRows=1)
    style_cmds = [
        ("BACKGROUND", (0, 0), (-1, 0), DARK_BLUE),
        ("TEXTCOLOR", (0, 0), (-1, 0), white),
        ("FONTNAME", (0, 0), (-1, 0), "TimesNewRoman"),
        ("FONTSIZE", (0, 0), (-1, 0), 9),
        ("BOTTOMPADDING", (0, 0), (-1, 0), 6),
        ("TOPPADDING", (0, 0), (-1, 0), 6),
        ("ALIGN", (0, 0), (-1, 0), "CENTER"),
        ("FONTNAME", (0, 1), (-1, -1), "TimesNewRoman"),
        ("FONTSIZE", (0, 1), (-1, -1), 9),
        ("TOPPADDING", (0, 1), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 1), (-1, -1), 4),
        ("LEFTPADDING", (0, 0), (-1, -1), 5),
        ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("GRID", (0, 0), (-1, -1), 0.5, HexColor("#CCCCCC")),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [white, LIGHT_GRAY]),
    ]
    t.setStyle(TableStyle(style_cmds))
    return t

def parse_markdown(md_text):
    """Parse markdown and return a list of (type, content) tuples."""
    elements = []
    lines = md_text.split('\n')
    i = 0
    n = len(lines)

    while i < n:
        line = lines[i]

        # Skip empty lines at top
        if line.strip() == '' and not elements:
            i += 1
            continue

        # H1 heading
        if line.startswith('# ') and not line.startswith('## '):
            text = line[2:].strip()
            elements.append(('h1', text))
            i += 1
            continue

        # H2 heading
        if line.startswith('## ') and not line.startswith('### '):
            text = line[3:].strip()
            elements.append(('h2', text))
            i += 1
            continue

        # H3 heading
        if line.startswith('### '):
            text = line[4:].strip()
            elements.append(('h3', text))
            i += 1
            continue

        # Horizontal rule
        if line.strip() == '---':
            elements.append(('hr', ''))
            i += 1
            continue

        # Fenced code block (```)
        if line.strip().startswith('```'):
            # Collect all lines until closing ```
            code_lines = []
            i += 1
            while i < n and not lines[i].strip() == '```':
                code_lines.append(lines[i])
                i += 1
            code_text = '\n'.join(code_lines)
            elements.append(('code', code_text))
            i += 1  # skip closing ```
            continue

        # Table (detect by | characters)
        if '|' in line and line.strip().startswith('|'):
            table_lines = []
            while i < n and '|' in lines[i] and lines[i].strip():
                table_lines.append(lines[i])
                i += 1
            elements.append(('table', table_lines))
            continue

        # Bullet list
        if re.match(r'^(\s*)-\s', line):
            bullet_lines = []
            while i < n and re.match(r'^(\s*)-\s', lines[i]):
                bullet_lines.append(lines[i])
                i += 1
            elements.append(('bullets', bullet_lines))
            continue

        # Numbered list
        if re.match(r'^\d+\.\s', line):
            num_lines = []
            while i < n and re.match(r'^\d+\.\s', lines[i]):
                num_lines.append(lines[i])
                i += 1
            elements.append(('numbered', num_lines))
            continue

        # Regular paragraph - collect consecutive non-empty/non-special lines
        if line.strip():
            para_lines = [line]
            i += 1
            while i < n and lines[i].strip() and not lines[i].startswith('#') and not lines[i].strip().startswith('```') and not lines[i].strip() == '---' and not (re.match(r'^(\s*)-\s', lines[i]) or re.match(r'^\d+\.\s', lines[i]) or (lines[i].strip().startswith('|') and '|' in lines[i])):
                para_lines.append(lines[i])
                i += 1
            elements.append(('paragraph', ' '.join(para_lines)))
            continue

        # Empty line
        i += 1

    return elements


def process_elements(elements, story, prompt_count=[0]):
    """Convert parsed markdown elements to reportlab flowables."""
    h1_counter = [0]
    h2_counter = [0]
    in_prompt = False

    for etype, content in elements:
        if etype == 'h1':
            h1_counter[0] += 1
            text = inline_format(escape_xml(content))
            bm_name = f"h1_{h1_counter[0]}"
            story.append(Heading1(text, bm_name, content))

        elif etype == 'h2':
            h2_counter[0] += 1
            text = inline_format(escape_xml(content))
            bm_name = f"h2_{h2_counter[0]}"

            # Check if this is a prompt heading
            is_prompt = bool(re.match(r'^Prompt\s+\d+', content, re.IGNORECASE))
            is_appendix = bool(re.match(r'^Appendix\s+', content, re.IGNORECASE))
            is_how_to = 'How to Use' in content

            if is_prompt:
                prompt_count[0] += 1
                in_prompt = True
                # Page break before each prompt
                if prompt_count[0] > 1:
                    story.append(PageBreak())
            elif is_appendix:
                in_prompt = False
                # Page break before Appendix A
                if 'Appendix A' in content:
                    story.append(PageBreak())

            story.append(Heading2(text, bm_name, content))

        elif etype == 'h3':
            text = inline_format(escape_xml(content))
            bm_name = f"h3_{h2_counter[0]}_{content[:20].replace(' ', '_')}"
            story.append(Heading3(text, bm_name, content))

        elif etype == 'hr':
            story.append(HRFlowable(width="100%", thickness=0.5, color=DARK_BLUE,
                                     spaceBefore=6, spaceAfter=6))

        elif etype == 'code':
            # Large code block - use table wrapper with background
            story.append(make_code_block(content))

        elif etype == 'table':
            rows_data = []
            headers = []
            for j, tl in enumerate(content):
                cells = [c.strip() for c in tl.strip().strip('|').split('|')]
                if j == 0:
                    headers = cells
                elif j == 1 and all(set(c.strip()) <= set('-:| ') for c in cells):
                    continue  # Skip separator row
                else:
                    rows_data.append(cells)
            if headers and rows_data:
                num_cols = len(headers)
                cw = [CONTENT_W / num_cols] * num_cols
                # Make first column slightly narrower if many columns
                if num_cols >= 3:
                    cw = [CONTENT_W * 0.22] + [CONTENT_W * 0.78 / (num_cols - 1)] * (num_cols - 1)
                story.append(make_table(headers, rows_data, col_widths=cw))
                story.append(Spacer(1, 6))

        elif etype == 'bullets':
            for bl in content:
                # Remove leading "- " and strip
                text = re.sub(r'^(\s*)-\s+', '', bl).strip()
                text = inline_format(escape_xml(text))
                story.append(Paragraph(text, sBullet, bulletText="\u2022"))

        elif etype == 'numbered':
            for idx, nl in enumerate(content):
                text = re.sub(r'^\d+\.\s+', '', nl).strip()
                text = inline_format(escape_xml(text))
                story.append(Paragraph(text, sNumbered, bulletText=str(idx + 1) + "."))

        elif etype == 'paragraph':
            text = inline_format(escape_xml(content))
            story.append(Paragraph(text, sBody))

        else:
            pass


def build_pdf():
    # Read markdown
    with open(MD_PATH, 'r', encoding='utf-8') as f:
        md_text = f.read()

    doc = TocDocTemplate(
        OUTPUT_PATH,
        pagesize=letter,
        title="NEXUS_Claude_Code_Prompt_Series",
        author="Z.ai",
        creator="Z.ai",
        subject="Claude Code build prompts for NEXUS Post-Coding Platform",
        leftMargin=MARGIN_L, rightMargin=MARGIN_R,
        topMargin=MARGIN_T, bottomMargin=MARGIN_B,
    )

    story = []

    # ═══════════════ COVER PAGE ═══════════════
    story.append(CoverPage())
    story.append(NextPageTemplate("TOC"))
    story.append(PageBreak())

    # ═══════════════ TABLE OF CONTENTS ═══════════════
    toc = TableOfContents()
    toc.levelStyles = [
        ParagraphStyle("TOC0", fontName="TimesNewRoman", fontSize=11, leading=18,
                       leftIndent=0, spaceBefore=4, spaceAfter=2, textColor=DARK_BLUE),
        ParagraphStyle("TOC1", fontName="TimesNewRoman", fontSize=10, leading=16,
                       leftIndent=18, spaceBefore=2, spaceAfter=1, textColor=DARK_TEXT),
        ParagraphStyle("TOC2", fontName="TimesNewRoman", fontSize=9, leading=14,
                       leftIndent=36, spaceBefore=1, spaceAfter=1, textColor=DARK_TEXT),
    ]
    story.append(Paragraph("Table of Contents", sTOCTitle))
    story.append(toc)
    story.append(NextPageTemplate("Content"))
    story.append(PageBreak())

    # ═══════════════ PARSE AND BUILD CONTENT ═══════════════
    elements = parse_markdown(md_text)
    prompt_count = [0]
    process_elements(elements, story, prompt_count)

    # Build PDF (multi-pass for TOC)
    doc.multiBuild(story)
    return doc


if __name__ == "__main__":
    print("Generating NEXUS Claude Code Prompt Series PDF...")
    doc = build_pdf()
    print(f"PDF generated: {OUTPUT_PATH}")
    print(f"Total pages: {doc.page}")
