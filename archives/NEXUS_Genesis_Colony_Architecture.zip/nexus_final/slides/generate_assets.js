const sharp = require('sharp');
const path = require('path');

// Colors
const BG_DARK = '#162235';
const BG_CARD = '#1E2D42';
const ACCENT = '#37DCF2';
const ACCENT_DIM = '#1A6E7F';
const WHITE = '#FFFFFF';
const GRAY = '#8899AA';
const RED = '#FF4D6A';
const GREEN = '#2EE89E';
const YELLOW = '#FFD93D';
const ORANGE = '#FF8C42';

const DIR = __dirname;

async function createGradient(filename, w, h, c1, c2, angle = '0%', angle2 = '100%') {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}">
    <defs>
      <linearGradient id="g" x1="0%" y1="0%" x2="${angle}" y2="${angle2}">
        <stop offset="0%" style="stop-color:${c1}"/>
        <stop offset="100%" style="stop-color:${c2}"/>
      </linearGradient>
    </defs>
    <rect width="100%" height="100%" fill="url(#g)"/>
  </svg>`;
  await sharp(Buffer.from(svg)).png().toFile(path.join(DIR, filename));
}

async function createCircleIcon(filename, color, size = 128) {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}">
    <circle cx="${size/2}" cy="${size/2}" r="${size*0.42}" fill="none" stroke="${color}" stroke-width="3"/>
  </svg>`;
  await sharp(Buffer.from(svg)).png().toFile(path.join(DIR, filename));
}

async function createCheckIcon(filename, color, size = 64) {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 24 24">
    <circle cx="12" cy="12" r="11" fill="${color}" opacity="0.2"/>
    <circle cx="12" cy="12" r="11" fill="none" stroke="${color}" stroke-width="1.5"/>
    <path d="M7 12.5l3 3 7-7" fill="none" stroke="${color}" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>`;
  await sharp(Buffer.from(svg)).png().toFile(path.join(DIR, filename));
}

async function createXIcon(filename, color, size = 64) {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 24 24">
    <circle cx="12" cy="12" r="11" fill="${color}" opacity="0.2"/>
    <circle cx="12" cy="12" r="11" fill="none" stroke="${color}" stroke-width="1.5"/>
    <path d="M8 8l8 8M16 8l-8 8" fill="none" stroke="${color}" stroke-width="2.5" stroke-linecap="round"/>
  </svg>`;
  await sharp(Buffer.from(svg)).png().toFile(path.join(DIR, filename));
}

async function createArrowDown(filename, color, size = 48) {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 24 24">
    <path d="M12 4v16M5 13l7 7 7-7" fill="none" stroke="${color}" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>`;
  await sharp(Buffer.from(svg)).png().toFile(path.join(DIR, filename));
}

async function createArrowRight(filename, color, size = 48) {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 24 24">
    <path d="M4 12h16M13 5l7 7-7 7" fill="none" stroke="${color}" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>`;
  await sharp(Buffer.from(svg)).png().toFile(path.join(DIR, filename));
}

async function createChipIcon(filename, color, size = 96) {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 48 48">
    <rect x="12" y="12" width="24" height="24" rx="3" fill="${color}" opacity="0.15" stroke="${color}" stroke-width="2"/>
    <rect x="16" y="16" width="16" height="16" rx="1" fill="${color}" opacity="0.3"/>
    <line x1="18" y1="8" x2="18" y2="12" stroke="${color}" stroke-width="2"/>
    <line x1="24" y1="8" x2="24" y2="12" stroke="${color}" stroke-width="2"/>
    <line x1="30" y1="8" x2="30" y2="12" stroke="${color}" stroke-width="2"/>
    <line x1="18" y1="36" x2="18" y2="40" stroke="${color}" stroke-width="2"/>
    <line x1="24" y1="36" x2="24" y2="40" stroke="${color}" stroke-width="2"/>
    <line x1="30" y1="36" x2="30" y2="40" stroke="${color}" stroke-width="2"/>
    <line x1="8" y1="18" x2="12" y2="18" stroke="${color}" stroke-width="2"/>
    <line x1="8" y1="24" x2="12" y2="24" stroke="${color}" stroke-width="2"/>
    <line x1="8" y1="30" x2="12" y2="30" stroke="${color}" stroke-width="2"/>
    <line x1="36" y1="18" x2="40" y2="18" stroke="${color}" stroke-width="2"/>
    <line x1="36" y1="24" x2="40" y2="24" stroke="${color}" stroke-width="2"/>
    <line x1="36" y1="30" x2="40" y2="30" stroke="${color}" stroke-width="2"/>
  </svg>`;
  await sharp(Buffer.from(svg)).png().toFile(path.join(DIR, filename));
}

async function createBrainIcon(filename, color, size = 96) {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 48 48">
    <circle cx="16" cy="18" r="8" fill="none" stroke="${color}" stroke-width="2" opacity="0.8"/>
    <circle cx="32" cy="18" r="8" fill="none" stroke="${color}" stroke-width="2" opacity="0.8"/>
    <circle cx="16" cy="32" r="8" fill="none" stroke="${color}" stroke-width="2" opacity="0.8"/>
    <circle cx="32" cy="32" r="8" fill="none" stroke="${color}" stroke-width="2" opacity="0.8"/>
    <circle cx="24" cy="24" r="6" fill="${color}" opacity="0.3"/>
    <line x1="16" y1="18" x2="24" y2="24" stroke="${color}" stroke-width="1.5" opacity="0.5"/>
    <line x1="32" y1="18" x2="24" y2="24" stroke="${color}" stroke-width="1.5" opacity="0.5"/>
    <line x1="16" y1="32" x2="24" y2="24" stroke="${color}" stroke-width="1.5" opacity="0.5"/>
    <line x1="32" y1="32" x2="24" y2="24" stroke="${color}" stroke-width="1.5" opacity="0.5"/>
  </svg>`;
  await sharp(Buffer.from(svg)).png().toFile(path.join(DIR, filename));
}

async function createCloudIcon(filename, color, size = 96) {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 48 48">
    <path d="M14 36c-4.4 0-8-3.6-8-8 0-3.7 2.5-6.8 6-7.7C12.6 16.5 16.2 14 20.4 14c3.4 0 6.4 1.9 7.9 4.7.8-.3 1.6-.4 2.5-.4 4.1 0 7.5 3.4 7.5 7.5 0 .4 0 .8-.1 1.2C39.8 27.8 41 29.7 41 32c0 2.8-2.2 5-5 5H14z" fill="none" stroke="${color}" stroke-width="2"/>
  </svg>`;
  await sharp(Buffer.from(svg)).png().toFile(path.join(DIR, filename));
}

async function createShieldIcon(filename, color, size = 96) {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 48 48">
    <path d="M24 4L8 12v12c0 11.1 6.8 21.5 16 24 9.2-2.5 16-12.9 16-24V12L24 4z" fill="${color}" opacity="0.15" stroke="${color}" stroke-width="2"/>
    <path d="M17 24l5 5 9-9" fill="none" stroke="${color}" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>`;
  await sharp(Buffer.from(svg)).png().toFile(path.join(DIR, filename));
}

async function createEyeIcon(filename, color, size = 96) {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 48 48">
    <path d="M24 12C14 12 6 24 6 24s8 12 18 12 18-12 18-12-8-12-18-12z" fill="none" stroke="${color}" stroke-width="2"/>
    <circle cx="24" cy="24" r="6" fill="none" stroke="${color}" stroke-width="2"/>
    <circle cx="24" cy="24" r="2" fill="${color}"/>
  </svg>`;
  await sharp(Buffer.from(svg)).png().toFile(path.join(DIR, filename));
}

async function createLockIcon(filename, color, size = 96) {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 48 48">
    <rect x="10" y="22" width="28" height="20" rx="3" fill="${color}" opacity="0.15" stroke="${color}" stroke-width="2"/>
    <path d="M16 22V16a8 8 0 1 1 16 0v6" fill="none" stroke="${color}" stroke-width="2"/>
    <circle cx="24" cy="32" r="3" fill="${color}"/>
  </svg>`;
  await sharp(Buffer.from(svg)).png().toFile(path.join(DIR, filename));
}

async function createStairsIcon(filename, color, size = 96) {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 48 48">
    <path d="M6 42V34h10v-8h10v-8h10v-8h10v-8" fill="none" stroke="${color}" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
    <circle cx="6" cy="34" r="2.5" fill="${color}"/>
    <circle cx="16" cy="26" r="2.5" fill="${color}"/>
    <circle cx="26" cy="18" r="2.5" fill="${color}"/>
    <circle cx="36" cy="10" r="2.5" fill="${color}"/>
  </svg>`;
  await sharp(Buffer.from(svg)).png().toFile(path.join(DIR, filename));
}

async function createWarningIcon(filename, color, size = 64) {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 24 24">
    <path d="M12 2L2 20h20L12 2z" fill="${color}" opacity="0.15" stroke="${color}" stroke-width="1.5"/>
    <line x1="12" y1="9" x2="12" y2="14" stroke="${color}" stroke-width="2" stroke-linecap="round"/>
    <circle cx="12" cy="17" r="1" fill="${color}"/>
  </svg>`;
  await sharp(Buffer.from(svg)).png().toFile(path.join(DIR, filename));
}

async function createTargetIcon(filename, color, size = 64) {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 24 24">
    <circle cx="12" cy="12" r="10" fill="none" stroke="${color}" stroke-width="1.5"/>
    <circle cx="12" cy="12" r="6" fill="none" stroke="${color}" stroke-width="1.5"/>
    <circle cx="12" cy="12" r="2" fill="${color}"/>
  </svg>`;
  await sharp(Buffer.from(svg)).png().toFile(path.join(DIR, filename));
}

async function main() {
  console.log('Generating assets...');
  
  // Main slide backgrounds
  await createGradient('bg_main.png', 1440, 810, '#0F1A2E', '#162235', '100%', '100%');
  await createGradient('bg_cover.png', 1440, 810, '#0D1526', '#1A2D4A', '80%', '100%');
  await createGradient('bg_accent_bar.png', 1440, 8, ACCENT, '#1A6E7F', '100%', '0%');
  await createGradient('bg_card.png', 600, 400, BG_CARD, '#1A2940', '0%', '100%');
  
  // Small decorative elements
  await createGradient('accent_line.png', 80, 4, ACCENT, '#1A6E7F', '100%', '0%');
  await createGradient('accent_line_h.png', 4, 40, ACCENT, '#1A6E7F', '0%', '100%');
  
  // Icons
  await createChipIcon('icon_chip.png', ACCENT);
  await createBrainIcon('icon_brain.png', ACCENT);
  await createCloudIcon('icon_cloud.png', ACCENT);
  await createShieldIcon('icon_shield.png', ACCENT);
  await createEyeIcon('icon_eye.png', ACCENT);
  await createLockIcon('icon_lock.png', ACCENT);
  await createCheckIcon('icon_check.png', GREEN);
  await createXIcon('icon_x.png', RED);
  await createArrowDown('icon_arrow_down.png', ACCENT);
  await createArrowRight('icon_arrow_right.png', ACCENT);
  await createStairsIcon('icon_stairs.png', ACCENT);
  await createWarningIcon('icon_warning.png', YELLOW);
  await createTargetIcon('icon_target.png', ACCENT);
  
  // Confidence level badges
  for (const [name, color] of [['veryhigh', GREEN], ['high', ACCENT], ['medium', YELLOW], ['low', ORANGE]]) {
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24">
      <circle cx="12" cy="12" r="10" fill="${color}" opacity="0.2"/>
      <circle cx="12" cy="12" r="10" fill="none" stroke="${color}" stroke-width="1.5"/>
      <circle cx="12" cy="12" r="4" fill="${color}"/>
    </svg>`;
    await sharp(Buffer.from(svg)).png().toFile(path.join(DIR, `badge_${name}.png`));
  }
  
  console.log('Assets generated successfully.');
}

main().catch(console.error);
