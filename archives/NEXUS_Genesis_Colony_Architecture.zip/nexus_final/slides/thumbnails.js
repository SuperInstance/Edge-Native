const { chromium } = require('playwright');
const path = require('path');

const DIR = __dirname;

async function generateThumbnails() {
  const browser = await chromium.launch();
  const page = await browser.newPage();
  await page.setViewportSize({ width: 1440, height: 810 });
  
  for (let i = 1; i <= 20; i++) {
    const fname = `slide${String(i).padStart(2, '0')}.html`;
    const filePath = path.join(DIR, fname);
    
    try {
      await page.goto(`file://${filePath}`, { waitUntil: 'networkidle' });
      await page.screenshot({
        path: path.join(DIR, `thumb${String(i).padStart(2, '0')}.png`),
        clip: { x: 0, y: 0, width: 1440, height: 810 }
      });
      console.log(`  Thumbnail: ${fname} -> thumb${String(i).padStart(2, '0')}.png`);
    } catch (err) {
      console.error(`  Error on ${fname}: ${err.message}`);
    }
  }
  
  await browser.close();
  console.log('Thumbnails generated.');
}

generateThumbnails().catch(console.error);
