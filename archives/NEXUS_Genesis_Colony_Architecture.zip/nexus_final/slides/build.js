const pptxgen = require('pptxgenjs');
const html2pptx = require('/home/z/my-project/skills/pptx/scripts/html2pptx');
const fs = require('fs');
const path = require('path');

const DIR = __dirname;
const SLIDE_W = 720; // pt
const SLIDE_H = 405; // pt

// Theme colors
const C = {
  bg: '#162235',
  bgCard: '#1E2D42',
  bgCardLight: '#243A54',
  accent: '#37DCF2',
  accentDim: '#1A6E7F',
  white: '#FFFFFF',
  gray: '#8899AA',
  grayDark: '#556677',
  red: '#FF4D6A',
  green: '#2EE89E',
  yellow: '#FFD93D',
  orange: '#FF8C42',
};

function baseCSS(extra = '') {
  return `
html { background: ${C.bg}; }
body {
  width: ${SLIDE_W}pt; height: ${SLIDE_H}pt; margin: 0; padding: 0;
  font-family: Helvetica, Arial, sans-serif;
  display: flex; flex-direction: column;
  background-image: url('bg_main.png');
  background-size: cover;
  color: ${C.white};
  overflow: hidden;
}
${extra}`;
}

function writeSlide(num, html) {
  const fname = `slide${String(num).padStart(2,'0')}.html`;
  fs.writeFileSync(path.join(DIR, fname), html);
  return fname;
}

// ==================== SLIDE GENERATORS ====================

function slide01_cover() {
  return writeSlide(1, `<!DOCTYPE html><html><head><style>
${baseCSS(`
.wrap { display: flex; flex-direction: column; align-items: center; justify-content: center; flex: 1; margin: 0 40pt; }
.stat-bar { display: flex; gap: 24pt; margin-top: 18pt; }
.stat-item { background: ${C.bgCard}; border: 1px solid ${C.accentDim}; border-radius: 6pt; padding: 8pt 16pt; text-align: center; }
`)}
</style></head><body>
<div class="wrap">
  <div style="margin-bottom: 8pt;"><img src="accent_line.png" style="width: 60pt; height: 3pt;"></div>
  <h1 style="font-size: 52pt; letter-spacing: 12pt; color: ${C.accent}; margin: 0 0 6pt 0;">NEXUS</h1>
  <p style="font-size: 16pt; color: ${C.gray}; margin: 0 0 24pt 0; letter-spacing: 3pt;">THE POST-CODING INTELLIGENCE PLATFORM</p>
  <div class="stat-bar">
    <div class="stat-item"><p style="font-size: 20pt; color: ${C.accent}; margin: 0; font-weight: bold;">21</p><p style="font-size: 9pt; color: ${C.gray}; margin: 2pt 0 0 0;">spec files</p></div>
    <div class="stat-item"><p style="font-size: 20pt; color: ${C.accent}; margin: 0; font-weight: bold;">19,200</p><p style="font-size: 9pt; color: ${C.gray}; margin: 2pt 0 0 0;">lines</p></div>
    <div class="stat-item"><p style="font-size: 20pt; color: ${C.accent}; margin: 0; font-weight: bold;">28</p><p style="font-size: 9pt; color: ${C.gray}; margin: 2pt 0 0 0;">arch decisions</p></div>
  </div>
  <p style="font-size: 9pt; color: ${C.grayDark}; margin-top: 24pt;">Production-Ready Specification  |  2026</p>
</div>
</body></html>`);
}

function slide02_problem() {
  return writeSlide(2, `<!DOCTYPE html><html><head><style>
${baseCSS(`
.header { margin: 24pt 36pt 0; display: flex; align-items: center; gap: 10pt; }
.content { display: flex; flex: 1; margin: 12pt 36pt 24pt; gap: 24pt; }
.left { flex: 1; display: flex; flex-direction: column; justify-content: center; }
.right { flex: 1; display: flex; flex-direction: column; justify-content: center; gap: 10pt; }
.pain { background: ${C.bgCard}; border-left: 3px solid ${C.red}; border-radius: 4pt; padding: 10pt 14pt; }
`)}
</style></head><body>
<div class="header">
  <img src="accent_line.png" style="width: 30pt; height: 3pt;">
  <h2 style="font-size: 22pt; margin: 0; color: ${C.white};">THE PROBLEM</h2>
</div>
<div class="content">
  <div class="left">
    <p style="font-size: 26pt; color: ${C.white}; margin: 0 0 10pt 0; font-weight: bold;">Today's industrial robots require armies of programmers.</p>
    <p style="font-size: 12pt; color: ${C.gray}; margin: 0;">And when hardware changes, the code breaks. Again.</p>
  </div>
  <div class="right">
    <div class="pain">
      <p style="font-size: 28pt; color: ${C.red}; margin: 0; font-weight: bold;">6-18</p>
      <p style="font-size: 10pt; color: ${C.gray}; margin: 2pt 0 0 0;">months to program a single robot</p>
    </div>
    <div class="pain">
      <p style="font-size: 28pt; color: ${C.red}; margin: 0; font-weight: bold;">3-5</p>
      <p style="font-size: 10pt; color: ${C.gray}; margin: 2pt 0 0 0;">specialized engineers required</p>
    </div>
    <div class="pain">
      <p style="font-size: 14pt; color: ${C.red}; margin: 0; font-weight: bold;">Code breaks when hardware changes</p>
      <p style="font-size: 10pt; color: ${C.gray}; margin: 2pt 0 0 0;">Every sensor swap = weeks of rework</p>
    </div>
  </div>
</div>
</body></html>`);
}

function slide03_vision() {
  return writeSlide(3, `<!DOCTYPE html><html><head><style>
${baseCSS(`
.header { margin: 24pt 36pt 0; display: flex; align-items: center; gap: 10pt; }
.content { display: flex; flex-direction: column; flex: 1; margin: 16pt 36pt 24pt; align-items: center; justify-content: center; }
.question { margin-bottom: 20pt; text-align: center; }
.icons { display: flex; gap: 30pt; margin-bottom: 20pt; }
.icon-card { background: ${C.bgCard}; border: 1px solid ${C.accentDim}; border-radius: 8pt; padding: 16pt 20pt; text-align: center; width: 120pt; }
.tagline { background: ${C.bgCard}; border: 1px solid ${C.accentDim}; border-radius: 6pt; padding: 10pt 24pt; text-align: center; }
`)}
</style></head><body>
<div class="header">
  <img src="accent_line.png" style="width: 30pt; height: 3pt;">
  <h2 style="font-size: 22pt; margin: 0;">OUR VISION</h2>
</div>
<div class="content">
  <div class="question">
    <p style="font-size: 22pt; color: ${C.white}; margin: 0; font-weight: bold;">What if robots learned the way humans do?</p>
  </div>
  <div class="icons">
    <div class="icon-card">
      <p style="font-size: 28pt; margin: 0 0 6pt 0; color: ${C.accent};">&#9678;</p>
      <p style="font-size: 16pt; margin: 0; font-weight: bold; color: ${C.accent};">WATCH</p>
      <p style="font-size: 9pt; color: ${C.gray}; margin: 4pt 0 0 0;">Observe human actions</p>
    </div>
    <div class="icon-card">
      <p style="font-size: 28pt; margin: 0 0 6pt 0; color: ${C.accent};">&#9672;</p>
      <p style="font-size: 16pt; margin: 0; font-weight: bold; color: ${C.accent};">LEARN</p>
      <p style="font-size: 9pt; color: ${C.gray}; margin: 4pt 0 0 0;">Discover patterns</p>
    </div>
    <div class="icon-card">
      <p style="font-size: 28pt; margin: 0 0 6pt 0; color: ${C.accent};">&#9654;</p>
      <p style="font-size: 16pt; margin: 0; font-weight: bold; color: ${C.accent};">ACT</p>
      <p style="font-size: 9pt; color: ${C.gray}; margin: 4pt 0 0 0;">Execute autonomously</p>
    </div>
  </div>
  <div class="tagline">
    <p style="font-size: 14pt; color: ${C.white}; margin: 0; font-weight: bold;">No code. No keyboards. Just intent and demonstration.</p>
  </div>
</div>
</body></html>`);
}

function slide04_howitworks() {
  return writeSlide(4, `<!DOCTYPE html><html><head><style>
${baseCSS(`
.header { margin: 24pt 36pt 0; display: flex; align-items: center; gap: 10pt; }
.flow { display: flex; flex-direction: column; flex: 1; margin: 6pt 28pt 10pt; align-items: center; justify-content: center; gap: 2pt; }
.step { background: ${C.bgCard}; border: 1px solid ${C.accentDim}; border-radius: 4pt; padding: 5pt 16pt; text-align: center; width: 480pt; }
.arrow-down { width: 0; height: 0; border-left: 6pt solid transparent; border-right: 6pt solid transparent; border-top: 6pt solid ${C.accentDim}; }
`)}
</style></head><body>
<div class="header">
  <img src="accent_line.png" style="width: 30pt; height: 3pt;">
  <h2 style="font-size: 22pt; margin: 0;">HOW IT WORKS</h2>
</div>
<div class="flow">
  <div class="step"><p style="margin:0; font-size: 10pt; color: ${C.accent}; font-weight: bold;">1. Human Demonstrates</p><p style="margin:1pt 0 0; font-size: 8pt; color: ${C.gray};">Operator performs the behavior while narrating intent</p></div>
  <div class="arrow-down"></div>
  <div class="step"><p style="margin:0; font-size: 10pt; color: ${C.accent}; font-weight: bold;">2. System Records</p><p style="margin:1pt 0 0; font-size: 8pt; color: ${C.gray};">Sensors capture 100Hz data + voice narration</p></div>
  <div class="arrow-down"></div>
  <div class="step"><p style="margin:0; font-size: 10pt; color: ${C.accent}; font-weight: bold;">3. AI Discovers Patterns</p><p style="margin:1pt 0 0; font-size: 8pt; color: ${C.gray};">5 algorithms find correlations, rules, and behaviors</p></div>
  <div class="arrow-down"></div>
  <div class="step"><p style="margin:0; font-size: 10pt; color: ${C.accent}; font-weight: bold;">4. Generates Proposal</p><p style="margin:1pt 0 0; font-size: 8pt; color: ${C.gray};">AI writes reflex code, separate AI validates safety</p></div>
  <div class="arrow-down"></div>
  <div class="step"><p style="margin:0; font-size: 10pt; color: ${C.accent}; font-weight: bold;">5. A/B Tests</p><p style="margin:1pt 0 0; font-size: 8pt; color: ${C.gray};">Proposed reflex vs. human baseline, statistical validation</p></div>
  <div class="arrow-down"></div>
  <div class="step"><p style="margin:0; font-size: 10pt; color: ${C.accent}; font-weight: bold;">6. Human Approves</p><p style="margin:1pt 0 0; font-size: 8pt; color: ${C.gray};">Natural-language explanation, not code. Approve or reject.</p></div>
  <div class="arrow-down"></div>
  <div class="step" style="border-color: ${C.green};"><p style="margin:0; font-size: 10pt; color: ${C.green}; font-weight: bold;">7. Deploys to Hardware</p><p style="margin:1pt 0 0; font-size: 8pt; color: ${C.gray};">Trust score incremented. Autonomy level may increase.</p></div>
</div>
</body></html>`);
}

function slide05_architecture() {
  return writeSlide(5, `<!DOCTYPE html><html><head><style>
${baseCSS(`
.header { margin: 24pt 36pt 0; display: flex; align-items: center; gap: 10pt; }
.content { display: flex; flex-direction: column; flex: 1; margin: 12pt 36pt 20pt; gap: 0; align-items: center; justify-content: center; }
.tier { border-radius: 6pt; padding: 12pt 20pt; text-align: center; width: 540pt; }
.t1 { background: ${C.bgCard}; border: 1px solid ${C.green}; }
.t2 { background: ${C.bgCard}; border: 1px solid ${C.accent}; }
.t3 { background: ${C.bgCard}; border: 1px solid ${C.accentDim}; }
.connector { display: flex; flex-direction: column; align-items: center; }
.conn-line { background: ${C.accentDim}; width: 2pt; height: 10pt; }
.conn-text { padding: 0 8pt; }
`)}
</style></head><body>
<div class="header">
  <img src="accent_line.png" style="width: 30pt; height: 3pt;">
  <h2 style="font-size: 22pt; margin: 0;">THREE-TIER ARCHITECTURE</h2>
</div>
<div class="content">
  <div class="tier t3">
    <p style="margin: 0; font-size: 14pt; font-weight: bold; color: ${C.accentDim};">TIER 3: CLOUD</p>
    <p style="margin: 4pt 0 0; font-size: 10pt; color: ${C.gray};">Heavy training, simulation, fleet management  |  Starlink/5G</p>
    <p style="margin: 2pt 0 0; font-size: 9pt; color: ${C.grayDark};">Can suggest but cannot command actuators directly</p>
  </div>
  <div class="connector">
    <div class="conn-line"></div>
    <p style="margin: 0; font-size: 8pt; color: ${C.accentDim};">queue-and-forward</p>
    <div class="conn-line"></div>
  </div>
  <div class="tier t2">
    <p style="margin: 0; font-size: 14pt; font-weight: bold; color: ${C.accent};">TIER 2: JETSON BRAIN</p>
    <p style="margin: 4pt 0 0; font-size: 10pt; color: ${C.gray};">AI inference, pattern discovery, chat interface  |  10-500ms</p>
    <p style="margin: 2pt 0 0; font-size: 9pt; color: ${C.grayDark};">3+ NVIDIA Jetson Orin Nano cluster, 40 TOPS</p>
  </div>
  <div class="connector">
    <div class="conn-line"></div>
    <p style="margin: 0; font-size: 8pt; color: ${C.accent};">RS-422  921,600 baud</p>
    <div class="conn-line"></div>
  </div>
  <div class="tier t1">
    <p style="margin: 0; font-size: 14pt; font-weight: bold; color: ${C.green};">TIER 1: MCU LIMBS</p>
    <p style="margin: 4pt 0 0; font-size: 10pt; color: ${C.gray};">Real-time control, sensor polling, safety  |  1kHz reflex loop</p>
    <p style="margin: 2pt 0 0; font-size: 9pt; color: ${C.grayDark};">ESP32-class, $6/unit, safety override is absolute</p>
  </div>
</div>
</body></html>`);
}

function slide06_limb() {
  return writeSlide(6, `<!DOCTYPE html><html><head><style>
${baseCSS(`
.header { margin: 24pt 36pt 0; display: flex; align-items: center; gap: 10pt; }
.content { display: flex; flex: 1; margin: 12pt 36pt 20pt; gap: 24pt; }
.left { flex: 1; display: flex; flex-direction: column; justify-content: center; }
.right { flex: 1; display: flex; flex-direction: column; justify-content: center; gap: 8pt; }
.role { background: ${C.bgCard}; border: 1px solid ${C.accentDim}; border-radius: 6pt; padding: 10pt 14pt; display: flex; align-items: center; gap: 10pt; }
.badge { background: ${C.accent}; color: ${C.bg}; border-radius: 4pt; padding: 2pt 8pt; font-weight: bold; font-size: 8pt; }
.highlight { background: ${C.bgCard}; border: 1px solid ${C.green}; border-radius: 6pt; padding: 10pt 14pt; margin-top: 8pt; }
`)}
</style></head><body>
<div class="header">
  <img src="accent_line.png" style="width: 30pt; height: 3pt;">
  <h2 style="font-size: 20pt; margin: 0;">THE LIMB: ONE FIRMWARE, INFINITE ROLES</h2>
</div>
<div class="content">
  <div class="left">
    <p style="font-size: 13pt; color: ${C.white}; margin: 0 0 8pt 0; font-weight: bold;">A single 320KB binary runs on every microcontroller.</p>
    <p style="font-size: 10pt; color: ${C.gray}; margin: 0 0 8pt 0;">Role is assigned at boot via JSON from the Jetson. No per-role firmware images needed.</p>
    <div class="highlight">
      <p style="font-size: 12pt; color: ${C.green}; margin: 0; font-weight: bold;">Hot-swap: Replace a failed unit in 2 minutes, no laptop needed.</p>
    </div>
    <p style="font-size: 9pt; color: ${C.grayDark}; margin: 8pt 0 0 0;">Boots to OPERATIONAL in 500ms. Auto-detects sensors and loads cached reflexes.</p>
  </div>
  <div class="right">
    <div class="role"><div class="badge"><p style="margin:0; font-size: 8pt; color: ${C.bg};">ROLE</p></div><p style="margin: 0; font-size: 11pt;">Autopilot Controller</p></div>
    <div class="role"><div class="badge"><p style="margin:0; font-size: 8pt; color: ${C.bg};">ROLE</p></div><p style="margin: 0; font-size: 11pt;">Engine Monitor</p></div>
    <div class="role"><div class="badge"><p style="margin:0; font-size: 8pt; color: ${C.bg};">ROLE</p></div><p style="margin: 0; font-size: 11pt;">Lighting Controller</p></div>
    <div class="role"><div class="badge"><p style="margin:0; font-size: 8pt; color: ${C.bg};">ROLE</p></div><p style="margin: 0; font-size: 11pt;">Bilge Pump Monitor</p></div>
    <div class="role"><div class="badge"><p style="margin:0; font-size: 8pt; color: ${C.bg};">ROLE</p></div><p style="margin: 0; font-size: 11pt;">Sensor Hub</p></div>
    <div class="role" style="border-style: dashed;"><div class="badge" style="background: ${C.gray};"><p style="margin:0; font-size: 8pt; color: ${C.bg};">ANY</p></div><p style="margin: 0; font-size: 11pt; color: ${C.gray};">Any future role via config</p></div>
  </div>
</div>
</body></html>`);
}

function slide07_bytecode() {
  return writeSlide(7, `<!DOCTYPE html><html><head><style>
${baseCSS(`
.header { margin: 24pt 36pt 0; display: flex; align-items: center; gap: 10pt; }
.content { display: flex; flex-direction: column; flex: 1; margin: 12pt 36pt 20pt; justify-content: center; gap: 14pt; }
.compare { display: flex; gap: 16pt; }
.col { flex: 1; background: ${C.bgCard}; border-radius: 6pt; padding: 14pt; }
.col-bad { border: 1px solid ${C.red}; }
.col-good { border: 1px solid ${C.green}; }
.metrics { display: flex; gap: 12pt; justify-content: center; }
.metric { background: ${C.bgCard}; border: 1px solid ${C.accentDim}; border-radius: 6pt; padding: 8pt 16pt; text-align: center; }
`)}
</style></head><body>
<div class="header">
  <img src="accent_line.png" style="width: 30pt; height: 3pt;">
  <h2 style="font-size: 20pt; margin: 0;">THE BRAIN: BYTECODE VM</h2>
</div>
<div class="content">
  <p style="font-size: 13pt; color: ${C.white}; margin: 0; text-align: center; font-weight: bold;">AI-generated code compiled to bytecode, not interpreted.</p>
  <div class="compare">
    <div class="col col-bad">
      <p style="font-size: 14pt; color: ${C.red}; margin: 0; font-weight: bold;">JSON Interpretation</p>
      <p style="font-size: 28pt; color: ${C.red}; margin: 8pt 0 2pt; font-weight: bold;">1000us</p>
      <p style="font-size: 10pt; color: ${C.gray}; margin: 0 0 6pt;">per cycle</p>
      <p style="font-size: 10pt; color: ${C.red}; margin: 0; font-weight: bold;">TOO SLOW at 1kHz</p>
      <p style="font-size: 9pt; color: ${C.grayDark}; margin: 4pt 0 0;">Variable timing, memory fragmentation, JSON injection risk</p>
    </div>
    <div class="col col-good">
      <p style="font-size: 14pt; color: ${C.green}; margin: 0; font-weight: bold;">NEXUS Bytecode VM</p>
      <p style="font-size: 28pt; color: ${C.green}; margin: 8pt 0 2pt; font-weight: bold;">100us</p>
      <p style="font-size: 10pt; color: ${C.gray}; margin: 0 0 6pt;">per cycle</p>
      <p style="font-size: 10pt; color: ${C.green}; margin: 0; font-weight: bold;">10x FASTER, deterministic</p>
      <p style="font-size: 9pt; color: ${C.grayDark}; margin: 4pt 0 0;">Fixed cycle count, zero allocation, type-safe sandbox</p>
    </div>
  </div>
  <div class="metrics">
    <div class="metric"><p style="margin: 0; font-size: 16pt; color: ${C.accent}; font-weight: bold;">32</p><p style="margin: 2pt 0 0; font-size: 8pt; color: ${C.gray};">opcodes</p></div>
    <div class="metric"><p style="margin: 0; font-size: 16pt; color: ${C.accent}; font-weight: bold;">8B</p><p style="margin: 2pt 0 0; font-size: 8pt; color: ${C.gray};">instructions</p></div>
    <div class="metric"><p style="margin: 0; font-size: 16pt; color: ${C.accent}; font-weight: bold;">3KB</p><p style="margin: 2pt 0 0; font-size: 8pt; color: ${C.gray};">memory footprint</p></div>
  </div>
</div>
</body></html>`);
}

function slide08_safety() {
  return writeSlide(8, `<!DOCTYPE html><html><head><style>
${baseCSS(`
.header { margin: 24pt 36pt 0; display: flex; align-items: center; gap: 10pt; }
.content { display: flex; flex-direction: column; flex: 1; margin: 10pt 36pt 18pt; gap: 6pt; justify-content: center; }
.layer { display: flex; gap: 10pt; align-items: center; padding: 8pt 14pt; border-radius: 6pt; }
.l4 { background: ${C.bgCard}; border-left: 4px solid ${C.accentDim}; }
.l3 { background: ${C.bgCard}; border-left: 4px solid ${C.yellow}; }
.l2 { background: ${C.bgCard}; border-left: 4px solid ${C.orange}; }
.l1 { background: ${C.bgCard}; border-left: 4px solid ${C.red}; }
.time-badge { border-radius: 4pt; padding: 2pt 8pt; min-width: 72pt; text-align: center; }
.badge-app { background: ${C.accentDim}; }
.badge-sup { background: #665500; }
.badge-fw { background: #663300; }
.badge-hw { background: #660022; }
.compliance { background: ${C.bgCard}; border: 1px solid ${C.green}; border-radius: 6pt; padding: 8pt 14pt; text-align: center; margin-top: 4pt; }
`)}
</style></head><body>
<div class="header">
  <img src="accent_line.png" style="width: 30pt; height: 3pt;">
  <h2 style="font-size: 22pt; margin: 0;">SAFETY: FOUR INDEPENDENT LAYERS</h2>
</div>
<div class="content">
  <div class="layer l4">
    <div class="time-badge badge-app"><p style="margin:0; font-size: 9pt; color: ${C.accent}; font-weight: bold;">APPLICATION</p></div>
    <p style="margin: 0; font-size: 11pt;">PID, AI, reflexes  |  lowest authority, always overridable</p>
  </div>
  <div class="layer l3">
    <div class="time-badge badge-sup"><p style="margin:0; font-size: 9pt; color: ${C.yellow}; font-weight: bold;">SUPERVISOR</p></div>
    <p style="margin: 0; font-size: 11pt;">Heartbeat, task watchdog  |  <b>&lt; 100ms</b> response</p>
  </div>
  <div class="layer l2">
    <div class="time-badge badge-fw"><p style="margin:0; font-size: 9pt; color: ${C.orange}; font-weight: bold;">FIRMWARE ISR</p></div>
    <p style="margin: 0; font-size: 11pt;">E-stop interrupt, overcurrent  |  <b>&lt; 10ms</b> response</p>
  </div>
  <div class="layer l1">
    <div class="time-badge badge-hw"><p style="margin:0; font-size: 9pt; color: ${C.red}; font-weight: bold;">HARDWARE</p></div>
    <p style="margin: 0; font-size: 11pt;">Kill switch, watchdog, fuses  |  <b>&lt; 1ms</b>, ABSOLUTE authority</p>
  </div>
  <div class="compliance">
    <p style="margin: 0; font-size: 12pt; color: ${C.green}; font-weight: bold;">Compliant with IEC 61508 SIL 1</p>
    <p style="margin: 2pt 0 0; font-size: 9pt; color: ${C.gray};">Defense in depth: no single tier is sufficient</p>
  </div>
</div>
</body></html>`);
}

function slide09_trust() {
  return writeSlide(9, `<!DOCTYPE html><html><head><style>
${baseCSS(`
.header { margin: 24pt 36pt 0; display: flex; align-items: center; gap: 10pt; }
.content { display: flex; flex: 1; margin: 10pt 36pt 18pt; gap: 20pt; }
.left { flex: 1; display: flex; flex-direction: column; justify-content: center; gap: 8pt; }
.right { flex: 1.2; display: flex; flex-direction: column; justify-content: center; gap: 4pt; }
.level { display: flex; align-items: center; gap: 8pt; }
.level-bar { height: 18pt; border-radius: 3pt; display: flex; align-items: center; padding: 0 8pt; }
.stair { background: ${C.bgCard}; border-radius: 4pt; padding: 6pt 10pt; border-left: 3px solid ${C.accentDim}; }
.stat-card { background: ${C.bgCard}; border: 1px solid ${C.red}; border-radius: 6pt; padding: 10pt; text-align: center; }
`)}
</style></head><body>
<div class="header">
  <img src="accent_line.png" style="width: 30pt; height: 3pt;">
  <h2 style="font-size: 22pt; margin: 0;">TRUST EARNED, NEVER GIVEN</h2>
</div>
<div class="content">
  <div class="left">
    <p style="font-size: 12pt; color: ${C.white}; margin: 0; font-weight: bold;">The system earns autonomy the way a deckhand earns a captain's trust: slowly.</p>
    <p style="font-size: 10pt; color: ${C.gray}; margin: 0;">Based on human psychology research (Lee & See, 2004).</p>
    <div class="stat-card">
      <p style="margin: 0; font-size: 28pt; color: ${C.red}; font-weight: bold;">25:1</p>
      <p style="margin: 2pt 0 0; font-size: 10pt; color: ${C.gray};">trust loss : gain ratio</p>
    </div>
    <p style="font-size: 10pt; color: ${C.gray}; margin: 0;">50 good operations to gain 0.1 trust</p>
    <p style="font-size: 10pt; color: ${C.red}; margin: 0; font-weight: bold;">2 bad operations to lose it</p>
  </div>
  <div class="right">
    <div class="stair" style="border-left-color: ${C.gray}; width: 60pt;"><p style="margin:0; font-size: 9pt; color: ${C.gray}; font-weight: bold;">L0 MANUAL</p></div>
    <div class="stair" style="border-left-color: ${C.accentDim}; width: 120pt;"><p style="margin:0; font-size: 9pt; color: ${C.accentDim}; font-weight: bold;">L1 ASSIST</p></div>
    <div class="stair" style="border-left-color: ${C.accent}; width: 180pt;"><p style="margin:0; font-size: 9pt; color: ${C.accent}; font-weight: bold;">L2 SEMI-AUTO</p></div>
    <div class="stair" style="border-left-color: ${C.yellow}; width: 240pt;"><p style="margin:0; font-size: 9pt; color: ${C.yellow}; font-weight: bold;">L3 CONDITIONAL</p><p style="margin: 1pt 0 0; font-size: 8pt; color: ${C.grayDark};">~120 days flawless</p></div>
    <div class="stair" style="border-left-color: ${C.green}; width: 310pt;"><p style="margin:0; font-size: 9pt; color: ${C.green}; font-weight: bold;">L4 HIGH</p></div>
    <div class="stair" style="border-left-color: ${C.green}; width: 380pt; border-color: ${C.green};"><p style="margin:0; font-size: 9pt; color: ${C.green}; font-weight: bold;">L5 FULL</p><p style="margin: 1pt 0 0; font-size: 8pt; color: ${C.grayDark};">~300 days flawless</p></div>
  </div>
</div>
</body></html>`);
}

function slide10_hardware() {
  return writeSlide(10, `<!DOCTYPE html><html><head><style>
${baseCSS(`
.header { margin: 24pt 36pt 0; display: flex; align-items: center; gap: 10pt; }
.content { display: flex; flex-direction: column; flex: 1; margin: 10pt 36pt 18pt; justify-content: center; gap: 12pt; }
.specs { display: flex; gap: 12pt; justify-content: center; flex-wrap: wrap; }
.spec { background: ${C.bgCard}; border: 1px solid ${C.accentDim}; border-radius: 6pt; padding: 10pt 14pt; text-align: center; flex: 1; min-width: 100pt; }
.chips { display: flex; gap: 10pt; justify-content: center; }
.chip { background: ${C.bgCard}; border: 1px solid ${C.accentDim}; border-radius: 6pt; padding: 8pt 14pt; text-align: center; }
`)}
</style></head><body>
<div class="header">
  <img src="accent_line.png" style="width: 30pt; height: 3pt;">
  <h2 style="font-size: 22pt; margin: 0;">HARDWARE-AGNOSTIC BY DESIGN</h2>
</div>
<div class="content">
  <p style="font-size: 13pt; color: ${C.white}; margin: 0; text-align: center; font-weight: bold;">Works on any MCU meeting minimal specs.</p>
  <div class="specs">
    <div class="spec"><p style="margin:0; font-size: 16pt; color: ${C.accent}; font-weight: bold;">200MHz</p><p style="margin:2pt 0 0; font-size: 9pt; color: ${C.gray};">dual-core</p></div>
    <div class="spec"><p style="margin:0; font-size: 16pt; color: ${C.accent}; font-weight: bold;">512KB</p><p style="margin:2pt 0 0; font-size: 9pt; color: ${C.gray};">SRAM</p></div>
    <div class="spec"><p style="margin:0; font-size: 16pt; color: ${C.accent}; font-weight: bold;">4MB</p><p style="margin:2pt 0 0; font-size: 9pt; color: ${C.gray};">flash</p></div>
    <div class="spec"><p style="margin:0; font-size: 16pt; color: ${C.accent}; font-weight: bold;">1 UART</p><p style="margin:2pt 0 0; font-size: 9pt; color: ${C.gray};">minimum</p></div>
  </div>
  <p style="font-size: 10pt; color: ${C.gray}; margin: 0; text-align: center;">13 MCU families evaluated. The bar is deliberately LOW.</p>
  <div class="chips">
    <div class="chip"><p style="margin:0; font-size: 11pt; color: ${C.green}; font-weight: bold;">ESP32-S3</p><p style="margin:2pt 0 0; font-size: 8pt; color: ${C.gray};">$6  |  Reference</p></div>
    <div class="chip"><p style="margin:0; font-size: 11pt; color: ${C.accent}; font-weight: bold;">STM32H7</p><p style="margin:2pt 0 0; font-size: 8pt; color: ${C.gray};">480MHz</p></div>
    <div class="chip"><p style="margin:0; font-size: 11pt; color: ${C.accent}; font-weight: bold;">Teensy 4.1</p><p style="margin:2pt 0 0; font-size: 8pt; color: ${C.gray};">600MHz</p></div>
    <div class="chip"><p style="margin:0; font-size: 11pt; color: ${C.accent}; font-weight: bold;">ESP32-P4</p><p style="margin:2pt 0 0; font-size: 8pt; color: ${C.gray};">400MHz</p></div>
  </div>
</div>
</body></html>`);
}

function slide11_protocol() {
  return writeSlide(11, `<!DOCTYPE html><html><head><style>
${baseCSS(`
.header { margin: 24pt 36pt 0; display: flex; align-items: center; gap: 10pt; }
.content { display: flex; flex-direction: column; flex: 1; margin: 12pt 36pt 20pt; justify-content: center; gap: 14pt; }
.frame { background: ${C.bgCard}; border: 1px solid ${C.accent}; border-radius: 6pt; padding: 14pt 20pt; text-align: center; }
.frame-parts { display: flex; gap: 4pt; justify-content: center; align-items: center; }
.part { border-radius: 4pt; padding: 6pt 10pt; text-align: center; }
.delim { background: ${C.red}; opacity: 0.8; }
.payload { background: ${C.accent}; }
.crc { background: ${C.yellow}; }
.stats { display: flex; gap: 12pt; justify-content: center; }
.stat { background: ${C.bgCard}; border: 1px solid ${C.accentDim}; border-radius: 6pt; padding: 8pt 14pt; text-align: center; }
`)}
</style></head><body>
<div class="header">
  <img src="accent_line.png" style="width: 30pt; height: 3pt;">
  <h2 style="font-size: 22pt; margin: 0;">WIRE PROTOCOL</h2>
</div>
<div class="content">
  <p style="font-size: 13pt; color: ${C.white}; margin: 0; text-align: center; font-weight: bold;">Every byte matters.</p>
  <div class="frame">
    <p style="margin: 0 0 8pt; font-size: 10pt; color: ${C.gray};">COBS-framed message structure</p>
    <div class="frame-parts">
      <div class="part delim"><p style="margin:0; font-size: 10pt; color: ${C.white}; font-weight: bold;">0x00</p></div>
      <div class="part payload"><p style="margin:0; font-size: 10pt; color: ${C.bg}; font-weight: bold;">COBS-encoded payload</p></div>
      <div class="part crc"><p style="margin:0; font-size: 10pt; color: ${C.bg}; font-weight: bold;">CRC-16</p></div>
      <div class="part delim"><p style="margin:0; font-size: 10pt; color: ${C.white}; font-weight: bold;">0x00</p></div>
    </div>
    <p style="margin: 8pt 0 0; font-size: 9pt; color: ${C.gray};">Self-synchronizing. 0.4% overhead vs. 33% for base64.</p>
  </div>
  <div class="stats">
    <div class="stat"><p style="margin:0; font-size: 16pt; color: ${C.accent}; font-weight: bold;">28</p><p style="margin:2pt 0 0; font-size: 8pt; color: ${C.gray};">message types</p></div>
    <div class="stat"><p style="margin:0; font-size: 16pt; color: ${C.accent}; font-weight: bold;">75</p><p style="margin:2pt 0 0; font-size: 8pt; color: ${C.gray};">error codes</p></div>
    <div class="stat"><p style="margin:0; font-size: 16pt; color: ${C.accent}; font-weight: bold;">921600</p><p style="margin:2pt 0 0; font-size: 8pt; color: ${C.gray};">baud RS-422</p></div>
    <div class="stat"><p style="margin:0; font-size: 16pt; color: ${C.accent}; font-weight: bold;">10m</p><p style="margin:2pt 0 0; font-size: 8pt; color: ${C.gray};">cable runs</p></div>
  </div>
</div>
</body></html>`);
}

function slide12_applications() {
  return writeSlide(12, `<!DOCTYPE html><html><head><style>
${baseCSS(`
.header { margin: 24pt 36pt 0; display: flex; align-items: center; gap: 10pt; }
.content { display: flex; flex-direction: column; flex: 1; margin: 14pt 36pt 20pt; justify-content: center; gap: 14pt; }
.grid { display: flex; gap: 12pt; flex-wrap: wrap; justify-content: center; }
.card { background: ${C.bgCard}; border: 1px solid ${C.accentDim}; border-radius: 8pt; padding: 14pt; width: 180pt; text-align: center; }
.footer-note { text-align: center; }
`)}
</style></head><body>
<div class="header">
  <img src="accent_line.png" style="width: 30pt; height: 3pt;">
  <h2 style="font-size: 22pt; margin: 0;">REAL-WORLD APPLICATIONS</h2>
</div>
<div class="content">
  <div class="grid">
    <div class="card">
      <p style="margin: 0; font-size: 20pt; color: ${C.accent};">&#9875;</p>
      <p style="margin: 4pt 0 0; font-size: 12pt; font-weight: bold;">Marine Vessels</p>
      <p style="margin: 2pt 0 0; font-size: 9pt; color: ${C.gray};">Autopilot, engine, bilge</p>
    </div>
    <div class="card">
      <p style="margin: 0; font-size: 20pt; color: ${C.green};">&#9752;</p>
      <p style="margin: 4pt 0 0; font-size: 12pt; font-weight: bold;">Agriculture</p>
      <p style="margin: 2pt 0 0; font-size: 9pt; color: ${C.gray};">Irrigation, harvest timing</p>
    </div>
    <div class="card">
      <p style="margin: 0; font-size: 20pt; color: ${C.yellow};">&#9729;</p>
      <p style="margin: 4pt 0 0; font-size: 12pt; font-weight: bold;">HVAC Systems</p>
      <p style="margin: 2pt 0 0; font-size: 9pt; color: ${C.gray};">Zone control, energy</p>
    </div>
    <div class="card">
      <p style="margin: 0; font-size: 20pt; color: ${C.orange};">&#9881;</p>
      <p style="margin: 4pt 0 0; font-size: 12pt; font-weight: bold;">Factory Automation</p>
      <p style="margin: 2pt 0 0; font-size: 9pt; color: ${C.gray};">Conveyors, quality</p>
    </div>
    <div class="card">
      <p style="margin: 0; font-size: 20pt; color: ${C.red};">&#9874;</p>
      <p style="margin: 4pt 0 0; font-size: 12pt; font-weight: bold;">Mining Operations</p>
      <p style="margin: 2pt 0 0; font-size: 9pt; color: ${C.gray};">Ventilation, pumps</p>
    </div>
    <div class="card">
      <p style="margin: 0; font-size: 20pt; color: ${C.accentDim};">&#8962;</p>
      <p style="margin: 4pt 0 0; font-size: 12pt; font-weight: bold;">Home Automation</p>
      <p style="margin: 2pt 0 0; font-size: 9pt; color: ${C.gray};">Lighting, security</p>
    </div>
  </div>
  <div class="footer-note">
    <p style="font-size: 12pt; color: ${C.white}; margin: 0; font-weight: bold;">Same platform. Different configuration. Zero code changes.</p>
  </div>
</div>
</body></html>`);
}

function slide13_marine() {
  return writeSlide(13, `<!DOCTYPE html><html><head><style>
${baseCSS(`
.header { margin: 24pt 36pt 0; display: flex; align-items: center; gap: 10pt; }
.content { display: flex; flex-direction: column; flex: 1; margin: 10pt 36pt 18pt; gap: 10pt; justify-content: center; }
.timeline { display: flex; gap: 6pt; align-items: flex-end; justify-content: center; }
.phase { background: ${C.bgCard}; border-radius: 6pt; padding: 8pt 10pt; text-align: center; border-bottom: 3px solid ${C.accentDim}; }
.phase-active { border-bottom-color: ${C.accent}; }
.validated { background: ${C.bgCard}; border: 1px solid ${C.green}; border-radius: 6pt; padding: 10pt 14pt; display: flex; gap: 16pt; justify-content: center; }
.v-item { text-align: center; }
`)}
</style></head><body>
<div class="header">
  <img src="accent_line.png" style="width: 30pt; height: 3pt;">
  <h2 style="font-size: 20pt; margin: 0;">MARINE PROVENANCE</h2>
</div>
<div class="content">
  <p style="font-size: 12pt; color: ${C.white}; margin: 0; text-align: center; font-weight: bold;">Born from 7 phases of iterative marine autopilot engineering.</p>
  <div class="timeline">
    <div class="phase" style="width: 110pt; height: 50pt;">
      <p style="margin:0; font-size: 8pt; color: ${C.grayDark};">PHASE 1</p>
      <p style="margin:2pt 0 0; font-size: 9pt; color: ${C.gray};">AI Chatbot</p>
    </div>
    <div class="phase" style="width: 110pt; height: 60pt;">
      <p style="margin:0; font-size: 8pt; color: ${C.grayDark};">PHASE 3</p>
      <p style="margin:2pt 0 0; font-size: 9pt; color: ${C.gray};">PID Autopilot</p>
    </div>
    <div class="phase" style="width: 110pt; height: 80pt;">
      <p style="margin:0; font-size: 8pt; color: ${C.grayDark};">PHASE 5</p>
      <p style="margin:2pt 0 0; font-size: 9pt; color: ${C.accent}; font-weight: bold;">Vessel Robotics</p>
    </div>
    <div class="phase phase-active" style="width: 110pt; height: 100pt;">
      <p style="margin:0; font-size: 8pt; color: ${C.accent};">PHASE 7</p>
      <p style="margin:2pt 0 0; font-size: 10pt; color: ${C.accent}; font-weight: bold;">General Platform</p>
    </div>
  </div>
  <div class="validated">
    <div class="v-item"><p style="margin:0; font-size: 14pt; color: ${C.green}; font-weight: bold;">14</p><p style="margin:2pt 0 0; font-size: 8pt; color: ${C.gray};">safety fixes</p></div>
    <div class="v-item"><p style="margin:0; font-size: 14pt; color: ${C.green}; font-weight: bold;">6</p><p style="margin:2pt 0 0; font-size: 8pt; color: ${C.gray};">sim scenarios</p></div>
    <div class="v-item"><p style="margin:0; font-size: 14pt; color: ${C.green}; font-weight: bold;">90 deg</p><p style="margin:2pt 0 0; font-size: 8pt; color: ${C.gray};">step stable</p></div>
    <div class="v-item"><p style="margin:0; font-size: 14pt; color: ${C.green}; font-weight: bold;">30 deg/s</p><p style="margin:2pt 0 0; font-size: 8pt; color: ${C.gray};">sustained rate</p></div>
  </div>
</div>
</body></html>`);
}

function slide14_learning() {
  return writeSlide(14, `<!DOCTYPE html><html><head><style>
${baseCSS(`
.header { margin: 24pt 36pt 0; display: flex; align-items: center; gap: 10pt; }
.content { display: flex; flex-direction: column; flex: 1; margin: 10pt 36pt 18pt; gap: 6pt; justify-content: center; }
.algo { display: flex; align-items: center; gap: 10pt; background: ${C.bgCard}; border-radius: 6pt; padding: 8pt 14pt; border-left: 3px solid ${C.accentDim}; }
.num { background: ${C.accent}; color: ${C.bg}; border-radius: 50%; width: 22pt; height: 22pt; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
`)}
</style></head><body>
<div class="header">
  <img src="accent_line.png" style="width: 30pt; height: 3pt;">
  <h2 style="font-size: 22pt; margin: 0;">THE LEARNING PIPELINE</h2>
</div>
<div class="content">
  <p style="font-size: 12pt; color: ${C.white}; margin: 0 0 4pt; text-align: center; font-weight: bold;">Five algorithms working together after each recording session:</p>
  <div class="algo">
    <div class="num"><p style="margin:0; font-size: 10pt; font-weight: bold; color: ${C.bg};">1</p></div>
    <div><p style="margin:0; font-size: 11pt; font-weight: bold; color: ${C.white};">Cross-Correlation</p><p style="margin:1pt 0 0; font-size: 9pt; color: ${C.gray};">What changes together?  2,556 sensor pairs, -60s to +60s lag</p></div>
  </div>
  <div class="algo">
    <div class="num"><p style="margin:0; font-size: 10pt; font-weight: bold; color: ${C.bg};">2</p></div>
    <div><p style="margin:0; font-size: 11pt; font-weight: bold; color: ${C.white};">Change-Point Detection</p><p style="margin:1pt 0 0; font-size: 9pt; color: ${C.gray};">When do things shift?  Bayesian algorithm, detects regime changes</p></div>
  </div>
  <div class="algo">
    <div class="num"><p style="margin:0; font-size: 10pt; font-weight: bold; color: ${C.bg};">3</p></div>
    <div><p style="margin:0; font-size: 11pt; font-weight: bold; color: ${C.white};">Behavioral Clustering (HDBSCAN)</p><p style="margin:1pt 0 0; font-size: 9pt; color: ${C.gray};">What patterns emerge?  Groups behavior windows automatically</p></div>
  </div>
  <div class="algo">
    <div class="num"><p style="margin:0; font-size: 10pt; font-weight: bold; color: ${C.bg};">4</p></div>
    <div><p style="margin:0; font-size: 11pt; font-weight: bold; color: ${C.white};">Temporal Rule Mining</p><p style="margin:1pt 0 0; font-size: 9pt; color: ${C.gray};">When X happens, do Y?  Recurring event-response patterns</p></div>
  </div>
  <div class="algo">
    <div class="num"><p style="margin:0; font-size: 10pt; font-weight: bold; color: ${C.bg};">5</p></div>
    <div><p style="margin:0; font-size: 11pt; font-weight: bold; color: ${C.white};">Bayesian Reward Inference</p><p style="margin:1pt 0 0; font-size: 9pt; color: ${C.gray};">Why humans do what they do?  Infers motivation weights</p></div>
  </div>
</div>
</body></html>`);
}

function slide15_build() {
  return writeSlide(15, `<!DOCTYPE html><html><head><style>
${baseCSS(`
.header { margin: 24pt 36pt 0; display: flex; align-items: center; gap: 10pt; }
.content { display: flex; flex: 1; margin: 12pt 36pt 20pt; gap: 20pt; }
.left { flex: 1; display: flex; flex-direction: column; justify-content: center; gap: 10pt; }
.right { flex: 1; display: flex; flex-direction: column; justify-content: center; gap: 10pt; }
.milestone { background: ${C.bgCard}; border-radius: 6pt; padding: 12pt 14pt; border-left: 3px solid ${C.accent}; }
.team-card { background: ${C.bgCard}; border: 1px solid ${C.accentDim}; border-radius: 6pt; padding: 10pt 14pt; }
`)}
</style></head><body>
<div class="header">
  <img src="accent_line.png" style="width: 30pt; height: 3pt;">
  <h2 style="font-size: 22pt; margin: 0;">BUILD IT</h2>
</div>
<div class="content">
  <div class="left">
    <div class="milestone">
      <p style="margin: 0; font-size: 11pt; color: ${C.accent}; font-weight: bold;">WEEK 8: First Demo</p>
      <p style="margin: 4pt 0 0; font-size: 10pt; color: ${C.gray};">LED blinker controlled by chat. User types "blink every 500ms" and it happens.</p>
    </div>
    <div class="milestone">
      <p style="margin: 0; font-size: 11pt; color: ${C.accent}; font-weight: bold;">WEEK 16: Full Autopilot</p>
      <p style="margin: 4pt 0 0; font-size: 10pt; color: ${C.gray};">Complete marine autopilot with learning pipeline and trust scoring.</p>
    </div>
  </div>
  <div class="right">
    <div class="team-card">
      <p style="margin: 0; font-size: 12pt; font-weight: bold; color: ${C.white};">Solo Developer</p>
      <p style="margin: 4pt 0 0; font-size: 24pt; color: ${C.accent}; font-weight: bold;">30-40 weeks</p>
    </div>
    <div class="team-card">
      <p style="margin: 0; font-size: 12pt; font-weight: bold; color: ${C.white};">3 Developers (parallel)</p>
      <p style="margin: 4pt 0 0; font-size: 24pt; color: ${C.green}; font-weight: bold;">12-16 weeks</p>
    </div>
    <div class="team-card" style="border-color: ${C.green};">
      <p style="margin: 0; font-size: 10pt; color: ${C.green}; font-weight: bold;">Critical path: weeks 1-8</p>
      <p style="margin: 2pt 0 0; font-size: 9pt; color: ${C.gray};">Wire protocol + VM + safety system</p>
    </div>
  </div>
</div>
</body></html>`);
}

function slide16_numbers() {
  return writeSlide(16, `<!DOCTYPE html><html><head><style>
${baseCSS(`
.header { margin: 20pt 36pt 0; display: flex; align-items: center; gap: 10pt; }
.content { display: flex; flex-wrap: wrap; gap: 10pt; margin: 10pt 30pt 16pt; justify-content: center; align-content: center; flex: 1; }
.num-card { background: ${C.bgCard}; border: 1px solid ${C.accentDim}; border-radius: 8pt; padding: 12pt 8pt; text-align: center; width: 125pt; }
.num-card-accent { border-color: ${C.accent}; }
`)}
</style></head><body>
<div class="header">
  <img src="accent_line.png" style="width: 30pt; height: 3pt;">
  <h2 style="font-size: 22pt; margin: 0;">BY THE NUMBERS</h2>
</div>
<div class="content">
  <div class="num-card num-card-accent"><p style="margin:0; font-size: 28pt; color: ${C.accent}; font-weight: bold;">21</p><p style="margin:2pt 0 0; font-size: 8pt; color: ${C.gray};">spec files</p></div>
  <div class="num-card num-card-accent"><p style="margin:0; font-size: 28pt; color: ${C.accent}; font-weight: bold;">19,200</p><p style="margin:2pt 0 0; font-size: 8pt; color: ${C.gray};">lines of spec</p></div>
  <div class="num-card num-card-accent"><p style="margin:0; font-size: 28pt; color: ${C.accent}; font-weight: bold;">28</p><p style="margin:2pt 0 0; font-size: 8pt; color: ${C.gray};">arch decisions</p></div>
  <div class="num-card"><p style="margin:0; font-size: 28pt; color: ${C.white}; font-weight: bold;">32</p><p style="margin:2pt 0 0; font-size: 8pt; color: ${C.gray};">VM opcodes</p></div>
  <div class="num-card"><p style="margin:0; font-size: 28pt; color: ${C.white}; font-weight: bold;">75</p><p style="margin:2pt 0 0; font-size: 8pt; color: ${C.gray};">error codes</p></div>
  <div class="num-card"><p style="margin:0; font-size: 28pt; color: ${C.white}; font-weight: bold;">13</p><p style="margin:2pt 0 0; font-size: 8pt; color: ${C.gray};">MCUs evaluated</p></div>
  <div class="num-card" style="border-color: ${C.green};"><p style="margin:0; font-size: 28pt; color: ${C.green}; font-weight: bold;">&lt;100us</p><p style="margin:2pt 0 0; font-size: 8pt; color: ${C.gray};">reflex cycle time</p></div>
  <div class="num-card" style="border-color: ${C.red};"><p style="margin:0; font-size: 28pt; color: ${C.red}; font-weight: bold;">&lt;1ms</p><p style="margin:2pt 0 0; font-size: 8pt; color: ${C.gray};">kill switch response</p></div>
  <div class="num-card" style="border-color: ${C.orange};"><p style="margin:0; font-size: 28pt; color: ${C.orange}; font-weight: bold;">25:1</p><p style="margin:2pt 0 0; font-size: 8pt; color: ${C.gray};">trust loss:gain ratio</p></div>
</div>
</body></html>`);
}

function slide17_decisions() {
  return writeSlide(17, `<!DOCTYPE html><html><head><style>
${baseCSS(`
.header { margin: 24pt 36pt 0; display: flex; align-items: center; gap: 10pt; }
.content { display: flex; flex-direction: column; flex: 1; margin: 10pt 36pt 18pt; gap: 6pt; justify-content: center; }
.decision { display: flex; align-items: center; gap: 10pt; background: ${C.bgCard}; border-radius: 6pt; padding: 8pt 12pt; border-left: 3px solid ${C.accentDim}; }
.conf-veryhigh { border-left-color: ${C.green}; }
.conf-high { border-left-color: ${C.accent}; }
.conf-low { border-left-color: ${C.orange}; }
.badge { border-radius: 4pt; padding: 2pt 6pt; font-size: 8pt; font-weight: bold; flex-shrink: 0; }
`)}
</style></head><body>
<div class="header">
  <img src="accent_line.png" style="width: 30pt; height: 3pt;">
  <h2 style="font-size: 22pt; margin: 0;">ARCHITECTURE DECISIONS</h2>
</div>
<div class="content">
  <p style="font-size: 10pt; color: ${C.gray}; margin: 0 0 2pt;">28 total decisions tracked. Highlights with confidence levels:</p>
  <div class="decision conf-veryhigh">
    <div class="badge" style="background: ${C.green}; color: ${C.bg};"><p style="margin:0; font-size: 7pt;">VERY HIGH</p></div>
    <div><p style="margin:0; font-size: 11pt; font-weight: bold; color: ${C.white};">RS-422 over WiFi</p><p style="margin:1pt 0 0; font-size: 9pt; color: ${C.gray};">"Metal hulls kill WiFi. Physics doesn't."</p></div>
  </div>
  <div class="decision conf-veryhigh">
    <div class="badge" style="background: ${C.green}; color: ${C.bg};"><p style="margin:0; font-size: 7pt;">VERY HIGH</p></div>
    <div><p style="margin:0; font-size: 11pt; font-weight: bold; color: ${C.white};">Separate LLM for Validation</p><p style="margin:1pt 0 0; font-size: 9pt; color: ${C.gray};">"Same model validating its own code = bias"</p></div>
  </div>
  <div class="decision conf-high">
    <div class="badge" style="background: ${C.accent}; color: ${C.bg};"><p style="margin:0; font-size: 7pt;">HIGH</p></div>
    <div><p style="margin:0; font-size: 11pt; font-weight: bold; color: ${C.white};">Bytecode over JSON</p><p style="margin:1pt 0 0; font-size: 9pt; color: ${C.gray};">"10x faster. Deterministic. Non-negotiable."</p></div>
  </div>
  <div class="decision conf-low">
    <div class="badge" style="background: ${C.orange}; color: ${C.bg};"><p style="margin:0; font-size: 7pt;">LOW</p></div>
    <div><p style="margin:0; font-size: 11pt; font-weight: bold; color: ${C.white};">Inverse RL for Reward Inference</p><p style="margin:1pt 0 0; font-size: 9pt; color: ${C.gray};">"Academic technique. We're honest about uncertainty."</p></div>
  </div>
</div>
</body></html>`);
}

function slide18_questions() {
  return writeSlide(18, `<!DOCTYPE html><html><head><style>
${baseCSS(`
.header { margin: 24pt 36pt 0; display: flex; align-items: center; gap: 10pt; }
.content { display: flex; flex-direction: column; flex: 1; margin: 12pt 36pt 20pt; justify-content: center; gap: 10pt; }
.q { display: flex; align-items: center; gap: 12pt; background: ${C.bgCard}; border: 1px solid ${C.yellow}; border-radius: 6pt; padding: 10pt 14pt; }
.q-icon { background: ${C.yellow}; color: ${C.bg}; border-radius: 50%; width: 22pt; height: 22pt; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.options { display: flex; gap: 6pt; }
.opt { background: ${C.bgCardLight}; border: 1px solid ${C.accentDim}; border-radius: 4pt; padding: 3pt 8pt; }
`)}
</style></head><body>
<div class="header">
  <img src="accent_line.png" style="width: 30pt; height: 3pt;">
  <h2 style="font-size: 22pt; margin: 0;">OPEN QUESTIONS</h2>
</div>
<div class="content">
  <p style="font-size: 12pt; color: ${C.white}; margin: 0; text-align: center; font-weight: bold;">Decisions left for the engineering team:</p>
  <div class="q">
    <div class="q-icon"><p style="margin:0; font-size: 11pt; font-weight: bold; color: ${C.bg};">?</p></div>
    <div><p style="margin:0; font-size: 11pt; font-weight: bold;">OTA Signing Algorithm</p>
    <div class="options"><div class="opt"><p style="margin:0; font-size: 9pt; color: ${C.accent};">ECDSA-P256</p></div><div class="opt"><p style="margin:0; font-size: 9pt; color: ${C.gray};">vs Ed25519</p></div></div></div>
  </div>
  <div class="q">
    <div class="q-icon"><p style="margin:0; font-size: 11pt; font-weight: bold; color: ${C.bg};">?</p></div>
    <div><p style="margin:0; font-size: 11pt; font-weight: bold;">MQTT Broker</p>
    <div class="options"><div class="opt"><p style="margin:0; font-size: 9pt; color: ${C.accent};">Mosquitto</p></div><div class="opt"><p style="margin:0; font-size: 9pt; color: ${C.gray};">vs EMQX</p></div></div></div>
  </div>
  <div class="q">
    <div class="q-icon"><p style="margin:0; font-size: 11pt; font-weight: bold; color: ${C.bg};">?</p></div>
    <div><p style="margin:0; font-size: 11pt; font-weight: bold;">Database</p>
    <div class="options"><div class="opt"><p style="margin:0; font-size: 9pt; color: ${C.accent};">SQLite</p></div><div class="opt"><p style="margin:0; font-size: 9pt; color: ${C.gray};">vs PostgreSQL</p></div></div></div>
  </div>
  <div class="q">
    <div class="q-icon"><p style="margin:0; font-size: 11pt; font-weight: bold; color: ${C.bg};">?</p></div>
    <div><p style="margin:0; font-size: 11pt; font-weight: bold;">Which Local LLM Model?</p>
    <div class="options"><div class="opt"><p style="margin:0; font-size: 9pt; color: ${C.yellow};">Landscape changes monthly</p></div></div></div>
  </div>
</div>
</body></html>`);
}

function slide19_promise() {
  return writeSlide(19, `<!DOCTYPE html><html><head><style>
${baseCSS(`
.header { margin: 24pt 36pt 0; display: flex; align-items: center; gap: 10pt; }
.content { display: flex; flex-direction: column; flex: 1; margin: 12pt 36pt 20pt; align-items: center; justify-content: center; gap: 16pt; }
.promise { text-align: center; }
.cols { display: flex; gap: 16pt; }
.col { background: ${C.bgCard}; border: 1px solid ${C.accentDim}; border-radius: 8pt; padding: 14pt 16pt; text-align: center; width: 160pt; }
.tagline { background: ${C.bgCard}; border: 1px solid ${C.accent}; border-radius: 6pt; padding: 10pt 24pt; text-align: center; }
`)}
</style></head><body>
<div class="header">
  <img src="accent_line.png" style="width: 30pt; height: 3pt;">
  <h2 style="font-size: 22pt; margin: 0;">THE POST-CODING PROMISE</h2>
</div>
<div class="content">
  <div class="promise">
    <p style="font-size: 14pt; color: ${C.white}; margin: 0; font-weight: bold;">Your engineers wire hardware.</p>
    <p style="font-size: 14pt; color: ${C.white}; margin: 2pt 0; font-weight: bold;">Your operators describe intent.</p>
    <p style="font-size: 14pt; color: ${C.accent}; margin: 0; font-weight: bold;">Your system writes itself.</p>
  </div>
  <div class="cols">
    <div class="col">
      <p style="margin: 0; font-size: 20pt; color: ${C.accent};">&#9998;</p>
      <p style="margin: 4pt 0 0; font-size: 14pt; font-weight: bold; color: ${C.white};">DESCRIBE</p>
      <p style="margin: 4pt 0 0; font-size: 9pt; color: ${C.gray};">Natural language intent</p>
    </div>
    <div class="col">
      <p style="margin: 0; font-size: 20pt; color: ${C.accent};">&#9654;</p>
      <p style="margin: 4pt 0 0; font-size: 14pt; font-weight: bold; color: ${C.white};">DEMONSTRATE</p>
      <p style="margin: 4pt 0 0; font-size: 9pt; color: ${C.gray};">Record desired behavior</p>
    </div>
    <div class="col">
      <p style="margin: 0; font-size: 20pt; color: ${C.accent};">&#10003;</p>
      <p style="margin: 4pt 0 0; font-size: 14pt; font-weight: bold; color: ${C.white};">APPROVE</p>
      <p style="margin: 4pt 0 0; font-size: 9pt; color: ${C.gray};">Yes or no. That's it.</p>
    </div>
  </div>
  <div class="tagline">
    <p style="font-size: 14pt; color: ${C.accent}; margin: 0; font-weight: bold;">Code becomes invisible infrastructure.</p>
  </div>
</div>
</body></html>`);
}

function slide20_getstarted() {
  return writeSlide(20, `<!DOCTYPE html><html><head><style>
${baseCSS(`
.header { margin: 24pt 36pt 0; display: flex; align-items: center; gap: 10pt; }
.content { display: flex; flex: 1; margin: 10pt 36pt 18pt; gap: 20pt; }
.left { flex: 1; display: flex; flex-direction: column; justify-content: center; gap: 10pt; }
.right { flex: 1; display: flex; flex-direction: column; justify-content: center; gap: 8pt; }
.file-tree { background: ${C.bgCard}; border: 1px solid ${C.accentDim}; border-radius: 6pt; padding: 10pt 14pt; }
.action { background: ${C.bgCard}; border: 1px solid ${C.green}; border-radius: 6pt; padding: 12pt 14pt; }
`)}
</style></head><body>
<div class="header">
  <img src="accent_line.png" style="width: 30pt; height: 3pt;">
  <h2 style="font-size: 22pt; margin: 0;">GET STARTED</h2>
</div>
<div class="content">
  <div class="left">
    <p style="font-size: 13pt; color: ${C.white}; margin: 0; font-weight: bold;">Everything is specified.</p>
    <p style="font-size: 12pt; color: ${C.gray}; margin: 0;">21 production-ready files. Ready for your senior engineer.</p>
    <div class="action">
      <p style="margin: 0; font-size: 11pt; color: ${C.green}; font-weight: bold;">Start here:</p>
      <p style="margin: 4pt 0 0; font-size: 10pt; color: ${C.white};">ARCHITECTURE_DECISION_RECORDS.md</p>
      <p style="margin: 2pt 0 0; font-size: 9pt; color: ${C.gray};">Focus on MEDIUM and LOW confidence decisions first.</p>
    </div>
  </div>
  <div class="right">
    <div class="file-tree">
      <p style="margin: 0; font-size: 10pt; color: ${C.accent}; font-weight: bold;">21 Specification Files</p>
      <p style="margin: 6pt 0 0; font-size: 9pt; color: ${C.gray}; font-family: 'Courier New', monospace;">NEXUS_PLATFORM_OVERVIEW.md</p>
      <p style="margin: 1pt 0; font-size: 9pt; color: ${C.gray}; font-family: 'Courier New', monospace;">ARCHITECTURE_DECISION_RECORDS.md</p>
      <p style="margin: 1pt 0; font-size: 9pt; color: ${C.gray}; font-family: 'Courier New', monospace;">FIRMWARE_SPEC.md</p>
      <p style="margin: 1pt 0; font-size: 9pt; color: ${C.gray}; font-family: 'Courier New', monospace;">VM_SPEC.md</p>
      <p style="margin: 1pt 0; font-size: 9pt; color: ${C.gray}; font-family: 'Courier New', monospace;">WIRE_PROTOCOL_SPEC.md</p>
      <p style="margin: 1pt 0; font-size: 9pt; color: ${C.gray}; font-family: 'Courier New', monospace;">SAFETY_SYSTEM_SPEC.md</p>
      <p style="margin: 1pt 0; font-size: 9pt; color: ${C.grayDark};">... and 15 more files</p>
    </div>
    <div style="background: ${C.bgCard}; border: 1px solid ${C.accent}; border-radius: 6pt; padding: 8pt 14pt; text-align: center;">
      <p style="margin: 0; font-size: 12pt; color: ${C.accent}; font-weight: bold;">~19,200 lines  |  28 decisions  |  Ready to build</p>
    </div>
  </div>
</div>
</body></html>`);
}

// ==================== BUILD PPTX ====================

async function build() {
  console.log('Generating HTML slides...');
  const slides = [
    slide01_cover(),
    slide02_problem(),
    slide03_vision(),
    slide04_howitworks(),
    slide05_architecture(),
    slide06_limb(),
    slide07_bytecode(),
    slide08_safety(),
    slide09_trust(),
    slide10_hardware(),
    slide11_protocol(),
    slide12_applications(),
    slide13_marine(),
    slide14_learning(),
    slide15_build(),
    slide16_numbers(),
    slide17_decisions(),
    slide18_questions(),
    slide19_promise(),
    slide20_getstarted(),
  ];
  console.log(`Generated ${slides.length} HTML slides.`);
  
  console.log('Building PPTX...');
  const pptx = new pptxgen();
  pptx.layout = 'LAYOUT_16x9';
  pptx.author = 'NEXUS Architecture Team';
  pptx.title = 'NEXUS Platform - The Post-Coding Intelligence Platform';
  
  for (let i = 0; i < slides.length; i++) {
    const fname = slides[i];
    console.log(`  Processing slide ${i+1}: ${fname}`);
    try {
      await html2pptx(path.join(DIR, fname), pptx);
    } catch (err) {
      console.error(`  ERROR on slide ${i+1}:`, err.message);
      // Continue with remaining slides
    }
  }
  
  const outPath = '/home/z/my-project/download/nexus_final/NEXUS_Platform_General_Audience.pptx';
  await pptx.writeFile({ fileName: outPath });
  console.log(`\nPresentation saved to: ${outPath}`);
}

build().catch(err => {
  console.error('Build failed:', err);
  process.exit(1);
});
