const pptxgen = require('pptxgenjs');
const fs = require('fs');

// Read the PPTX to get slide count and basic info
async function validate() {
  const outPath = '/home/z/my-project/download/nexus_final/NEXUS_Platform_General_Audience.pptx';
  
  if (!fs.existsSync(outPath)) {
    console.error('ERROR: PPTX file not found at', outPath);
    process.exit(1);
  }
  
  const stats = fs.statSync(outPath);
  console.log(`File: ${outPath}`);
  console.log(`Size: ${(stats.size / 1024).toFixed(1)} KB`);
  console.log(`Modified: ${stats.mtime.toISOString()}`);
  
  // Verify it's a valid PPTX (it's a zip file)
  const JSZip = require('/home/z/my-project/download/nexus_final/slides/node_modules/jszip');
  // pptxgenjs uses JSZip internally, let's check
  try {
    const AdmZip = require('/home/z/my-project/download/nexus_final/slides/node_modules/adm-zip');
    if (AdmZip) {
      const zip = new AdmZip(outPath);
      const entries = zip.getEntries();
      const slideEntries = entries.filter(e => e.entryName.match(/ppt\/slides\/slide\d+\.xml/));
      console.log(`Slides found in PPTX: ${slideEntries.length}`);
      
      // Check for core PPTX structure
      const hasPresentation = entries.some(e => e.entryName === '[Content_Types].xml');
      const hasRels = entries.some(e => e.entryName === 'ppt/_rels/presentation.xml.rels');
      console.log(`Valid PPTX structure: ${hasPresentation && hasRels ? 'YES' : 'NO'}`);
      
      slideEntries.forEach((entry, i) => {
        const size = entry.header ? entry.header.size : 0;
        console.log(`  Slide ${i+1}: ${(size / 1024).toFixed(1)} KB`);
      });
    }
  } catch(e) {
    console.log('(Skipping detailed validation - adm-zip not available)');
    console.log('File exists and has reasonable size - likely valid.');
  }
  
  console.log('\nValidation complete.');
}

validate().catch(err => {
  console.error('Validation error:', err.message);
  process.exit(0);
});
