#!/usr/bin/env python3
"""
NEXUS v3.1 Documentation — Markdown-to-PDF Generator
Converts all 13 v3.1 markdown docs to professionally formatted PDFs using reportlab.
"""

import os
import re
import sys
from pathlib import Path

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import inch, mm
from reportlab.lib.colors import HexColor, black, white, Color
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_JUSTIFY, TA_RIGHT
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    PageBreak, KeepTogether, HRFlowable, ListFlowable, ListItem,
    Preformatted
)
from reportlab.platypus.tableofcontents import TableOfContents
from reportlab.lib.fonts import addMapping
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

# ─── Configuration ───────────────────────────────────────────────────────────

DOCS_DIR = Path(__file__).parent
OUTPUT_DIR = DOCS_DIR

FILES = [
    "01_User_Guide_v3.1.md",
    "02_Quick_Start_Guide.md",
    "03_Terms_and_Definitions.md",
    "04_Developer_Guide_v3.1.md",
    "05_Architecture_v3.1.md",
    "06_Modification_Tips_and_Tricks.md",
    "07_Training_Your_Own_Model.md",
    "08_Examples_and_Templates.md",
    "09_Autonomous_Research_Repository.md",
    "10_The_Bootstrapping_Agent.md",
    "11_The_Autonomous_Builder.md",
    "12_Idea_Trees_and_Direction.md",
    "13_Cross_Linguistic_Perspective_Analysis.md",
]

# Colors
CLR_TITLE = HexColor("#1a1a2e")
CLR_H1 = HexColor("#16213e")
CLR_H2 = HexColor("#0f3460")
CLR_H3 = HexColor("#533483")
CLR_BODY = HexColor("#2d2d2d")
CLR_CODE_BG = HexColor("#f0f0f0")
CLR_CODE_BORDER = HexColor("#d0d0d0")
CLR_TABLE_HEADER = HexColor("#1a1a2e")
CLR_TABLE_HEADER_TEXT = white
CLR_TABLE_ALT_ROW = HexColor("#f5f5f8")
CLR_ACCENT = HexColor("#e94560")
CLR_LINK = HexColor("#0f3460")
CLR_CHECKBOX = HexColor("#333333")

# Page dimensions
PAGE_W, PAGE_H = A4
MARGIN = 0.9 * inch


# ─── Styles ──────────────────────────────────────────────────────────────────

def build_styles():
    """Build all paragraph styles."""
    styles = {}
    styles["title"] = ParagraphStyle(
        "Title", fontName="Helvetica-Bold", fontSize=18,
        leading=22, textColor=CLR_TITLE, spaceAfter=6,
        alignment=TA_LEFT, spaceBefore=0,
    )
    styles["subtitle"] = ParagraphStyle(
        "Subtitle", fontName="Helvetica", fontSize=10,
        leading=13, textColor=HexColor("#555555"), spaceAfter=12,
        alignment=TA_LEFT,
    )
    styles["h1"] = ParagraphStyle(
        "H1", fontName="Helvetica-Bold", fontSize=15,
        leading=19, textColor=CLR_H1, spaceBefore=18, spaceAfter=8,
        borderWidth=0, borderPadding=0,
    )
    styles["h2"] = ParagraphStyle(
        "H2", fontName="Helvetica-Bold", fontSize=12,
        leading=15, textColor=CLR_H2, spaceBefore=14, spaceAfter=6,
    )
    styles["h3"] = ParagraphStyle(
        "H3", fontName="Helvetica-Bold", fontSize=10,
        leading=13, textColor=CLR_H3, spaceBefore=10, spaceAfter=4,
    )
    styles["body"] = ParagraphStyle(
        "Body", fontName="Helvetica", fontSize=9,
        leading=12.5, textColor=CLR_BODY, spaceBefore=2, spaceAfter=4,
        alignment=TA_JUSTIFY,
    )
    styles["bullet"] = ParagraphStyle(
        "Bullet", fontName="Helvetica", fontSize=9,
        leading=12.5, textColor=CLR_BODY, spaceBefore=1, spaceAfter=2,
        leftIndent=18, bulletIndent=6, alignment=TA_LEFT,
    )
    styles["numbered"] = ParagraphStyle(
        "Numbered", fontName="Helvetica", fontSize=9,
        leading=12.5, textColor=CLR_BODY, spaceBefore=1, spaceAfter=2,
        leftIndent=18, bulletIndent=6, alignment=TA_LEFT,
    )
    styles["checkbox"] = ParagraphStyle(
        "Checkbox", fontName="Helvetica", fontSize=9,
        leading=12.5, textColor=CLR_BODY, spaceBefore=1, spaceAfter=2,
        leftIndent=18, bulletIndent=6, alignment=TA_LEFT,
    )
    styles["code"] = ParagraphStyle(
        "Code", fontName="Courier", fontSize=7,
        leading=9, textColor=HexColor("#333333"),
        backColor=CLR_CODE_BG, spaceBefore=4, spaceAfter=4,
        leftIndent=10, rightIndent=10,
        borderWidth=0.5, borderColor=CLR_CODE_BORDER,
        borderPadding=5,
    )
    styles["block_quote"] = ParagraphStyle(
        "BlockQuote", fontName="Helvetica-Oblique", fontSize=9,
        leading=12, textColor=HexColor("#444444"), spaceBefore=6, spaceAfter=6,
        leftIndent=24, rightIndent=12,
        borderWidth=2, borderColor=CLR_ACCENT, borderPadding=6,
    )
    styles["table_header"] = ParagraphStyle(
        "TableHeader", fontName="Helvetica-Bold", fontSize=8,
        leading=10, textColor=CLR_TABLE_HEADER_TEXT, alignment=TA_LEFT,
    )
    styles["table_cell"] = ParagraphStyle(
        "TableCell", fontName="Helvetica", fontSize=8,
        leading=10, textColor=CLR_BODY, alignment=TA_LEFT,
    )
    styles["hr"] = ParagraphStyle(
        "HR", fontName="Helvetica", fontSize=6,
        leading=8, textColor=CLR_BODY, spaceBefore=8, spaceAfter=8,
        alignment=TA_CENTER,
    )
    styles["footer"] = ParagraphStyle(
        "Footer", fontName="Helvetica", fontSize=7,
        leading=9, textColor=HexColor("#999999"), alignment=TA_CENTER,
    )
    styles["header_text"] = ParagraphStyle(
        "Header", fontName="Helvetica", fontSize=7,
        leading=9, textColor=HexColor("#999999"), alignment=TA_LEFT,
    )
    return styles


# ─── Markdown Parsing ────────────────────────────────────────────────────────

def parse_inline(text, styles, style_key="body"):
    """Convert inline markdown (bold, italic, code) to reportlab XML markup."""
    # Escape HTML special chars first (but not our own tags)
    # Protect backticks/code spans
    code_spans = []
    def save_code(m):
        code_spans.append(m.group(1))
        return f"__CODESPAN_{len(code_spans) - 1}__"
    text = re.sub(r"`([^`]+)`", save_code, text)
    
    # Bold+italic  ***text***
    text = re.sub(r'\*\*\*(.+?)\*\*\*', r'<b><i>\1</i></b>', text)
    # Bold **text**
    text = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', text)
    # Italic *text* (but not inside words already processed)
    text = re.sub(r'(?<!\*)\*(?!\*)(.+?)(?<!\*)\*(?!\*)', r'<i>\1</i>', text)
    # Restore code spans with mono font
    for i, cs in enumerate(code_spans):
        text = text.replace(f"__CODESPAN_{i}__", f'<font name="Courier" size="7">{cs}</font>')
    
    return text


def md_to_flowables(md_text, styles):
    """Convert a markdown string into a list of reportlab flowables."""
    flowables = []
    lines = md_text.split("\n")
    i = 0
    in_code_block = False
    code_lines = []
    code_lang = ""
    
    # State for grouped list items
    list_items = []
    list_type = None  # 'bullet', 'numbered', 'checkbox'
    
    def flush_list():
        nonlocal list_items, list_type
        if list_items:
            for item_text, item_type in list_items:
                if item_type == "checkbox":
                    # Handle checkbox
                    checked = item_text.startswith("[x]")
                    label = item_text[3:].strip()
                    if label.startswith("-"):
                        label = label[1:].strip()
                    box = "\u2611" if checked else "\u2610"
                    clean = parse_inline(label, styles, "checkbox")
                    flowables.append(Paragraph(f"{box}  {clean}", styles["checkbox"]))
                else:
                    clean = parse_inline(item_text, styles, item_type)
                    if item_type == "bullet":
                        flowables.append(Paragraph(f"\u2022  {clean}", styles["bullet"]))
                    elif item_type == "numbered":
                        flowables.append(Paragraph(f"\u2022  {clean}", styles["numbered"]))
            list_items = []
            list_type = None
    
    def detect_list_type(line):
        stripped = line.lstrip()
        if re.match(r"^\[[ xX]\]", stripped):
            return "checkbox"
        if re.match(r"^[-*]\s", stripped):
            return "bullet"
        if re.match(r"^\d+\.\s", stripped):
            return "numbered"
        return None
    
    while i < len(lines):
        line = lines[i]
        
        # ── Code blocks ──
        if line.strip().startswith("```"):
            if in_code_block:
                # End code block
                in_code_block = False
                code_text = "\n".join(code_lines)
                # Escape XML chars in code
                code_text = code_text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                flowables.append(Paragraph(code_text, styles["code"]))
                code_lines = []
                i += 1
                continue
            else:
                # Start code block
                flush_list()
                in_code_block = True
                code_lang = line.strip()[3:].strip()
                code_lines = []
                i += 1
                continue
        
        if in_code_block:
            code_lines.append(line)
            i += 1
            continue
        
        stripped = line.strip()
        
        # ── Empty line ──
        if not stripped:
            flush_list()
            i += 1
            continue
        
        # ── Horizontal rule ──
        if re.match(r"^[\-_]{3,}\s*$", stripped):
            flush_list()
            flowables.append(HRFlowable(
                width="100%", thickness=0.5, color=HexColor("#cccccc"),
                spaceBefore=6, spaceAfter=6,
            ))
            i += 1
            continue
        
        # ── Headings ──
        heading_match = re.match(r"^(#{1,3})\s+(.+)$", stripped)
        if heading_match:
            flush_list()
            level = len(heading_match.group(1))
            heading_text = parse_inline(heading_match.group(2).strip(), styles)
            if level == 1:
                flowables.append(Spacer(1, 10))
                flowables.append(Paragraph(heading_text, styles["h1"]))
            elif level == 2:
                flowables.append(Paragraph(heading_text, styles["h2"]))
            elif level == 3:
                flowables.append(Paragraph(heading_text, styles["h3"]))
            i += 1
            continue
        
        # ── Tables ──
        if stripped.startswith("|") and stripped.endswith("|"):
            flush_list()
            # Collect all table rows
            table_rows = []
            while i < len(lines) and lines[i].strip().startswith("|") and lines[i].strip().endswith("|"):
                row_text = lines[i].strip()
                # Skip separator rows like |---|---|
                if re.match(r"^\|[\s\-:|]+\|$", row_text):
                    i += 1
                    continue
                cells = [c.strip() for c in row_text.split("|")[1:-1]]
                table_rows.append(cells)
                i += 1
            
            if table_rows:
                # Determine column count
                num_cols = max(len(r) for r in table_rows)
                # Pad rows
                for r in table_rows:
                    while len(r) < num_cols:
                        r.append("")
                
                # Build table data with styled paragraphs
                table_data = []
                for row_idx, row in enumerate(table_rows):
                    styled_row = []
                    for cell in row:
                        cell_text = parse_inline(cell, styles, "table_header" if row_idx == 0 else "table_cell")
                        if row_idx == 0:
                            styled_row.append(Paragraph(cell_text, styles["table_header"]))
                        else:
                            styled_row.append(Paragraph(cell_text, styles["table_cell"]))
                    table_data.append(styled_row)
                
                # Calculate column widths
                available_w = PAGE_W - 2 * MARGIN
                col_w = available_w / num_cols
                
                t = Table(table_data, colWidths=[col_w] * num_cols, repeatRows=1)
                
                # Style the table
                tstyle_cmds = [
                    ("BACKGROUND", (0, 0), (-1, 0), CLR_TABLE_HEADER),
                    ("TEXTCOLOR", (0, 0), (-1, 0), CLR_TABLE_HEADER_TEXT),
                    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                    ("FONTSIZE", (0, 0), (-1, 0), 8),
                    ("BOTTOMPADDING", (0, 0), (-1, 0), 5),
                    ("TOPPADDING", (0, 0), (-1, 0), 5),
                    ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
                    ("FONTSIZE", (0, 1), (-1, -1), 8),
                    ("BOTTOMPADDING", (0, 1), (-1, -1), 4),
                    ("TOPPADDING", (0, 1), (-1, -1), 4),
                    ("LEFTPADDING", (0, 0), (-1, -1), 5),
                    ("RIGHTPADDING", (0, 0), (-1, -1), 5),
                    ("GRID", (0, 0), (-1, -1), 0.3, HexColor("#cccccc")),
                    ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ]
                
                # Alternating row colors
                for row_idx in range(1, len(table_data)):
                    if row_idx % 2 == 0:
                        tstyle_cmds.append(("BACKGROUND", (0, row_idx), (-1, row_idx), CLR_TABLE_ALT_ROW))
                
                t.setStyle(TableStyle(tstyle_cmds))
                flowables.append(Spacer(1, 4))
                flowables.append(t)
                flowables.append(Spacer(1, 4))
            continue
        
        # ── Block quotes ──
        if stripped.startswith(">"):
            flush_list()
            quote_text = stripped.lstrip(">").strip()
            quote_parsed = parse_inline(quote_text, styles, "block_quote")
            flowables.append(Paragraph(f'"{quote_parsed}"', styles["block_quote"]))
            i += 1
            continue
        
        # ── List items ──
        lt = detect_list_type(stripped)
        if lt:
            if lt != list_type:
                flush_list()
                list_type = lt
            content = stripped
            # Strip list marker
            if lt == "bullet":
                content = re.sub(r"^[-*]\s+", "", content)
            elif lt == "numbered":
                content = re.sub(r"^\d+\.\s+", "", content)
            elif lt == "checkbox":
                content = content  # keep the [ ] or [x] prefix
            list_items.append((content, lt))
            i += 1
            continue
        
        # ── Regular paragraph ──
        flush_list()
        # Collect continuation lines for paragraph
        para_lines = [stripped]
        i += 1
        while i < len(lines):
            next_stripped = lines[i].strip()
            if not next_stripped:
                break
            if (next_stripped.startswith("#")
                or next_stripped.startswith("|")
                or next_stripped.startswith("```")
                or next_stripped.startswith(">")
                or next_stripped.startswith("- ")
                or next_stripped.startswith("* ")
                or re.match(r"^\d+\.\s", next_stripped)
                or re.match(r"^\[[ xX]\]", next_stripped)
                or re.match(r"^[\-_]{3,}\s*$", next_stripped)):
                break
            para_lines.append(next_stripped)
            i += 1
        
        para_text = " ".join(para_lines)
        parsed = parse_inline(para_text, styles, "body")
        flowables.append(Paragraph(parsed, styles["body"]))
    
    flush_list()
    return flowables


# ─── Page Templates ──────────────────────────────────────────────────────────

def header_footer(canvas, doc, doc_title):
    """Draw header and footer on each page."""
    canvas.saveState()
    
    # Footer line
    canvas.setStrokeColor(HexColor("#cccccc"))
    canvas.setLineWidth(0.5)
    canvas.line(MARGIN, MARGIN - 12, PAGE_W - MARGIN, MARGIN - 12)
    
    # Footer text: page number
    page_num = doc.page
    canvas.setFont("Helvetica", 7)
    canvas.setFillColor(HexColor("#999999"))
    canvas.drawCentredString(PAGE_W / 2, MARGIN - 24, f"Page {page_num}")
    
    # Footer right: document short name
    short_name = doc_title[:60]
    canvas.drawRightString(PAGE_W - MARGIN, MARGIN - 24, short_name)
    
    # Header line
    canvas.setStrokeColor(HexColor("#cccccc"))
    canvas.line(MARGIN, PAGE_H - MARGIN + 12, PAGE_W - MARGIN, PAGE_H - MARGIN + 12)
    
    # Header text
    canvas.setFont("Helvetica", 7)
    canvas.setFillColor(HexColor("#999999"))
    canvas.drawString(MARGIN, PAGE_H - MARGIN + 18, "NEXUS v3.1 Documentation")
    canvas.drawRightString(PAGE_W - MARGIN, PAGE_H - MARGIN + 18, "Confidential")
    
    canvas.restoreState()


# ─── PDF Generation ──────────────────────────────────────────────────────────

def generate_pdf(md_path, pdf_path, styles):
    """Generate a PDF from a markdown file."""
    filename = os.path.basename(md_path)
    
    # Read markdown
    with open(md_path, "r", encoding="utf-8") as f:
        md_text = f.read()
    
    # Extract title from first H1
    title = filename.replace(".md", "").replace("_", " ")
    first_h1 = re.search(r"^#\s+(.+)$", md_text, re.MULTILINE)
    if first_h1:
        title = first_h1.group(1).strip()
    
    # Extract version/date from metadata if present
    version_line = re.search(r"\*\*Version:\*\*\s*(.+?)\n", md_text)
    date_line = re.search(r"\*\*(?:Last Updated|Date):\*\*\s*(.+?)\n", md_text)
    subtitle_parts = []
    if version_line:
        subtitle_parts.append(f"Version: {version_line.group(1).strip()}")
    if date_line:
        subtitle_parts.append(f"Date: {date_line.group(1).strip()}")
    subtitle = "  |  ".join(subtitle_parts) if subtitle_parts else ""
    
    # Create document
    doc = SimpleDocTemplate(
        str(pdf_path),
        pagesize=A4,
        leftMargin=MARGIN,
        rightMargin=MARGIN,
        topMargin=MARGIN,
        bottomMargin=MARGIN,
        title=title,
        author="NEXUS Platform",
        subject=f"NEXUS v3.1 — {title}",
    )
    
    # Build story
    story = []
    
    # Title page elements
    story.append(Spacer(1, 20))
    story.append(Paragraph(parse_inline(title, styles, "title"), styles["title"]))
    if subtitle:
        story.append(Paragraph(subtitle, styles["subtitle"]))
    story.append(HRFlowable(width="100%", thickness=1.5, color=CLR_ACCENT, spaceBefore=8, spaceAfter=12))
    
    # Parse markdown body (skip the first H1 since we used it as title)
    # Remove the first H1 from md_text to avoid duplication
    body_text = md_text
    if first_h1:
        body_text = md_text[first_h1.end():].lstrip("\n")
    
    flowables = md_to_flowables(body_text, styles)
    story.extend(flowables)
    
    # Build with header/footer callback
    def hf(canvas, doc):
        header_footer(canvas, doc, title)
    
    doc.build(story, onFirstPage=hf, onLaterPages=hf)
    print(f"  [OK] {filename} -> {os.path.basename(pdf_path)}")


def main():
    print("=" * 60)
    print("NEXUS v3.1 Documentation — PDF Generator")
    print("=" * 60)
    print()
    
    styles = build_styles()
    
    success = 0
    errors = 0
    
    for filename in FILES:
        md_path = DOCS_DIR / filename
        pdf_name = filename.replace(".md", ".pdf")
        pdf_path = OUTPUT_DIR / pdf_name
        
        if not md_path.exists():
            print(f"  [MISSING] {filename}")
            errors += 1
            continue
        
        try:
            generate_pdf(str(md_path), str(pdf_path), styles)
            success += 1
        except Exception as e:
            print(f"  [ERROR] {filename}: {e}")
            errors += 1
    
    print()
    print(f"Done: {success} succeeded, {errors} errors out of {len(FILES)} files.")
    return 0 if errors == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
